angular.module("voi.desktop")
    // 个人桌面列表控制器
    .controller("voiDesktopPersonalListController", [
        '$scope', '$modal', '$interval', '$filter', 'voiApi', '$http', '$$$os_types', '$routeParams', 'i18n', 'uihelper', 'voiDPersonalFns',
        function ($scope, $modal, $interval, $filter, voiApi, $http, $$$os_types, $routeParams, i18n, uihelper, voiDPersonalFns) {
            let me = this, fns = voiDPersonalFns;
            me.allRecords = [];
            me.selectRecords = [];
            me.isUpdate = false;
            me.defaultSelectGroup = {
                name: i18n.translate('全部'),
                isLeaf: false,
                id: 'root',
                nodeType: 'all'
            };
            me.rowsById = {};

            $scope.rows = [];
            //每页显示多少条
            $scope.pagesize = 100;
            //当前页
            $scope.currentPage = 1;
            $scope.init = {
                isLoading: false,
                selectGroup: angular.copy(me.defaultSelectGroup),
                selectStatus: "",
                searchText: "",
                desktopStatus: {},
                searchId: null
            };


            //用于跳转之后的筛选
            $scope.init.searchId = $$$storage.getSessionStorage('voi_searchId');
            $$$storage.setSessionStorage('voi_isVoiTab', false);
            $$$storage.setSessionStorage('voi_searchId', '');

            /**
             * 用于拿到当前显示的记录，这里主要为了和界面上的筛选和分页自段拿到一致的记录
             */
            me.getRealRecords = function () {
                let searchRecords = [], pageRecords;
                //选搜索
                searchRecords = $filter("filter")($scope.rows, $scope.init.searchText);
                //根据搜索后的结果再分页
                pageRecords = $filter("paging")(searchRecords, $scope.currentPage, $scope.pagesize);
                return pageRecords;
            };

            /**
             * 按记录中的某个字段分组
             * @param key
             * @param data
             * @returns {{}}
             */
            me.groupRecordBy = function (key, data, toArray = false) {
                let result = {};
                //以记录id为索要建立更新对像
                data.forEach(item => {
                    if (toArray) {
                        if (typeof result[item[key]] === 'undefined') {
                            result[item[key]] = [];
                        }
                        result[item[key]].push(item);
                    } else {
                        result[item[key]] = item;
                    }
                });
                return result;
            };

            //用来轮训
            me.rollPolling = function () {
                if (me.intervalObj) {
                    return false;
                }
                me.intervalObj = $interval(function () {
                    let filterSearchPage = me.getRealRecords();
                    $scope.rows && $scope.$root &&
                    $scope.$root.$broadcast('voipersonalIDS', filterSearchPage.map(item => {
                        return item.id
                    }));

                    if (!window.location.hash.includes('#/desktop/personal')) {
                        if (me.intervalObj) {
                            $interval.cancel(me.intervalObj);
                            me.intervalObj = null;
                        }
                    }
                }, 1000);
            };
            //用来更新列表
            $scope.$on('voipersonalsRowsUpdate', function ($event, data) {
                let ignoreStatus = ['updating', 'making'];
                data = me.formatData(data);
                data.forEach(item => {
                    if (typeof me.rowsById[item.id] !== 'undefined') {
                        /*if (item.extra_data) {
                            item.extra_data.down_speed = item.extra_data.down_speed ? Math.round(item.extra_data.down_speed / 1024) : 0;
                            item.extra_data.up_speed = item.extra_data.up_speed ? Math.round(item.extra_data.up_speed / 1024) : 0;
                            desk.desktop_status = desk.extra_data.status;
                        }
                        */

                        delete item.detailData;

                        //console.log(item);
                        Object.assign(me.rowsById[item.id], item);
                    }
                });


                //$scope.filtrateData($scope.init.searchText, $scope.init.selectStatus, $scope.init.selectGroup);
            });

            //个人桌面排序
            $scope.sortPersonalName = function (name, bool) {
                $scope.rows.sort(function (a, b) {
                    var _numa, _numb;
                    var get_num = function (tar) {
                        for (var i = tar.length - 1; i--; i >= 0) {
                            if (!Number(tar[i])) {
                                return Number(tar.substring(i + 1, tar.length));
                            }
                        }
                    };
                    _numa = get_num(a[name]);
                    _numb = get_num(b[name]);
                    return (_numa - _numb) * (bool ? -1 : 1);
                });
            };
            $scope.filtrateData = function (text, selectStatus, selectGroup, recordId) {
                let nodePath = '';

                if (recordId) {
                    $scope.rows = $scope.rows.filter(function (row) {
                        return row.id == recordId;
                    });
                    //$scope.init.desktopStatus = me.getRecordStatus($scope.rows, 'desktop_status');
                }

                $scope.rows = me.allRecords.filter(function (row) {
                    if (selectStatus) {
                        return row.desktop_status === selectStatus;
                    }
                    return true;
                });
                $scope.rows = fns.filterDesktop($scope.rows, selectGroup);
                /*switch (selectGroup.nodeType) {
                    //uaa管理员，与本地管理员
                    case 'admin':
                        $scope.rows = $scope.rows.filter(row => {
                            /!**如果是最子级的节点
                             * 返回管理员记录，以及相同用户的记录
                             *!/

                            return (!row.user.is_domain_user) &&
                                (row.user.role === 0) &&
                                (row.user.is_uaa === selectGroup.is_uaa) &&
                                (row.user.username === selectGroup.name);
                        });
                        break;
                    //所有本地管理员筛选
                    case 'allAdmin':
                        $scope.rows = $scope.rows.filter(row => {
                            return (!row.user.is_domain_user) &&
                                (row.user.role === 0) &&
                                (!row.user.is_uaa);
                        });
                        break;
                    //所以uaa管理员筛选
                    case 'allUaaAdmin':
                        $scope.rows = $scope.rows.filter(row => {
                            return (!row.user.is_domain_user) &&
                                (row.user.role === 0) &&
                                (row.user.is_uaa);
                        });
                        break;


                    //普通用户 与 普通用户部门
                    case 'common':
                        //普通用户的判断
                        nodePath = selectGroup.nodePath.split('/');
                        nodePath.shift();
                        nodePath = nodePath.join('/');
                        if (!nodePath) {
                            nodePath = selectGroup.name;
                        }
                        $scope.rows = $scope.rows.filter(row => {
                            //搜索绑定的非管理帐号的记录
                            if ((row.user.role === 0) || !row.user.department || row.user.is_uaa) {
                                return false;
                            }
                            //如果选择筛选直接到子节点
                            if (selectGroup.isLeaf) {
                                return row.user.username === selectGroup.name;
                            }
                            //如果非子节点 那么筛选部门
                            return (nodePath && row.user.department.full_group.indexOf(nodePath) !== -1);
                        });
                        break;
                    //uaa普通用户与uaa普通用户部门
                    case 'uaa':
                        nodePath = selectGroup.nodePath.split('/');
                        nodePath.shift();
                        nodePath = nodePath.join('/');
                        if (!nodePath) {
                            nodePath = selectGroup.name;
                        }
                        $scope.rows = $scope.rows.filter(row => {
                            //搜索绑定的非管理帐号的记录
                            if ((row.user.role === 0) || !row.user.department || !row.user.is_uaa) {
                                return false;
                            }
                            //如果选择筛选直接到子节点
                            if (selectGroup.isLeaf) {
                                return row.user.username === selectGroup.name;
                            }
                            //如果非子节点 那么筛选部门
                            return (nodePath && row.user.department.full_group.indexOf(nodePath) !== -1);
                        });
                        break;
                    case 'allUser':
                        $scope.rows = $scope.rows.filter(row => {
                            return (!row.user.is_domain_user) &&
                                (row.user.role !== 0) &&
                                (!row.user.is_uaa);
                        });
                        break;
                    case 'allUaaUser':
                        $scope.rows = $scope.rows.filter(row => {
                            return (!row.user.is_domain_user) &&
                                (row.user.role !== 0) &&
                                (row.user.is_uaa);
                        });
                        break;
                    case 'domain':
                        nodePath = selectGroup.nodePath.split('/')[0];
                        if (!nodePath) {
                            nodePath = selectGroup.name;
                        }

                        $scope.rows = $scope.rows.filter(function (row) {
                            if (row.user.is_domain_user) {
                                if (nodePath && !selectGroup.isLeaf) {
                                    return row.user.username.indexOf('@' + nodePath) !== -1;
                                } else {
                                    return row.user.username === selectGroup.name;
                                }
                            }
                        });
                        break;
                    default:

                        break;
                }*/
                $scope.init.desktopStatus = me.getRecordStatus($scope.rows, 'desktop_status');

            };

            //格式化数据
            me.formatData = function (data) {
                data.forEach(function (desk) {
                    if (desk.user_group === "") {
                        desk.user_group = i18n.translate("管理用户")
                    }

                    if (desk.extra_data) {
                        desk.extra_data.down_speed = desk.extra_data.down_speed ? Math.round(desk.extra_data.down_speed / 1024) : 0;
                        desk.extra_data.up_speed = desk.extra_data.up_speed ? Math.round(desk.extra_data.up_speed / 1024) : 0;
                        desk.desktop_status = desk.extra_data.status;
                    }


                    desk.detailData = {};

                    desk.desktop_status = desk.desktop_status ? desk.desktop_status : 'unknown';
                });

                return data;
            };

            /*//设置操作系统图标
            me.setOSType = function (records) {
                let os;
                records.forEach(function (row) {
                    os = $$$os_types.filter(item => {
                        return item.key.toLowerCase() === row.os_type.toLowerCase()
                    })[0];
                    //row.icon = 'other.png';
                    os && os.icon && (row.icon = os.icon);
                    if (row.os_type) {
                        if (row.os_type.indexOf('_64') > -1)
                            row.os_type = row.os_type.slice(0, row.os_type.indexOf('_64'));
                        if (row.os_type.indexOf('(64 bit)') > -1)
                            row.os_type = row.os_type.slice(0, row.os_type.indexOf('(64 bit)'));
                    }

                });

                return records;
            };*/

            /**
             * 统计记录中所有状态
             */
            me.getRecordStatus = function (records, statusKey) {
                let result = {};
                result.count = me.allRecords.length;
                if (!angular.isArray(records)) {
                    return result;
                }
                records.forEach(function (item) {
                    if (!angular.isArray(result[item[statusKey]])) {
                        result[item[statusKey]] = [];
                    }
                    result[item[statusKey]].push(item);
                });
                return result;
            };

            /**
             * 载入数据
             * 教室
             * 场景
             */
            me.loadData = function () {
                let schoolRoomData = [], queryParams = '/thor/voi/personal/desktops';
                //$scope.init.schoolRooms = [];
                //$scope.rows = [];
                $scope.init.isLoading = true;

                if ($scope.init.searchId) {
                    queryParams = queryParams + '?id=' + $scope.init.searchId;
                }
                $http.get('/thor/controller/ha_storage_state')
                    .then(function (okRes) {
                        let res = okRes.data.result;
                        if (res.storage_type === "local" && res.ha_mode === "active_passive" && res.ha_triggered) {
                            me.isUpdate = true;
                        }

                    }, function (errRes) {
                    });

                $http.get(queryParams)
                    .then(function (okRes) {
                        $scope.rows = me.formatData(okRes.data.result);
                        me.allRecords = $scope.rows;
                        me.rowsById = me.groupRecordBy('id', $scope.rows);
                        $scope.init.searchId = null;
                        $scope.filtrateData($scope.init.searchText, $scope.init.selectStatus, $scope.init.selectGroup);
                        $scope.init.isLoading = false;
                        me.rollPolling();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            me.loadDetail = function (item) {

                if (!item.roam_instance || (Object.getOwnPropertyNames(item.detailData).length > 0)) {
                    return false;
                }


                item.isLoadingDetail = true;

                $http.get('/thor/get_instance_details/' + item.roam_instance.uuid)
                    .then(function (okRes) {
                        item.detailData = okRes.data.result;
                        me.rowsById[item.id].detailData = okRes.data.result;
                        console.log(me.rowsById[item.id]);
                        item.isLoadingDetail = false;
                    }, function (errRes) {
                        item.isLoadingDetail = false;
                    });
            };
            me.loadData();

            $scope.onClickGotoPage = function (item) {
                $$$storage.setSessionStorage('voi_isVoiTab', true);
                $$$storage.setSessionStorage('voi_searchId', item.roam_instance.uuid);
                window.location.href = '#/desktop/roam'
            };

            $scope.onChangeStatus = function (newStatus) {
                $scope.filtrateData($scope.init.searchText, newStatus, $scope.init.selectGroup);
            };
            //绑定终端
            $scope.onClickOpenUser = function (item) {
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/personal_user_group.html",
                    size: "md",
                    controller: "voiUserGroupTreeWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectGroup: $scope.init.selectGroup
                            }
                        }
                    }
                }).result.then(function (selectNode) {
                    if (selectNode) {
                        $scope.init.selectGroup = selectNode;
                    } else {
                        if (!$scope.init.selectGroup) {
                            $scope.init.selectGroup = angular.copy(me.defaultSelectGroup);
                        }
                    }
                    $scope.filtrateData($scope.init.searchText, $scope.init.selectStatus, $scope.init.selectGroup);
                });
            };

            //新增个人桌面
            $scope.onClickAddPersonal = function () {
                if (me.isUpdate) {
                    uihelper.alert(i18n.translate('HA_MODE_REMOTE_SAVE_AS_TPL'));
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/add_personal.html",
                    size: "md",
                    controller: "voiAddPersonalWinCtrl",
                    resolve: {
                        params: function () {
                            // return {
                            //      rows: me.allRecords,
                            //      schoolRooms: $scope.init.schoolRooms
                            // };
                        }
                    }
                }).result.finally(me.loadData)
            };

            //编辑个人桌面
            $scope.onClickEditPersonal = function (item) {
                let selectRecords;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected;
                });

                if (selectRecords.length !== 1) {
                    uihelper.i18nAlert('请选择一个桌面进行编辑');
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/edit_personal.html",
                    size: "md",
                    controller: "voiEditPersonalWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecord: selectRecords[0]
                            };
                        }
                    }
                }).result.finally(me.loadData)
            };

            //展开显示详细
            $scope.onClickExpand = function (item) {
                $scope.rows.forEach(row => {
                    if (row.id !== item.id) {
                        delete row._expand;
                    }
                });
                item._expand = !item._expand;
                if (item._expand) {
                    me.loadDetail(item);
                }
            };

            //唤醒
            $scope.onClickStart = function (item) {
                // client_status
                // 0离线  1部署  2uefi层  3底层维护   4windows  5linux

                let selectRecords, selectIds, unStatus = [0];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.client && (unStatus.indexOf(record.client_status) !== -1);
                });
                selectIds = selectRecords.map(record => record.id);
                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('请选择已绑定终端且终端为离线状态的桌面进行操作');
                    return false;
                }
                $http.post('/thor/voi/personal/desktops/wakeup', {
                    desktop_ids: selectIds
                }).then(me.loadData());
            };

            //关机 2.uefi层  3底层维护  以及 桌面在线
            $scope.onClickShutdown = function (item) {

                let unStatus = [2, 3], selectRecords, selectIds, selectNames = [];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.client && ((unStatus.indexOf(record.client_status) !== -1) ||
                        (record.desktop_status === 'online'));
                });

                selectIds = selectRecords.map(record => record.id);
                selectNames = selectRecords.map(record => record.name);
                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('请选择开机状态的桌面进行操作');
                    return false;
                }
                uihelper.confirmWithModal(
                    '桌面关机',
                    ['桌面{1}关机弹窗提示', selectNames.join(',')]
                ).then(function () {
                    $http.post('/thor/voi/personal/desktops/shutdown', {
                        desktop_ids: selectIds
                    }).then(me.loadData);
                });
            };

            //重启 2.uefi层  3底层维护  以及 桌面在线
            $scope.onClickRestart = function (item) {
                let selectRecords, selectIds, selectNames, unStatus = [2, 3];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.client && (unStatus.indexOf(record.client_status) !== -1 || (record.desktop_status === 'online'));
                });
                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('请选择开机状态的桌面进行操作');
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                selectNames = selectRecords.map(record => record.name);
                uihelper.confirmWithModal(
                    '桌面重启',
                    ['桌面{1}重启弹窗提示', selectNames.join(',')]
                ).then(function () {
                    $http.post('/thor/voi/personal/desktops/reboot', {
                        desktop_ids: selectIds
                    }).then(me.loadData);
                });
            };

            //绑定终端
            $scope.onClickBind = function (item) {
                let selectRecords, bindRecords;

                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected;
                });

                bindRecords = selectRecords.filter(function (record) {
                    return record.client;
                });
                if (selectRecords.length !== 0 && (selectRecords.length === bindRecords.length)) {
                    uihelper.i18nAlert('请选择没有绑定过终端的桌面');
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/bind_client.html",
                    size: "lg",
                    controller: "voiBindPersonalClientWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecords: selectRecords
                            };
                        }
                    }
                }).result.finally(me.loadData)

            };

            //解绑
            $scope.onClickUnBind = function (item) {
                let selectRecords, selectIds;

                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.bind_mac;
                });

                selectIds = selectRecords.map(record => record.id);

                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('解绑桌面客户端提示');
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/unbind_personal.html",
                    controller: "voiUnbindPersonalWinCtrl",
                    resolve: {
                        param: function () {
                            return selectRecords;
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });

            };

            //加域
            $scope.onClickAddDomain = function (item) {
                let selectIds, unStatus = ['online'],
                    selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                        return record._selected && !record.ad_server && record.user.is_domain_user &&
                            ((unStatus.indexOf(record.desktop_status) !== -1) || (record.client_status === 3));
                    });
                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('请选择开机状态且没加过域的桌面进行操作');
                    return;
                }
                selectIds = selectRecords.map(record => record.id);
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/add_domain.html",
                    controller: "voiAddDomainWinCtrl",
                    resolve: {
                        param: function () {
                            return {
                                winType: 'personal',
                                selectRecordIds: selectIds
                            };
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });
            };

            //退域
            $scope.onClickExitDomain = function (item) {
                let selectRecords, selectIds, unStatus = ['online'];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.ad_server && record.user.is_domain_user &&
                        ((unStatus.indexOf(record.desktop_status) !== -1) || (record.client_status === 3));
                });

                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('vdiDesktopPersonalDomain_TIP2');
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                uihelper.confirmWithModal(
                    '退域',
                    'DOMAIN_EXIT_TIP'
                ).then(function () {
                    $http.post('/thor/voi/personal/desktops/quit_domain', {
                        desktop_ids: selectIds
                    }).then(me.loadData);
                });
            };

            //删除桌面
            $scope.onClickDelete = function (item) {
                let unStatus = [], selectRecords, selectIds;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected;
                });
                selectIds = selectRecords.map(record => record.id);

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/alert_input_ok.html",
                    controller: "voiAlertInputYesWinCtrl",
                    size: 'sm',
                    resolve: {
                        param: function () {
                            return {
                                winType: 'delPersonalDesktop'
                            };
                        }
                    }
                }).result.then(function (res) {
                    if (res === 'yes') {
                        $http.delete('/thor/voi/personal/desktops', {data: {ids: selectIds}})
                            .then(function (okRes) {
                                me.loadData();
                            }, function (errRes) {

                            });
                    }
                });
            };

            //个人桌面重置
            $scope.onClickReset = function (item) {
                let unStatus = [], selectRecords, selectIds;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && record.bind_mac && record.client.status !== 0;
                });

                if (selectRecords.length === 0) {
                    uihelper.i18nAlert('个人桌面重置提示');
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/alert_input_ok.html",
                    controller: "voiAlertInputYesWinCtrl",
                    size: 'md',
                    resolve: {
                        param: function () {
                            return {
                                winType: 'resetPersonalDesktop',
                                selectedRecords: selectRecords
                            };
                        }
                    }
                }).result.then(function (res) {
                    if (res === 'yes') {
                        voiApi.personal.reset({
                                desktop_type: 2,
                                desktop_ids: selectIds
                            }, okRes => {
                                me.loadData();
                            },
                            errRes => {
                                me.loadData();
                            });
                    }
                });
            };
            //下发桌面
            $scope.onClickSendDesktop = function (item) {

                // client_status
                // 0离线  1部署  2uefi层  3底层维护   4windows  5linux

                let status = [3, 4], selectIds, selectRecords = [], result = {
                    autoDesks: [],
                    unStatus: [],
                    sendDesks: [],
                    unSendDesks: [],
                    sending: [],
                    noClients: [],
                    clientUpdateIng: []
                };

                if (item) {
                    item._selected = true;
                    selectRecords = [item];
                } else {
                    selectRecords = $scope.rows;
                }


                angular.forEach(selectRecords, function (item) {

                    if (item._selected) {
                        //自动下发的不需要下发
                        if (item.auto_update_desk) {
                            result.autoDesks.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }


                        //正在下发的不需要下发
                        if (item.send_status === 2) {
                            result.sending.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        if (item.roam_instance && item.roam_instance.status !== 'SHUTOFF') {
                            result.unStatus.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        //没有终端的不需要下发
                        if (!item.client) {
                            result.noClients.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        //终端正在下发，那么不运行下发任务
                        if (item.client_updatestatus === 1 || item.client_updatestatus === 2) {
                            result.clientUpdateIng.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        //不在底层和windows层状态的不可以下发
                        if (status.indexOf(item.client_status) === -1) {
                            result.unStatus.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        result.sendDesks.push(item);
                    }


                });


                if (result.sendDesks.length === 0) {


                    if (result.unSendDesks.length !== 0) {
                        uihelper.i18nAlert('请选择桌面非自动下发并且漫游桌面状态为关机终端在维护模式Windows在线状态下的桌面进行操作');
                        return false;
                    }

                    return false;
                }


                // if (selectRecords.length === 0) {
                //     uihelper.alert(i18n.translate('vdiDesktopPersonalDomain_TIP1'));
                //     return;
                // }
                selectIds = selectRecords.map(record => record.id);


                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/send_personal.html",
                    controller: "voiSendPersonalWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecords: result.sendDesks,
                                unSendDesks: result.unSendDesks,
                                winType: 'sendPersonal'
                            };
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });


            };

            //查看桌面
            $scope.onClickView = function (item) {
                // window.open("desktopScreenshot.html#" + item.id, "person_desktop_" + item.id);
                //
                // if (item.status === 'offline') {
                //     return false;
                // }
                if (!item.extra_data) {
                    return false;
                }
                window.open('http://' + window.location.hostname + ':9092/nodejs/vnc_auto.html?view_only=true&cip=' + item.extra_data.desktop_ip, '_blank');

            };

            //页面销毁后 清空定时器
            $scope.$on('$destroy', function () {
                if (me.intervalObj) {
                    $interval.cancel(me.intervalObj);
                    me.intervalObj = null;
                }
            });
        }
    ])
    //添加个人桌面窗口控制器
    .controller('voiAddPersonalWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'params', 'i18n',
        function ($scope, $modalInstance, $http, $q, params, i18n) {
            let me = this;
            $scope.init = {
                stepIndex: 1,
                images: {
                    windows: [],
                    linux: [],
                    other: []
                },
                pools: [],
                imageType: 'windows',
                selectedImage: null,
                enterCountMin: 0,
                dataDisks: [],
                selectedUsers: [],
                selectedDomainUsers: [],
                advancedExpand: false
            };

            $scope.m = {
                name: null,
                count: 1,
                rule_id: 0,
                image_id: null,
                auto_update_desk: false,
                show_desk_info: false,
                system_restore: 0,
                system_date: 1,
                data_restore: 0,
                data_date: 1,
                use_dhcp: false,
                diskless: false
            };

            //载入镜像
            me.loadIsoData = function (classId) {
                let resImages = {};
                $scope.init.isLoading = true;
                ///api/images?status=alive&type=2&virtual_type=kvm&product_type=voi
                $http.get('/thor/image/simple/2?product_type__in=voi&virtual_type=kvm')
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        okRes.data.win_images.forEach(item => {
                            item.os_family = 'windows';
                        });
                        $scope.init.images.windows = okRes.data.win_images.filter(item => item.status === 'alive' && item.data_alloc_disk_2 < 2);
                        $scope.init.images.linux = okRes.data.linux_images.filter(item => item.status === 'alive' && item.data_alloc_disk_2 < 2);
                        $scope.init.images.other = okRes.data.other_images.filter(item => item.status === 'alive' && item.data_alloc_disk_2 < 2);
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            me.loadIsoData();

            //切换镜像类型TAB
            $scope.onChangeImageType = function (type) {
                if (type === $scope.init.imageType) {
                    return false;
                }
                $scope.init.selectedImage = null;
                $scope.m.image_id = null;
                $scope.init.imageType = type;
            };

            //选择镜像
            $scope.selectRow = function (item) {
                $scope.init.selectedImage = item;
                if (item.os_family !== 'windows' || item.firmware_type !== 'uefi') {
                    $scope.m.diskless = false;
                }
                if (item.os_family !== 'windows') {
                    $scope.m.show_desk_info = false;
                }
                $scope.m.image_id = item.id;
            };

            //选择还原方式重置还原时间
            $scope.rollbackChange = function (type) {
                $scope.m[type] = 1;
            };

            //选择额外的还原方式，重置还原时间
            $scope.onChangeDiskRollback = function (index) {
                $scope.init.dataDisks[index].data_date = 1;
            };

            //添加一块额外的数据盘
            $scope.onClickAddDataDisk = function () {
                $scope.init.dataDisks.push({
                    data_restore: 0,
                    data_size: 5
                });
            };

            //删除额外的数据盘
            $scope.onClickRemoveDataDisk = function (index) {
                $scope.init.dataDisks.splice(index, 1);
            };

            //点击使用DHCP功能
            $scope.onClickUseDhcp = function () {
                $scope.m.use_dhcp = !$scope.m.use_dhcp;
            };

            //处理已选择用户之后返回重新修改桌面数量
            $scope.$watch('m.count', function () {
                $scope.m.user_id = me.getSelectedUserId();
            });

            //侦听用户和域的选择，生成已选择的用户id
            $scope.$watch(function () {
                return $scope.init.selectedUsers + ',' + $scope.init.selectedDomainUsers;
            }, function () {
                $scope.m.user_id = me.getSelectedUserId();
            });

            //每次选择用户时生成一下用户ID
            me.getSelectedUserId = function () {
                let result = [];
                angular.forEach($scope.init.selectedUsers, function (user) {
                    if (typeof user.id !== 'undefined') {
                        result.push(user.id);
                    } else {
                        result.push(user.user_id);
                    }
                });
                return (result.length == $scope.m.count) ? result : null;
            };


            /**
             * 向导步骤切换
             * @param type
             */
            $scope.onClickChangePage = function (type) {
                if (type === 'prev') {
                    $scope.init.stepIndex--;
                } else {
                    $scope.init.stepIndex++;
                }
            };

            $scope.ok = function () {
                let submitData;
                $scope.init.isLoading = true;
                submitData = angular.copy($scope.m);

                if ($scope.init.dataDisks.length !== 0) {
                    submitData.extra_data_restore = $scope.init.dataDisks[0].data_restore;
                    submitData.extra_data_date = $scope.init.dataDisks[0].data_date;
                    submitData.extra_data_size = $scope.init.dataDisks[0].data_size;
                }

                if ($scope.init.selectedImage.data_alloc_disk < 2) {
                    delete submitData.data_restore;
                    delete submitData.data_date;
                }
                $http.post('/thor/voi/personal/desktops', submitData)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //编辑个人桌面窗口控制器
    .controller('voiEditPersonalWinCtrl', [
        '$scope', '$modalInstance', '$http', '$modal', '$q', 'params', 'i18n', 'voiDPersonalFns',
        function ($scope, $modalInstance, $http, $modal, $q, params, i18n, voiDPersonalFns) {
            let me = this, key;
            let voiFns = voiDPersonalFns;
            $scope.init = {
                dataDisks: [],
                extra_data_size: null,
                has_extra_data_disk: false,
                has_data_disk: false,
                selectedImage: null,
                selectRecord: params.selectRecord
            };

            $scope.init.selectedImage = params.selectRecord.image;
            $scope.m = {
                name: null,
                hostname: null,
                user_id: null,
                auto_update_desk: false,
                show_desk_info: false,
                system_restore: 0,
                system_date: 1,
                data_restore: 0,
                data_date: 1,
                use_dhcp: false,
                diskless: false
            };

            $scope.treeCfg = {
                options: {
                    allowDeselect: false,
                    isSelectable: function (node) {
                        //控制某些节点是否可选
                        return node.isSelectable;
                    }
                },
                _is_open: false,
                expandedNodes: [],//用于控制树当前的默认展开的节点
                selectedNode: null,//用于控制树当前的默认选择
                alternativeNode: null,//将要加到选中的用户列表
                tree: [],//所有目录均在这里存放
                nodes: [],
                getNodePath: function (pathAllNodes) {
                    let result = [], i = 2, l = pathAllNodes.length + 1;
                    for (i; l > i; i++) {
                        result.push(pathAllNodes[pathAllNodes.length - i].name);
                    }
                    return result.join('/');
                },
                onToggleNode: function (selectedNode) {
                },
                onSelectionNode: function (node, selected, $parentNode, $index, $first, $middle, $last, $odd, $even, $path) {
                    $scope.treeCfg.selectedNode = node;
                    $scope.treeCfg.selectedNode.nodePath = $scope.treeCfg.getNodePath($path(node));
                    $scope.treeCfg._is_open = false;
                }
            };

            me.selectRecord = params.selectRecord;
            console.log(me.selectRecord);

            //还原额外数据盘
            $scope.onClickRestoreExtra = function () {
                $scope.init.has_extra_data_disk = me.selectRecord.has_extra_data_disk;
                $scope.init.has_data_disk = me.selectRecord.has_data_disk;
                if (me.selectRecord.has_extra_data_disk) {
                    $scope.init.dataDisks.push({
                        data_restore: me.selectRecord.extra_data_restore,
                        data_date: me.selectRecord.extra_data_date,
                        data_size: me.selectRecord.extra_data_size
                    });
                    $scope.init.extra_data_size = me.selectRecord.extra_data_size;
                }
            };

            if (me.selectRecord) {
                for (key in $scope.m) {
                    if (me.selectRecord.hasOwnProperty(key)) {
                        $scope.m[key] = me.selectRecord[key];
                    }
                }

                $scope.onClickRestoreExtra();
                $scope.m.user_id = me.selectRecord.user.id;
            }

            //滚动到对应选择的位置
            me.scrollTree = function () {
                let treeWrap = $('#voiTreeControlPicker'), nodeWrap;
                if (!me.treeInterval) {
                    me.treeInterval = setInterval(function () {
                        if (!$scope.treeCfg._is_open) {
                            return false;
                        }
                        nodeWrap = $('#voiTreeControlPicker .tree-selected');
                        if (nodeWrap.length) {
                            treeWrap.animate({
                                    scrollTop: nodeWrap.offset().top - treeWrap.offset().top + treeWrap.scrollTop()
                                }, 1000
                            );
                            clearInterval(me.treeInterval);
                            me.treeInterval = null;
                            me.scrollTree = function () {
                            };
                        }
                    }, 100);
                }

            };

            //载入用户选择框
            me.loadUsers = function () {
                $scope.init.isLoading = true;
                $q.all([
                    $http.get('/thor/user/manager'),
                    $http.get('/thor/user/common/tree'),
                    $http.get('/thor/user/get_users')
                ]).then(function (okRes) {
                    let treeData;

                    treeData = {
                        admin: okRes[0].data.users,
                        common: okRes[1].data.result,
                        uaa: okRes[1].data.uaa_result,
                        domain: okRes[2].data.result
                    };
                    treeData = voiFns.formatTree(treeData);
                    $scope.treeCfg.tree = treeData.tree;
                    $scope.treeCfg.expandedNodes = treeData.nodes;
                    $scope.treeCfg.selectedNode = treeData.tree[0];
                    if (me.selectRecord.user) {
                        $scope.treeCfg.selectedNode = treeData.nodes.filter(function (item) {

                            if (me.selectRecord.user.is_domain_user) {
                                return ('domain' === item.nodeType) && (me.selectRecord.user.id === item.id);
                            }
                            if (!me.selectRecord.user.is_domain_user && me.selectRecord.user.department) {
                                return (['common', 'uaa'].includes(item.nodeType)) && (me.selectRecord.user.id === item.id);
                            }
                            if (!me.selectRecord.user.is_domain_user && !me.selectRecord.user.department) {
                                return ('admin' === item.nodeType) && (me.selectRecord.user.id === item.id);
                            }
                        })[0];
                    }
                    $scope.init.isLoading = false;
                }, function (errRes) {
                    $scope.init.isLoading = false;
                });
            };
            me.loadUsers();

            //点击树型下拉框时 滚动到选择的位置
            $scope.onClickTreePicker = function () {
                $scope.treeCfg._is_open = !$scope.treeCfg._is_open;
                me.scrollTree();
            };

            //选择还原方式时重置还原时间
            $scope.rollbackChange = function (type) {
                $scope.m[type] = 1;
            };

            //选择额外数据盘还原方式时，重置还原时间
            $scope.onChangeDiskRollback = function (index) {
                $scope.init.dataDisks[index].data_date = 1;
            };

            //添加一块额外的数据盘
            $scope.onClickAddDataDisk = function () {
                $scope.init.dataDisks.push({
                    data_restore: 0,
                    data_size: 5
                });
            };

            //删除额外的数据盘
            $scope.onClickRemoveDataDisk = function (index) {
                $scope.init.dataDisks.splice(index, 1);
            };

            //点击使用DHCP功能
            $scope.onClickUseDhcp = function () {
                $scope.m.use_dhcp = !$scope.m.use_dhcp;
            };

            //提交表单数据
            me.submitForm = function (submitData) {
                $scope.init.isLoading = true;
                $http.put('/thor/voi/personal/desktop/' + me.selectRecord.id, submitData)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            let outScope = $scope;
            // 更换用户按钮
            $scope.onChangeUser = function () {
                $modal.open({
                    size: "md",
                    templateUrl: "views/vdi/dialog/desktop/user-select-modal.html",
                    controller: function ($scope, $modalInstance) {
                        let models = $scope.m = {
                            selectUser: null
                        }
                        $scope.ok = function () {
                            models.selectUser.name = models.selectUser.username;
                            outScope.treeCfg.selectedNode = models.selectUser;
                            $modalInstance.close();
                        }
                        $scope.close = function () {
                            $modalInstance.close();
                        }
                    }
                }).result.finally(function () {
                    // ignore
                });
            }

            $scope.ok = function () {
                let submitData;
                submitData = angular.copy($scope.m);
                submitData.user_id = $scope.treeCfg.selectedNode.id;
                if ($scope.init.dataDisks.length !== 0) {
                    submitData.extra_data_restore = $scope.init.dataDisks[0].data_restore;
                    submitData.extra_data_date = $scope.init.dataDisks[0].data_date;
                    submitData.extra_data_size = $scope.init.dataDisks[0].data_size;
                }

                //分别对待原来有额外的数据盘，确认要删除时
                if ($scope.init.has_extra_data_disk && $scope.init.dataDisks.length === 0) {
                    $modal.open({
                        templateUrl: "views/voi/dialog/desktop/alert_input_ok.html",
                        controller: "voiAlertInputYesWinCtrl",
                        size: 'sm',
                        resolve: {
                            param: function () {
                                return {
                                    winType: 'delExtraData'
                                }
                            }
                        }
                    }).result.then(function (res) {
                        if (res === 'yes') {
                            submitData.extra_data_restore = null;
                            submitData.extra_data_size = 0;
                            me.submitForm(submitData);
                        }
                    });
                    return false;
                }

                me.submitForm(submitData);
            };
            $scope.close = function () {
                if (me.treeInterval) {
                    clearInterval(me.treeInterval);
                }
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //加域窗口控制器
    .controller("voiAddDomainWinCtrl", [
        '$scope', '$modalInstance', '$http', 'param',
        function ($scope, $modalInstance, $http, param) {
            let me = this;

            //默认个人桌面加入域
            me.submitUrl = '/thor/voi/personal/desktops/join_domain';
            $scope.init = {
                isLoading: false,
                servers: [],
                winType: 'personal'
            };
            $scope.m = {
                recreate_sid: true,
                ad_server_id: null,
                desktop_ids: []
            };

            $scope.init.winType = param.winType;

            $scope.m.desktop_ids = param.selectRecordIds;

            //漫游桌面
            if ($scope.init.winType === 'roam') {
                $scope.m.instance_ids = param.selectRecordIds;
                $scope.m.has_domain = true;
                delete $scope.m.desktop_ids;
                me.submitUrl = '/thor/instances/change_domain';
            }
            //教学桌面
            if ($scope.init.winType === 'teach') {
                $scope.m.action = 'join_domain';
                me.submitUrl = '/thor/voi/mode/desktops';
            }


            $http.get('/thor/user/server')
                .then(function (okRes) {
                    $scope.init.servers = okRes.data.servers;
                    if ($scope.init.servers.length !== 0) {
                        $scope.m.ad_server_id = $scope.init.servers[0].id * 1;
                    }
                }, function (errRes) {

                });

            $scope.ok = function () {

                $scope.init.isLoading = true;

                $scope.m.ad_server_id = $scope.m.ad_server_id * 1;

                $http.post(me.submitUrl, $scope.m)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                $modalInstance.dismiss();
            };
        }])
    //绑定终端窗口控制器
    .controller('voiBindPersonalClientWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'params', 'i18n', 'voiDPersonalFns',
        function ($scope, $modalInstance, $http, $q, params, i18n, voiDPersonalFns) {
            let me = this;
            let voiFns = voiDPersonalFns;

            me.allDeskTops = [];
            me.allClients = [];

            me.bindDesktopIds = [];

            me.treeInterval = null;

            $scope.init = {
                classId: null,
                groupId: null,
                selectedClient: null,
                inputClientMac: null,
                binds: null,
                clients: [],
                desktops: [],
                bindsByMac: {},
                bindsByDeskId: {},
                clientsForSelected: false,
                style: {
                    'height': '201px',
                    'overflow-y': 'auto',
                    'padding': 0
                }
            };

            $scope.m = {
                action: 'bind-client',
                data: []
            };

            $scope.treeCfg = {
                options: {
                    allowDeselect: false,
                    isSelectable: function (node) {
                        //控制某些节点是否可选
                        return true;
                        //return node.isSelectable;
                    }
                },
                _is_open: false,
                expandedNodes: [],//用于控制树当前的默认展开的节点
                selectedNode: null,//用于控制树当前的默认选择
                alternativeNode: null,//将要加到选中的用户列表
                tree: [],//所有目录均在这里存放
                nodes: [],
                getNodePath: function (pathAllNodes) {
                    let result = [], i = 2, l = pathAllNodes.length + 1;
                    for (i; l > i; i++) {
                        result.push(pathAllNodes[pathAllNodes.length - i].name);
                    }
                    return result.join('/');
                },
                onToggleNode: function (selectedNode) {
                },
                onSelectionNode: function (node, selected, $parentNode, $index, $first, $middle, $last, $odd, $even, $path) {
                    $scope.treeCfg.selectedNode = node;
                    $scope.treeCfg.selectedNode.nodePath = $scope.treeCfg.getNodePath($path(node));
                    me.filtrateDesktopsData($scope.treeCfg.selectedNode);
                    $scope.treeCfg._is_open = false;
                }
            };

            //载入用户选择框
            me.loadUsers = function () {
                $scope.init.isLoading = true;
                $q.all([
                    $http.get('/thor/user/manager'),
                    $http.get('/thor/user/common/tree'),
                    $http.get('/thor/user/get_users')
                ]).then(function (okRes) {
                    let treeData;
                    treeData = {
                        admin: okRes[0].data.users,
                        common: okRes[1].data.result,
                        uaa: okRes[1].data.uaa_result,
                        domain: okRes[2].data.result
                    };
                    treeData = voiFns.formatTree(treeData);
                    $scope.treeCfg.tree = treeData.tree;
                    $scope.treeCfg.expandedNodes = treeData.nodes;
                    $scope.treeCfg.selectedNode = treeData.tree[0];
                    if (params.selectGroup) {
                        $scope.treeCfg.selectedNode = treeData.nodes.filter(function (item) {
                            return (params.selectGroup.nodeType === item.nodeType) && (params.selectGroup.id === item.id);
                        })[0];
                    }
                    $scope.init.isLoading = false;
                }, function (errRes) {
                    $scope.init.isLoading = false;
                });
            };
            //载入桌面
            me.loadDesktops = function () {
                $scope.init.isLoading = true;

                if (params.selectRecords.length !== 0) {

                    me.allRecords = angular.copy(params.selectRecords);

                    //筛选掉已绑定过的桌面
                    $scope.init.desktops = me.filtrateBindDesktops(me.allRecords);

                    //$scope.init.desktops = params.selectRecords;
                    $scope.init.clientsForSelected = true;
                    $scope.init.style.height = '295px';
                    $scope.init.isLoading = false;
                    return false;
                }


                $http.get('/thor/voi/personal/desktops')
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        //筛选掉已绑定过的桌面
                        me.allDeskTops = me.filtrateBindDesktops(okRes.data.result);
                        $scope.init.desktops = angular.copy(me.allDeskTops);

                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            //载入客户端列表
            me.loadClients = function (poolId) {
                $http.get('/thor/voi-clients?pool_id=' + poolId)
                    .then(function (okRes) {
                        $scope.init.clients = okRes.data.clients;
                    }, function (errRes) {

                    });
            };
            //载入教室
            me.loadClassRooms = function () {
                $http.get('/thor/pools?product_type=voi&simple=true')
                    .then(function (okRes) {
                        $scope.init.classrooms = okRes.data.pools_;
                        if ($scope.init.classrooms.length !== 0) {
                            $scope.init.classId = $scope.init.classrooms[0].id;
                            me.loadClients($scope.init.classrooms[0].id);
                        }
                    }, function (errRes) {
                    });
            };
            //筛选已绑定过的桌面
            me.filtrateBindDesktops = function (desktops) {
                let result = [];
                angular.forEach(desktops, function (item) {
                    if (!item.client) {
                        result.push(item);
                    }
                });

                return result;
            };
            //按选择的用户组筛选列表
            me.filtrateDesktopsData = function (selectGroup) {
                let nodePath = '';
                $scope.init.desktops = angular.copy(me.allDeskTops);
                if (selectGroup) {
                    $scope.init.desktops = voiFns.filterDesktop(me.allDeskTops, selectGroup);
                }
            };
            me.loadUsers();
            me.loadClassRooms();
            me.loadDesktops();

            //已绑定的客户端中是否存在相同的桌面
            me.clientHasDesktop = function (desktop, clientMac) {
                let result = false;
                if ($scope.init.binds === null) {
                    return result;
                }
                angular.forEach($scope.init.binds, function (bind) {
                    if (bind.desktop.id === desktop.id) {
                        if (bind.client.mac === clientMac) {
                            result = true;
                        }
                    }
                });
                return result;
            };
            //切换分组
            $scope.onChangeClassRoom = function (poolId) {
                me.loadClients(poolId);
            };
            $scope.isAllReady = function () {
                let result = false,
                    selectedDeskTops = $scope.init.desktops.filter(desk => {
                        return desk._isSelected;
                    });
                if ($scope.init.selectedClient && $scope.init.selectedClient !== '0') {
                    result = Object.getOwnPropertyNames($scope.init.selectedClient);
                } else {
                    result = $scope.init.selectedClient === '0' && !!$scope.init.inputClientMac;
                }
                result = selectedDeskTops.length > 0 && result;
                return result;
            };
            //删除已绑定的终端
            $scope.onClickRemoveBind = function (index) {
                let removeBind = $scope.init.binds[index];

                angular.forEach($scope.init.desktops, function (desktop) {
                    if (desktop.id === removeBind.desktop.id) {
                        desktop.isHidden = false;
                    }
                });
                $scope.init.binds.splice(index, 1);
                if ($scope.init.binds.length === 0) {
                    $scope.init.binds = null;
                }
            };
            //点击绑定时做重复判断，最终确定是否放入下表
            $scope.onClickBind = function () {
                // {desktop : {name : '', id : ''}, client : {client_name : '', id: '', mac : ''}}
                let selectedDeskTops = [], selectedClient = angular.copy($scope.init.selectedClient), tmpBinds;

                if (selectedClient === '0') {
                    selectedClient = {mac: $scope.init.inputClientMac};
                }

                angular.forEach($scope.init.desktops, function (desktop) {
                    if (desktop._isSelected) {
                        desktop._isSelected = false;
                        selectedDeskTops.push(desktop);
                        desktop.isHidden = true;
                    }
                });

                angular.forEach(selectedDeskTops, function (desktop) {

                    if (!me.clientHasDesktop(desktop, selectedClient.mac)) {
                        if ($scope.init.binds === null) {
                            $scope.init.binds = [];
                        }
                        desktop._isSelected = false;
                        $scope.init.binds.push({
                            desktop: angular.copy(desktop),
                            client: angular.copy(selectedClient)
                        });
                    }
                });
            };

            $scope.ok = function () {
                let submitData;
                $scope.init.isLoading = true;
                if ($scope.init.binds === null) {
                    return false;
                }

                angular.forEach($scope.init.binds, function (item) {
                    $scope.m.data.push({
                        desktop_id: item.desktop.id,
                        client_mac: item.client.mac,
                    });
                });

                $http.put('/thor/voi/personal/desktops', $scope.m)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    });


            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //解绑终端窗口控制器
    .controller('voiUnbindPersonalWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'param', 'i18n',
        function ($scope, $modalInstance, $http, $q, param, i18n) {

            $scope.init = {
                isLoading: false,
                desktops: [],
                inputOk: '',
                okBtnText: i18n.translate('确定')
            };

            $scope.m = {
                action: 'unbind-client',
                data: []
            };

            $scope.init.desktops = param;

            $scope.onChangeInputOk = function () {
                return ($scope.init.inputOk === $scope.init.okBtnText);
            };

            $scope.ok = function () {
                if (!$scope.onChangeInputOk()) {
                    return false;
                }
                $scope.init.isLoading = true;

                angular.forEach($scope.init.desktops, function (item) {
                    $scope.m.data.push(item.id);
                });

                $http.put('/thor/voi/personal/desktops', $scope.m)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }])
    //下发桌面窗口控制器
    .controller('voiSendPersonalWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'params', 'i18n', 'uihelper',
        function ($scope, $modalInstance, $http, $q, params, i18n, uihelper) {

            let me = this;

            me.hasRoams = [];

            $scope.init = {

                advancedExpand: false,
                desktops: [],
                unSendDesks: [],
                isDisabledBroadcast: false,

                winType: params.winType ? params.winType : 'sendPersonal'
            };

            $scope.m = {
                action: 'manual-update',
                data: {
                    desktop_ids: [],
                    send_mode: 1,
                    send_strategy: 2
                }
            };
            $scope.init.desktops = params.selectRecords;
            $scope.init.unSendDesks = params.unSendDesks;

            if (params.winType === 'sendPersonal') {
                angular.forEach($scope.init.desktops, function (item) {
                    if (item.roam_instance) {
                        me.hasRoams.push(item);
                    }
                });
                $scope.init.isDisabledBroadcast = me.hasRoams.length !== 0;
                $scope.m.data.send_mode = 1;
            }


            $scope.ok = function () {
                let submitData, clientNames = [];
                submitData = angular.copy($scope.m);

                submitData.data.send_strategy = submitData.data.send_strategy * 1;
                submitData.data.send_mode = submitData.data.send_mode * 1;

                angular.forEach($scope.init.desktops, function (item) {
                    submitData.data.desktop_ids.push(item.id);
                    clientNames.push(item.client.client_name);
                });

                if (params.winType === 'cancelSend') {
                    uihelper.confirmWithModal(
                        '取消下发',
                        ['确定要取消{1}正下发的桌面数据吗', clientNames.join(',')]
                    ).then(function () {
                        $scope.init.isLoading = true;
                        $http.delete('/thor/voi/personal/desktops', submitData)
                            .then(function (okRes) {
                                $scope.init.isLoading = false;
                                $scope.close();
                            }, function (errRes) {
                                $scope.init.isLoading = false;
                            });
                    });
                    return false;
                }


                uihelper.confirmWithModal(
                    '下发桌面',
                    ['确定对终端{1}下发个人桌面吗', clientNames.join(',')]
                ).then(function () {
                    $scope.init.isLoading = true;
                    $http.put('/thor/voi/personal/desktops', submitData)
                        .then(function (okRes) {
                            $scope.init.isLoading = false;
                            $modalInstance.close();
                        }, function (errRes) {
                            $scope.init.isLoading = false;
                            $modalInstance.close();
                        });
                });


            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }])
    //列表用户筛选窗口控制器
    .controller('voiUserGroupTreeWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'params', 'i18n', 'voiDPersonalFns',
        function ($scope, $modalInstance, $http, $q, params, i18n, voiDPersonalFns) {
            let me = this;
            let voiFns = voiDPersonalFns;
            $scope.init = {
                isLoading: false
            };
            $scope.treeCfg = {
                options: {
                    allowDeselect: false,
                    isSelectable: function (node) {
                        //控制某些节点是否可选
                        return true;
                        //return node.isSelectable;
                    }
                },
                expandedNodes: [],//用于控制树当前的默认展开的节点
                selectedNode: null,//用于控制树当前的默认选择
                alternativeNode: null,//将要加到选中的用户列表
                tree: [],//所有目录均在这里存放
                nodes: [],
                getNodePath: function (pathAllNodes) {
                    let result = [], i = 2, l = pathAllNodes.length + 1;
                    for (i; l > i; i++) {
                        result.push(pathAllNodes[pathAllNodes.length - i].name);
                    }
                    return result.join('/');
                },
                onToggleNode: function (selectedNode) {
                },
                onSelectionNode: function (node, selected, $parentNode, $index, $first, $middle, $last, $odd, $even, $path) {
                    $scope.treeCfg.selectedNode = node;
                    $scope.treeCfg.selectedNode.nodePath = $scope.treeCfg.getNodePath($path(node));
                }
            };

            me.treeInterval = null;
            //滚动到对应选择的位置
            me.scrollTree = function () {
                let treeWrap = $('#voiTreeControl'), nodeWrap;
                if (!me.treeInterval) {
                    me.treeInterval = setInterval(function () {
                        nodeWrap = $('#voiTreeControl .tree-selected');
                        if (nodeWrap.length) {
                            treeWrap.animate({
                                    scrollTop: nodeWrap.offset().top - treeWrap.offset().top + treeWrap.scrollTop()
                                }, 1000
                            );
                            clearInterval(me.treeInterval);
                            me.treeInterval = null;
                        }
                    }, 100);
                }

            };

            //载入用户选择框
            me.loadUsers = function () {
                $scope.init.isLoading = true;
                $q.all([
                    $http.get('/thor/user/manager'),
                    $http.get('/thor/user/common/tree'),
                    $http.get('/thor/user/get_users')
                ]).then(function (okRes) {
                    let treeData = {
                        admin: okRes[0].data.users,
                        common: okRes[1].data.result,
                        uaa: okRes[1].data.uaa_result,
                        domain: okRes[2].data.result
                    };
                    treeData = voiFns.formatTree(treeData);

                    $scope.treeCfg.tree = treeData.tree;

                    $scope.treeCfg.expandedNodes = treeData.nodes;

                    $scope.treeCfg.selectedNode = treeData.tree[0];
                    if (params.selectGroup) {
                        $scope.treeCfg.selectedNode = treeData.nodes.filter(function (item) {
                            return (params.selectGroup.nodeType === item.nodeType) && (params.selectGroup.id === item.id);
                        })[0];
                    }
                    me.scrollTree();
                    $scope.init.isLoading = false;
                }, function (errRes) {
                    $scope.init.isLoading = false;
                });
            };

            me.loadUsers();

            $scope.ok = function () {
                if (me.treeInterval) {
                    clearInterval(me.treeInterval);
                }
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close($scope.treeCfg.selectedNode);
            };
            $scope.close = function () {
                if (me.treeInterval) {
                    clearInterval(me.treeInterval);
                }
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //弹出输入确定窗口控制器
    .controller('voiAlertInputYesWinCtrl', [
        '$scope', '$modalInstance', '$http', '$q', 'param', 'i18n',
        function ($scope, $modalInstance, $http, $q, param, i18n) {
            $scope.init = {
                inputOk: '',
                winType: param.winType,
                okBtnText: i18n.translate('确定')
            };

            if ($scope.init.winType==='resetPersonalDesktop'){
                console.log(param.selectedRecords);
                $scope.init.selectedNames = param.selectedRecords.map(item=> item.name).join(',');
                $scope.init.selectedCount = param.selectedRecords.length;
            }

            $scope.onChangeInputOk = function () {
                return ($scope.init.inputOk === $scope.init.okBtnText);
            };
            $scope.ok = function () {
                if (!$scope.onChangeInputOk()) {
                    return false;
                }
                $modalInstance.close('yes');
            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close('no');
            };
        }])
    .factory('voiDPersonalFns', ['$timeout', 'i18n', function ($timeout, i18n) {
        let fns = {};


        //格式化树型数据
        fns.formatTree = (treeData) => {
            let tree = angular.copy(treeData);

            let result = {
                nodes: [],
                tree: [
                    {
                        name: i18n.translate('全部'),
                        isLeaf: false,
                        id: 'root',
                        //isSelectable: true,
                        nodeType: 'all',
                        children: []
                    }
                ]
            };

            const tTree = (data, type) => {
                angular.forEach(data, function (node) {
                    result.nodes.push(node);
                    if (type) {
                        node.nodeType = type;
                    }

                    if (typeof node.user_name !== 'undefined') {
                        node.name = node.user_name;
                    }

                    if (typeof node.real_name !== 'undefined') {
                        node.realname = node.real_name;
                    }

                    if (typeof node.dept_name !== 'undefined') {
                        node.name = node.dept_name;
                    }

                    if (typeof node.dept_id !== 'undefined') {
                        node.id = node.dept_id;
                    }
                    if (typeof node.user_id !== 'undefined') {
                        node.id = node.user_id;
                    }

                    if (typeof node.groups !== 'undefined' && node.groups.length !== 0) {
                        node.children = node.groups;
                    }
                    if (typeof node.users !== 'undefined' && node.users.length !== 0) {
                        node.children = node.users;
                    }

                    if (typeof node.children !== 'undefined') {
                        node.isLeaf = false;
                        node.isSelectable = false;

                        //递归处理子节点结构
                        tTree(node.children, type);
                    } else {
                        node.isLeaf = true;
                        node.isSelectable = true;
                    }
                    if (typeof node.parent_id !== 'undefined') {
                        node.isLeaf = false;
                        node.isSelectable = false;
                    }
                });
            };

            for (let key in tree) {
                tTree(tree[key], key);
            }

            result.nodes.unshift({
                name: i18n.translate('UAA普通用户'),
                nodeType: 'allUaaUser',
                id: 'allUaaUser',
                isLeaf: false,
                children: tree.uaa
            });
            result.nodes.unshift({
                name: i18n.translate('UAA管理用户'),
                nodeType: 'allUaaAdmin',
                id: 'allUaaAdmin',
                isLeaf: false,
                children: tree.admin.filter(item => {
                    return item.is_uaa
                })
            });
            result.nodes.unshift({
                name: i18n.translate('普通用户'),
                nodeType: 'allUser',
                id: 'allUser',
                isLeaf: false,
                children: tree.common
            });
            result.nodes.unshift({
                name: i18n.translate('管理用户'),
                nodeType: 'allAdmin',
                id: 'allAdmin',
                isLeaf: false,
                children: tree.admin.filter(item => {
                    return !item.is_uaa;
                })
            });
            result.nodes.push(result.tree[0]);
            result.tree[0].children.push(result.nodes[0]);
            result.tree[0].children.push(result.nodes[1]);
            result.tree[0].children.push(result.nodes[2]);
            result.tree[0].children.push(result.nodes[3]);
            result.tree[0].children = result.tree[0].children.concat(tree.domain);
            return result;
        };
        fns.filterDesktop = (datas, userNode) => {
            let nodePath, result = [];
            switch (userNode.nodeType) {
                //uaa管理员，与本地管理员
                case 'admin':
                    result = datas.filter(row => {
                        /**如果是最子级的节点
                         * 返回管理员记录，以及相同用户的记录
                         */

                        return (!row.user.is_domain_user) &&
                            (row.user.role === 0) &&
                            (row.user.is_uaa === userNode.is_uaa) &&
                            (row.user.username === userNode.name);
                    });
                    break;
                //所有本地管理员筛选
                case 'allAdmin':
                    result = datas.filter(row => {
                        return (!row.user.is_domain_user) &&
                            (row.user.role === 0) &&
                            (!row.user.is_uaa);
                    });
                    break;
                //所以uaa管理员筛选
                case 'allUaaAdmin':
                    result = datas.filter(row => {
                        return (!row.user.is_domain_user) &&
                            (row.user.role === 0) &&
                            (row.user.is_uaa);
                    });
                    break;


                //普通用户 与 普通用户部门
                case 'common':
                    //普通用户的判断
                    nodePath = userNode.nodePath.split('/');
                    nodePath.shift();
                    nodePath = nodePath.join('/');
                    if (!nodePath) {
                        nodePath = userNode.name;
                    }
                    result = datas.filter(row => {
                        //搜索绑定的非管理帐号的记录
                        if ((row.user.role === 0) || !row.user.department || row.user.is_uaa) {
                            return false;
                        }
                        //如果选择筛选直接到子节点
                        if (userNode.isLeaf) {
                            return row.user.username === userNode.name;
                        }
                        //如果非子节点 那么筛选部门
                        return (nodePath && row.user.department.full_group.indexOf(nodePath) !== -1);
                    });
                    break;
                //uaa普通用户与uaa普通用户部门
                case 'uaa':
                    nodePath = userNode.nodePath.split('/');
                    nodePath.shift();
                    nodePath = nodePath.join('/');
                    if (!nodePath) {
                        nodePath = userNode.name;
                    }
                    result = datas.filter(row => {
                        //搜索绑定的非管理帐号的记录
                        if ((row.user.role === 0) || !row.user.department || !row.user.is_uaa) {
                            return false;
                        }
                        //如果选择筛选直接到子节点
                        if (userNode.isLeaf) {
                            return row.user.username === userNode.name;
                        }
                        //如果非子节点 那么筛选部门
                        return (nodePath && row.user.department.full_group.indexOf(nodePath) !== -1);
                    });
                    break;
                case 'allUser':
                    result = datas.filter(row => {
                        return (!row.user.is_domain_user) &&
                            (row.user.role !== 0) &&
                            (!row.user.is_uaa);
                    });
                    break;
                case 'allUaaUser':
                    result = datas.filter(row => {
                        return (!row.user.is_domain_user) &&
                            (row.user.role !== 0) &&
                            (row.user.is_uaa);
                    });
                    break;
                case 'domain':
                    nodePath = userNode.nodePath.split('/')[0];
                    if (!nodePath) {
                        nodePath = userNode.name;
                    }

                    result = datas.filter(function (row) {
                        if (row.user.is_domain_user) {
                            if (nodePath && !userNode.isLeaf) {
                                return row.user.username.indexOf('@' + nodePath) !== -1;
                            } else {
                                return row.user.username === userNode.name;
                            }
                        }
                    });
                    break;
                default:
                    result = datas;
                    break;
            }
            return result;
        };

        return fns;
    }])
;
