angular.module("voi.desktop")
    // 漫游桌面列表控制器
    .controller("voiDesktopRoamListController", [
        '$scope', '$modal', '$interval', '$filter', '$q', '$http', '$$$os_types', '$routeParams', 'i18n', 'uihelper',
        function ($scope, $modal, $interval, $filter, $q, $http, $$$os_types, $routeParams, i18n, uihelper) {
            let me = this;
            me.isUpdate = false;
            me.allRecords = [];
            me.selectRecords = [];

            me.defaultSelectGroup = {
                name: i18n.translate('全部'),
                isLeaf: false,
                id: 'root',
                nodeType: 'all'
            };
            me.rowsById = {};

            $scope.rows = [];
            //每页显示多少条
            $scope.pagesize = 100;
            //当前页
            $scope.currentPage = 1;
            $scope.init = {
                isLoading: false,
                isLoadDetailing: false,
                isCheckMove: false,
                selectGroup: angular.copy(me.defaultSelectGroup),
                selectStatus: "",
                searchText: "",
                searchId: null,
            };

            //用于跳转之后的筛选
            $scope.init.searchId = $$$storage.getSessionStorage('voi_searchId');
            $$$storage.setSessionStorage('voi_isVoiTab', false);
            $$$storage.setSessionStorage('voi_searchId', '');

            /**
             * 用于拿到当前显示的记录，这里主要为了和界面上的筛选和分页自段拿到一致的记录
             */
            me.getRealRecords = function () {
                let searchRecords = [], pageRecords;
                //选搜索
                searchRecords = $filter("filter")($scope.rows, $scope.init.searchText);
                //根据搜索后的结果再分页
                pageRecords = $filter("paging")(searchRecords, $scope.currentPage, $scope.pagesize);
                return pageRecords;
            };

            /**
             * 按记录中的某个字段分组
             * @param key
             * @param data
             * @returns {{}}
             */
            me.groupRecordBy = function (key, data, toArray = false) {
                let result = {};
                //以记录id为索要建立更新对像
                data.forEach(item => {
                    if (toArray) {
                        if (typeof result[item[key]] === 'undefined') {
                            result[item[key]] = [];
                        }
                        result[item[key]].push(item);
                    } else {
                        result[item[key]] = item;
                    }
                });
                return result;
            };

            //用来轮训
            me.rollPolling = function () {
                if (me.intervalObj) {
                    return false;
                }
                me.intervalObj = $interval(function () {
                    let filterSearchPage = me.getRealRecords();
                    $scope.rows && $scope.$root &&
                    $scope.$root.$broadcast('voiRoamsIDS', filterSearchPage.map(item => {
                        return item.id
                    }));

                    if (!window.location.hash.includes('#/desktop/roam')) {
                        if (me.intervalObj) {
                            $interval.cancel(me.intervalObj);
                            me.intervalObj = null;
                        }
                    }
                }, 1000);
            };
            //用来更新列表
            $scope.$on('voiroamsRowsUpdate', function ($event, data) {
                let ignoreStatus = ['updating', 'making'];
                data.forEach(item => {
                    if (typeof me.rowsById[item.id] !== 'undefined') {
                        angular.extend(me.rowsById[item.id], item);
                    }
                });

                //$scope.onChangeSearchText();
            });

            //个人桌面排序
            $scope.sortPersonalName = function (name, bool) {
                $scope.rows.sort(function (a, b) {
                    var _numa, _numb;
                    var get_num = function (tar) {
                        for (var i = tar.length - 1; i--; i >= 0) {
                            if (!Number(tar[i])) {
                                return Number(tar.substring(i + 1, tar.length));
                            }
                        }
                    };
                    _numa = get_num(a[name]);
                    _numb = get_num(b[name]);
                    return (_numa - _numb) * (bool ? -1 : 1);
                });
            };
            $scope.filtrateData = function (text, selectStatus, selectGroup) {
                let nodePath = '';

                $scope.rows = me.allRecords.filter(function (row) {
                    row._selected = false;
                    if (selectStatus) {
                        return row.status === selectStatus;
                    }
                    return true;
                });

                if (selectGroup.nodeType === "common") {
                    $scope.rows = $scope.rows.filter(function (item) {
                        nodePath = selectGroup.nodePath;
                        if (!nodePath) {
                            nodePath = selectGroup.name;
                        }
                        if (item.user_group) {

                            if (nodePath && !selectGroup.isLeaf) {
                                return item.user_group.indexOf(nodePath) !== -1;
                            } else {
                                return item.user === selectGroup.name;
                            }
                        }
                    });
                } else if (selectGroup.nodeType === "domain") {
                    $scope.rows = $scope.rows.filter(function (item) {
                        if (item.is_domain_user) {
                            nodePath = selectGroup.nodePath.split('/')[0];
                            if (!nodePath) {
                                nodePath = selectGroup.name;
                            }
                            if (nodePath && !selectGroup.isLeaf) {
                                return item.user.indexOf('@' + nodePath) !== -1;
                            } else {
                                return item.user === selectGroup.name;
                            }
                        }

                    });
                } else if (selectGroup.nodeType === "admin") {
                    $scope.rows = $scope.rows.filter(function (item) {

                        if (item.user_group === i18n.translate('管理用户')) {
                            return item.user === selectGroup.name;
                        }
                    });
                } else if (selectGroup.nodeType === "allAdmin") {
                    $scope.rows = $scope.rows.filter(function (item) {
                        if (!item.user_group) {
                            return true;
                        }
                    });
                }
            };

            //格式化数据
            me.formatData = function (data) {
                data.forEach(function (desk) {
                    if (desk.user_group === "") {
                        desk.user_group = i18n.translate("管理用户")
                    }

                    desk.detailData = {};
                });

                return data;
            };
            /**
             * 载入数据
             * 教室
             * 场景
             */
            me.loadData = function () {
                let schoolRoomData = [], queryParams = '/thor/roam/instances';
                //$scope.init.schoolRooms = [];
                //$scope.rows = [];
                $scope.init.isLoading = true;

                if ($scope.init.searchId) {
                    queryParams = queryParams + '?instance_id=' + $scope.init.searchId;
                }

                $http.get(queryParams)
                    .then(function (okRes) {
                        $scope.rows = me.formatData(okRes.data.result);
                        me.allRecords = $scope.rows;
                        me.rowsById = me.groupRecordBy('id', $scope.rows);
                        $scope.filtrateData($scope.init.searchText, $scope.init.selectStatus, $scope.init.selectGroup);
                        // $scope.sortPersonalName("display_name");
                        $scope.init.isLoading = false;
                        me.rollPolling();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });


                $http.get('/thor/controller/ha_storage_state')
                    .then(function (okRes) {
                        let res = okRes.data.result;
                        if (res.storage_type === "local" && res.ha_mode === "active_passive" && res.ha_triggered) {
                            me.isUpdate = true;
                        }

                    }, function (errRes) {
                    })
            };
            me.loadDetail = function (item) {

                if (Object.getOwnPropertyNames(item.detailData).length > 0) {
                    return false;
                }

                item.isLoadingDetail = true;

                $http.get('/thor/get_instance_details/' + item.id)
                    .then(function (okRes) {
                        item.detailData = okRes.data.result;
                        item.isLoadingDetail = false;
                    }, function (errRes) {
                        item.isLoadingDetail = false;
                    });

            };

            me.loadData();

            //设置是否漫游
            $scope.onClickEnableRoam = function (item) {
                if (item.voi_desktop.enable_roam) {
                    uihelper.confirmWithModal(
                        '取消漫游功能',
                        '取消漫游功能提示'
                    ).then(function () {
                        item.isLoading = true;
                        $http.post('/thor/voi/personal/desktops/disable_roam', {
                            desktop_ids: [item.voi_desktop.id]
                        }).then(function (okRes) {
                            item.voi_desktop.enable_roam = !item.voi_desktop.enable_roam;
                            item.isLoading = false;
                        }, function (errRes) {
                            item.isLoading = true;
                        })
                    });
                    return false;
                }

                item.isLoading = true;
                $http.post('/thor/voi/personal/desktops/enable_roam', {
                    desktop_ids: [item.voi_desktop.id]
                }).then(function (okRes) {
                    item.voi_desktop.enable_roam = !item.voi_desktop.enable_roam;
                    item.isLoading = false;
                }, function (errRes) {
                    item.isLoading = true;
                })

            };

            $scope.onClickGotoPage = function (item) {
                $$$storage.setSessionStorage('voi_isVoiTab', true);
                $$$storage.setSessionStorage('voi_searchId', item.voi_desktop.id);
                $$$storage.setSessionStorage('voi_searchText', item.voi_desktop.name);
                window.location.href = '#/desktop/personal'
            };
            $scope.onClickGotoVdiClientPage = function (item) {
                $$$storage.setSessionStorage("TERMINAL_TAB", 'vdi');
                location.hash = `#/terminal/client?client_pool=${item.client_pool}&ip=${item.client_ip}`;
            };
            //按帐号筛选
            $scope.onClickOpenUser = function (item) {
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/personal_user_group.html",
                    size: "md",
                    controller: "voiUserGroupTreeWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectGroup: $scope.init.selectGroup
                            }
                        }
                    }
                }).result.then(function (selectNode) {
                    if (selectNode) {
                        $scope.init.selectGroup = selectNode;
                    } else {
                        if (!$scope.init.selectGroup) {
                            $scope.init.selectGroup = angular.copy(me.defaultSelectGroup);
                        }
                    }
                    $scope.filtrateData($scope.init.searchText, $scope.init.selectStatus, $scope.init.selectGroup);
                });
            };

            //新增个人桌面
            $scope.onClickAddRoamDesktop = function () {
                if (me.isUpdate) {
                    uihelper.i18nAlert('HA_MODE_REMOTE_ADD_DESKTOP');
                    return false;
                }
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/add_roam_desktop.html",
                    size: "md",
                    controller: "voiAddRoamDesktopWinCtrl",
                    resolve: {
                        params: function () {
                        }
                    }
                }).result.finally(me.loadData)
            };

            //编辑个人桌面
            $scope.onClickEditPersonal = function (item) {
                let selectRecords;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected;
                });

                if (selectRecords.length !== 1) {
                    uihelper.alert(i18n.translate('请选择一个桌面进行编辑'));
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/edit_roam_desktop.html",
                    size: "md",
                    controller: "voiEditRoamDesktopWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecord: selectRecords[0]
                            };
                        }
                    }
                }).result.finally(me.loadData)
            };

            //展开显示详细
            $scope.onClickExpand = function (item) {
                $scope.rows.forEach(row => {
                    if (row.id !== item.id) {
                        delete row._expand;
                    }
                });
                item._expand = !item._expand;
                if (item._expand) {
                    me.loadDetail(item);
                }
            };

            //开机
            $scope.onClickStart = function (item) {
                let selectRecords, selectIds, unStatus = ['shutdown', 'suspended'];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                selectIds = selectRecords.map(record => record.id);
                if (selectRecords.length === 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP1'));
                    return false;
                }
                $http.post('/thor/instance/starts', {
                    instance_ids: selectIds
                }).then(me.loadData());
            };

            //强制关机
            $scope.onClickPowerOff = function (item) {
                let unStatus = ['running', 'suspended'], selectRecords, selectIds, selectNames = [];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                selectIds = selectRecords.map(record => record.id);
                selectNames = selectRecords.map(record => record.display_name);
                if (selectRecords.length === 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP2'));
                    return false;
                }
                uihelper.confirmWithModal(
                    '桌面关机',
                    ['桌面{1}关机弹窗提示', selectNames.join(',')]
                ).then(function () {
                    $http.post('/thor/instance/shutdowns', {
                        instance_ids: selectIds,
                        is_soft: 'false',
                    }).then(me.loadData);
                });
            };

            //自然关机
            $scope.onClickShutdown = function (item) {
                let unStatus = ['running', 'suspended'], selectRecords, selectIds, selectNames;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                selectIds = selectRecords.map(record => record.id);
                selectNames = selectRecords.map(record => record.display_name);
                if (selectRecords.length === 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP3'));
                    return false;
                }
                uihelper.confirmWithModal(
                    '桌面关机',
                    ['桌面{1}关机弹窗提示', selectNames.join(',')]
                ).then(function () {
                    $http.post('/thor/instance/shutdowns', {
                        is_soft: 'true',
                        instance_ids: selectIds
                    }).then(me.loadData);
                });
            };

            //重启
            $scope.onClickRestart = function (item) {
                let selectRecords, selectIds, selectNames, unStatus = ['running', 'suspended'];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                if (selectRecords.length === 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP4'));
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                selectNames = selectRecords.map(record => record.display_name);
                uihelper.confirmWithModal(
                    '桌面重启',
                    ['桌面{1}重启弹窗提示', selectNames.join(',')]
                ).then(function () {
                    $http.post('/thor/instance/reboots', {
                        instance_ids: selectIds
                    }).then(me.loadData);
                });
            };

            $scope.onClickPause = function (item) {
                let selectRecords, selectIds, unStatus = ['running'];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                if (selectRecords.length == 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP5'));
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                uihelper.confirmWithModal(
                    '桌面暂停',
                    '确定暂停桌面吗'
                ).then(function () {
                    $http.post('/thor/instance/pause', {
                        instance_ids: selectIds
                    }).then(me.loadData);
                });


            };

            //恢复
            $scope.onClickResume = function (item) {
                let selectRecords, selectIds, unStatus = ['paused'];
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected && (unStatus.indexOf(record.status) !== -1) && !record.task_state;
                });
                if (selectRecords.length == 0) {
                    uihelper.alert(i18n.translate('vdiDesktopPersonalList_TIP6'));
                    return false;
                }
                selectIds = selectRecords.map(record => record.id);
                uihelper.confirmWithModal(
                    '桌面恢复',
                    '确定恢复桌面吗'
                ).then(function () {
                    $http.post('/thor/instance/unpause', {
                        instance_ids: selectIds
                    }).then(me.loadData);
                });
            };

            //移动 / 动态迁移
            $scope.onClickMove = function (item, winType) {
                let selectRecords, selectIds, key;


                if (winType) {
                    selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                        return record._selected && record.status === 'running' && !record.task_state
                    });
                    if (!selectRecords.length) {
                        uihelper.alert(i18n.translate('DESKTOP_MOVE_TIP2'));
                        return false;
                    }
                } else {
                    selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                        return record._selected && record.virtual_type === 'kvm' && record.status == 'shutdown' && !record.task_state;
                    });

                }

                selectIds = selectRecords.map(function (item) {
                    return item.id
                });


                if (!winType) {
                    //如果是关机移动，还需要检查主机host
                    $scope.init.isCheckMove = true;
                    $http.post('/thor/check_can_migrate_host', {
                        instance_ids: selectIds
                    }).then(function (okRes) {
                        $scope.init.isCheckMove = false;
                        selectIds = [];
                        for (key in okRes.data.result) {
                            if (okRes.data.result[key]) {
                                selectIds.push(key);
                            }
                        }
                        if (!selectIds.length) {
                            uihelper.alert(i18n.translate('DESKTOP_MOVE_TIP1'));
                            return false;
                        }
                        $modal.open({
                            templateUrl: "views/voi/dialog/desktop/move_roam.html",
                            controller: "voiMoveRoamWinCtrl",
                            resolve: {
                                param: function () {
                                    return {
                                        winType: false,
                                        instanceIds: selectIds
                                    }
                                }
                            }
                        }).result.then(function (res) {
                            me.loadData()
                        });

                    }, function (errRes) {
                        $scope.init.isCheckMove = true;
                    });

                    return false;
                }


                //动态迁移
                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/move_roam.html",
                    controller: "voiMoveRoamWinCtrl",
                    resolve: {
                        param: function () {
                            return {
                                winType: winType ? true : false,
                                instanceIds: selectIds
                            }
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });
            };

            //删除桌面
            $scope.onClickDelete = function (item) {
                let unStatus = [], selectRecords, selectIds;
                selectRecords = item ? [item] : $scope.rows.filter(function (record) {
                    return record._selected;
                });
                selectIds = selectRecords.map(record => record.id);

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/alert_input_ok.html",
                    controller: "voiAlertInputYesWinCtrl",
                    size: 'sm',
                    resolve: {
                        param: function () {
                            return {
                                winType: 'delRoamDesktop'
                            };
                        }
                    }
                }).result.then(function (res) {
                    if (res === 'yes') {
                        $http.delete('/thor/roam/instances', {
                            params: {
                                instance_ids: selectIds,
                                force_delete_data: true,
                            }
                        }).then(function (okRes) {
                            me.loadData();
                        }, function (errRes) {

                        });
                    }
                });
            };

            //下发桌面
            $scope.onClickSendRoamDesktop = function (item) {

                // client.status
                // 0离线  1部署  2uefi层  3底层维护   4windows  5linux

                let status = [3, 4], selectIds, selectRecords = [], result = {
                    autoDesks: [],
                    unStatus: [],
                    sendDesks: [],
                    unSendDesks: [],
                    sending: [],
                    noDesktops: [],
                    onStatus: [],
                    clientUpdateIng: [],
                };

                if (item) {
                    item._selected = true;
                    selectRecords = [item];
                } else {
                    selectRecords = $scope.rows;
                }


                angular.forEach(selectRecords, function (item) {
                    let formatItem;
                    if (item._selected) {
                        formatItem = {
                            name: item.display_name,
                            id: item.voi_desktop.id,
                            client: {
                                client_name: item.voi_desktop.client_name
                            },
                            client_status: item.voi_desktop.client_status,
                            user: {
                                user_id: item.user_id,
                                username: item.user
                            }
                        };

                        //自动下发的不需要下发
                        if (item.auto_update_desk) {
                            result.autoDesks.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        //终端正在下发，那么不运行下发任务
                        if (item.client_updatestatus === 1 || item.client_updatestatus === 2) {
                            result.clientUpdateIng.push(item);
                            result.unSendDesks.push(item);
                            return false;
                        }

                        //正在下发的不需要下发
                        if (item.send_status === 2) {
                            result.sending.push(formatItem);
                            result.unSendDesks.push(formatItem);
                            return false;
                        }

                        //没有漫游桌面的不需要下发
                        if (!item.voi_desktop) {
                            result.noDesktops.push(formatItem);
                            result.unSendDesks.push(formatItem);
                            return false;
                        }

                        if (item.status !== 'shutdown') {
                            result.onStatus.push(formatItem);
                            result.unSendDesks.push(formatItem);
                            return false;
                        }

                        if (!item.voi_desktop.enable_roam) {
                            result.unSendDesks.push(formatItem);
                            return false;
                        }

                        //不在底层和windows层状态的不可以下发
                        if (status.indexOf(item.voi_desktop.client_status) === -1) {
                            result.onStatus.push(formatItem);
                            result.unSendDesks.push(formatItem);
                            return false;
                        }
                        result.sendDesks.push(formatItem);
                    }
                });

                if ((result.sendDesks.length === 0) && (result.unSendDesks.length !== 0)) {
                    uihelper.alert(i18n.translate('请选择桌面为关机终端为维护Windows在线模式进行操作'));
                    return false;
                }


                // if (selectRecords.length === 0) {
                //     uihelper.alert(i18n.translate('vdiDesktopPersonalDomain_TIP1'));
                //     return;
                // }
                selectIds = selectRecords.map(record => record.id);


                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/send_personal.html",
                    controller: "voiSendPersonalWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecords: result.sendDesks,
                                unSendDesks: result.unSendDesks,
                                winType: 'sendRoam'
                            };
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });


            };

            //保存为模板
            $scope.onClickSaveAsTpl = function (item) {

                if (item.status !== 'shutdown' || item.task_state) {
                    uihelper.alert(i18n.translate('关机状态才可执行存为模板操作'));
                    return false;
                }

                if (me.isUpdate) {
                    uihelper.alert(i18n.translate('HA_MODE_REMOTE_SAVE_AS_TPL'));
                    return false;
                }

                $modal.open({
                    templateUrl: "views/voi/dialog/desktop/save_roam_tpl.html",
                    controller: "voiSaveRoamTplWinCtrl",
                    resolve: {
                        params: function () {
                            return {
                                selectRecord: item
                            };
                        }
                    }
                }).result.then(function (res) {
                    me.loadData()
                });
            };

            //查看桌面
            $scope.onClickView = function (item) {
                window.open("desktopScreenshot.html#" + item.id, "person_desktop_" + item.id);
            };

            //页面销毁后 清空定时器
            $scope.$on('$destroy', function () {
                if (me.intervalObj) {
                    $interval.cancel(me.intervalObj);
                    me.intervalObj = null;
                }
            });
        }
    ])
    //添加漫游桌面窗口控制器
    .controller('voiAddRoamDesktopWinCtrl', [
        '$scope', '$modal', '$modalInstance', '$http', '$q', 'params', 'i18n',
        function ($scope, $modal, $modalInstance, $http, $q, params, i18n) {
            let me = this;

            me.canceller = $q.defer();
            me.allDeskTops = [];
            me.ipModes = [
                {name: i18n.translate('不分配'), value: 'none'},
                {name: i18n.translate('系统分配'), value: 'auto'},
                {name: i18n.translate('固定IP'), value: 'static'}
            ];
            $scope.init = {
                stepIndex: 1
            };

            $scope.m = {
                resource_pool: null,
                network_id: null,
                subnet_id: null,
                usb_redir: true,
                usb_version: '2.0',
                gpu_auto_assignment: false,
                enable_share: false,
                servers: null,
                count: 0,
                servers_storage: [],
                vcpu: 2,
                ram: 3,
                start_ip: null,
                voi_desktops: null,
                share_server_ip: null,
                share_server_id: null
            };

            /**
             * 按记录中的某个字段分组
             * @param key
             * @param data
             * @returns {{}}
             */
            me.groupRecordBy = function (key, data, toArray = false) {
                let result = {};
                //以记录id为索要建立更新对像
                data.forEach(item => {
                    if (toArray) {
                        if (typeof result[item[key]] === 'undefined') {
                            result[item[key]] = [];
                        }
                        result[item[key]].push(item);
                    } else {
                        result[item[key]] = item;
                    }
                });
                return result;
            };
            //第一步选择桌面
            $scope.step1 = {
                desktops: [],
                shareServers: [],
                selectedNode: {},
                filterType : 'all',
                filtrateDesktopsData: function () {
                    let selectGroup = $scope.step1.selectedNode;
                    $scope.step1.desktops = angular.copy(me.allDeskTops);
                    if ($scope.step1.filterType === 'all' || !selectGroup) {
                        return;
                    }
                    $scope.step1.desktops = $scope.step1.desktops.filter(function (item) {
                        return item.user.id === selectGroup.id;
                    });

                },
                onSelectDesktop: function (item) {
                    let result = [];
                    item._isSelected = !item._isSelected;
                    angular.forEach($scope.step1.desktops, function (desktop) {
                        if (desktop._isSelected) {
                            result.push({
                                desktop_id: desktop.id,
                                user_id: desktop.user.id
                            });
                        }
                    });
                    $scope.m.voi_desktops = (result.length > 0) ? result : null;
                    $scope.m.count = result.length;
                },
                loadBaseData: function () {
                    $scope.init.isLoading = true;
                    $q.all([
                        $http.get('/thor/voi/personal/desktops'),
                        $http.get('/thor/resource'),
                        $http.get('/thor/networks'),
                        $http.get('/thor/share/servers')
                    ]).then(function (okRes) {
                        me.allDeskTops = okRes[0].data.result.filter(function (item) {
                            return !item.roam_instance && item.image.os_family === 'windows';
                        });
                        $scope.step1.desktops = angular.copy(me.allDeskTops);
                        $scope.step2.resources = okRes[1].data.result.filter(function (item) {
                            return item.hosts.length !== 0;
                        });
                        // if ($scope.step2.resources.length !== 0) {
                        //     $scope.step2.selectedResource = $scope.step2.resources[0];
                        //     $scope.step2.onChangeResource($scope.step2.selectedResource);
                        // }
                        $scope.step2.networks = okRes[2].data.networks;
                        if ($scope.step2.networks.length !== 0) {
                            $scope.step2.selectedNetwork = $scope.step2.networks[0];
                            $scope.step2.onChangeNetWork($scope.step2.selectedNetwork);

                        }

                        $scope.step3.shareServers = okRes[3].data.servers;
                        $scope.init.isLoading = false;
                    }, function () {
                        $scope.init.isLoading = false;
                    });
                },

                // 更换用户按钮
                onChangeUser: function () {
                    $modal.open({
                        size: "md",
                        templateUrl: "views/vdi/dialog/desktop/user-select-modal.html",
                        controller: 'voiUserSelectWinCtrl'
                    }).result.then(function (res) {
                        console.log(res);
                        $scope.step1.selectedNode = res.selectUser;
                        $scope.step1.filtrateDesktopsData();
                    });
                }
            };
            //第二步资源池和网络
            $scope.step2 = {
                resources: [],
                networks: [],
                subnets: [],
                selectedNetwork: null,
                selectedSubnet: null,
                selectedResource: null,
                ipModes: [],
                formatData: function (subnets) {
                    angular.forEach(subnets, function (item) {
                        item.name = item.name + '(' + item.start_ip + ' - ' + item.end_ip + ')';
                    });
                },
                onChangeResource: function (item) {
                    $scope.step2.selectedResource = null;
                    if (!item) {
                        return false;
                    }
                    $scope.step2.selectedResource = item;
                    $scope.m.resource_pool = item.id;
                    $scope.step4.loadHost();
                },
                onChangeNetWork: function (network) {
                    $scope.m.network_id = null;
                    if (!network) {
                        return false;
                    }
                    $scope.m.network_id = network.id;
                    $scope.step4.loadHost();
                    $scope.step2.loadSubnet(network.id);
                },
                onChangeSubnet: function (subnet) {
                    $scope.m.subnet_id = subnet.id;

                    $scope.step2.ipModes = angular.copy(me.ipModes);
                    $scope.step2.ipModes.shift();
                    if (subnet.id === 'none') {
                        $scope.step2.ipModes = [me.ipModes[0]];
                    }
                    $scope.m.band_type = $scope.step2.ipModes[0].value;
                },
                loadSubnet: function (networkId) {
                    $http.get('/thor/network/' + networkId + '/subnets')
                        .then(function (okRes) {
                            $scope.step2.formatData(okRes.data.result);
                            $scope.step2.subnets = okRes.data.result;
                            $scope.step2.subnets.unshift({name: i18n.translate('不分配'), id: 'none'});
                            $scope.step2.selectedSubnet = $scope.step2.subnets[0];
                            if ($scope.step2.subnets.length > 1) {
                                $scope.step2.selectedSubnet = $scope.step2.subnets[1];
                            }
                            $scope.step2.onChangeSubnet($scope.step2.selectedSubnet);
                        }, function (errRes) {
                        });
                }
            };

            $scope.step3 = {
                shareServers: []
            };
            //第四步界面逻辑
            $scope.step4 = {
                hosts: [],
                hostType: 0,
                maxDesktop: 0,
                isDesktopOk: null,
                isAllHost: false,
                hostsById: {},
                cfgsByHostId: {},
                loadHost: function () {
                    $scope.init.hosts = [];
                    if (!$scope.step2.selectedNetwork || !$scope.step2.selectedResource) {
                        return false;
                    }

                    $scope.init.isLoading = true;
                    $http.get('/thor/hosts/' + $scope.step2.selectedResource.id, {timeout: me.canceller.promise}, {
                        check_service: true,
                        enable_gpu: $scope.m.gpu_auto_assignment,
                        network_id: $scope.step2.selectedNetwork.id
                    }).then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.step4.hosts = okRes.data.hosts_list.filter(function (h) {
                            return h.status === "active"
                        });
                        $scope.step4.hostsById = me.groupRecordBy('id', $scope.step4.hosts);
                        $scope.step4.onChangeHostType();

                        $scope.step4.onSelectionChangeHost();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
                },

                //切换创建方式时清空所有选择和输入的数据
                onChangeHostType: function () {
                    angular.forEach($scope.step4.hosts, function (item) {
                        item._isSelected = false;
                        item.vm_count = 0;
                    });
                    $scope.m.servers = $scope.step4.getSelectedHost();

                    //$scope.m.count = 0;
                },
                //获取所有选中的宿主机信息
                getSelectedHost: function () {
                    let tmpItem, result = [], serversStorage = [];
                    $scope.step4.maxDesktop = 0;
                    //$scope.m.count = 0;
                    angular.forEach($scope.step4.hosts, function (item) {
                        tmpItem = {};
                        if ($scope.step4.hostType === 0) {
                            if (item._isSelected) {
                                tmpItem.uuid = item.id;
                                $scope.step4.maxDesktop = $scope.step4.maxDesktop + item.max_instance;
                                result.push(tmpItem);
                                serversStorage.push({
                                    uuid: item.id,
                                    host: item.host,
                                    storage_uuid: item.storage_uuid,
                                    image_storage_capacity: item.image_storage_capacity,
                                    image_storage_performance: item.image_storage_performance,
                                    storage_capacity: item.storage_capacity,
                                    storage_performance: item.storage_performance
                                })
                            }
                        } else {
                            if (item.vm_count) {
                                tmpItem.uuid = item.id;
                                tmpItem.vm_count = item.vm_count;
                                //$scope.m.count = $scope.m.count + item.vm_count;
                                result.push(tmpItem);
                                serversStorage.push({
                                    uuid: item.id,
                                    host: item.host,
                                    storage_uuid: item.storage_uuid,
                                    image_storage_capacity: item.image_storage_capacity,
                                    image_storage_performance: item.image_storage_performance,
                                    storage_capacity: item.storage_capacity,
                                    storage_performance: item.storage_performance
                                })
                            }
                        }
                    });
                    $scope.m.servers_storage = (serversStorage.length > 0) ? serversStorage : [];

                    $scope.step4.isDesktopOk = !($scope.m.count > $scope.step4.maxDesktop) ? true : null;
                    return (result.length > 0) ? result : null;
                },
                //点选宿主机时
                onSelectionChangeHost: function () {
                    $scope.m.servers = $scope.step4.getSelectedHost();
                    $scope.step4.isAllHost = ($scope.m.servers) ? ($scope.m.servers.length === $scope.step4.hosts.length) : false;
                },
                onChangeDesktopNum: function () {
                    $scope.m.servers = $scope.step4.getSelectedHost();
                },
                //勾选所有主机时
                selectAllHost: function (isAllSelect) {
                    angular.forEach($scope.step4.hosts, function (item) {
                        item._isSelected = isAllSelect;
                    });
                    $scope.step4.onSelectionChangeHost();
                },

                //打开主机配置窗口
                openHostConfigWin: function () {
                    let moreDialog = $modal.open({
                        templateUrl: "views/voi/dialog/desktop/host_config.html",
                        controller: "voiHostConfigWinCtrl",
                        resolve: {
                            param: function () {
                                return {
                                    selectedRecords: angular.copy($scope.m.servers_storage),
                                    cfgsByHostId: angular.copy($scope.step4.cfgsByHostId)
                                }
                            }
                        }
                    });
                    moreDialog.result.then(function (res) {
                        if (res) {

                            $scope.step4.getChangedHosts(res);

                        }
                    });
                },

                getChangedHosts: function (newConfig) {
                    let hostIds, key, localHost,
                        cfgsById = $scope.step4.cfgsByHostId;
                    if (!newConfig) {
                        return false;
                    }
                    Object.assign($scope.step4.cfgsByHostId, newConfig);
                    //获取所有配置中的主机id
                    hostIds = Object.getOwnPropertyNames(newConfig);
                    angular.forEach(hostIds, function (hostId) {
                        localHost = $scope.step4.hostsById[hostId];
                        //比较配置id与本地主机是否有改动
                        if (typeof localHost !== 'undefined') {
                            //在宿主机中建立一个判断字段，push进当前主机变化的字段做为标识
                            localHost.hasChangedKey = [];
                            localHost.newCfg = cfgsById[hostId];
                            for (key in localHost.newCfg) {
                                if ((key !== 'uuid') &&
                                    (localHost.newCfg[key] !== localHost[key])) {
                                    localHost.hasChangedKey.push(key);
                                }
                            }
                        }
                    });
                }


            };

            $scope.step1.loadBaseData();


            /**
             * 向导步骤切换
             * @param type
             */
            $scope.onClickChangePage = function (type) {
                if (type === 'prev') {
                    $scope.init.stepIndex--;
                } else {
                    $scope.init.stepIndex++;
                }

                //$scope.$apply();
            };

            $scope.ok = function () {
                let submitData, hostsById = $scope.step4.hostsById;
                $scope.init.isLoading = true;
                submitData = angular.copy($scope.m);
                angular.forEach(submitData.servers_storage, function (server) {
                    if (typeof hostsById[server.uuid] !== 'undefined') {
                        if (hostsById[server.uuid].hasChangedKey && hostsById[server.uuid].hasChangedKey.length > 0) {
                            angular.extend(server, hostsById[server.uuid].newCfg);
                        }
                    }
                });
                if (submitData.subnet_id === 'none') {
                    submitData.subnet_id = null;
                }

                $http.post('/thor/roam/instances', submitData)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //添加漫游桌面时存储配置子窗口控制器
    .controller('voiHostConfigWinCtrl', ['$scope', '$modalInstance', '$http', 'param',
        function ($scope, $modalInstance, $http, param) {
            let me = this,
                selectedRecords = param.selectedRecords,
                cfgsByHostId = param.cfgsByHostId || {};

            me.hostsById = {};
            me.resultData = {};

            $scope.n = {
                isLoading: false,
                hosts: [],
                storages: [],
                sysLuns: [],
                dataLuns: [],
                selectedHost: null,
                image_storage_performance: null,
                image_storage_capacity: null,
                storage_performance: null,
                storage_capacity: null
            };
            me.resultData = {};
            $scope.m = {};
            /**
             * 按记录中的某个字段分组
             * @param key
             * @param data
             * @returns {{}}
             */
            me.groupRecordBy = function (key, data, toArray = false) {
                let result = {};
                //以记录id为索要建立更新对像
                data.forEach(item => {
                    if (toArray) {
                        if (typeof result[item[key]] === 'undefined') {
                            result[item[key]] = [];
                        }
                        result[item[key]].push(item);
                    } else {
                        result[item[key]] = item;
                    }
                });
                return result;
            };
            $scope.n.hosts = angular.copy(selectedRecords);


            //切换时载入补充数据
            me.loadHostStorage = function (host) {
                $scope.n.isLoading = true;
                $http.get('/thor/list_storage_with_hosts', {params: {storage_hosts: host.storage_uuid}})
                    .then(function (okRes) {
                        $scope.n.isLoading = false;
                        //筛选主机并把主机的扩展信息更新到host列表
                        angular.forEach(okRes.data.result, function (item) {
                            item.storages.forEach(storage => {
                                storage._total_size = Math.round(storage.storage_metadata.capabilities.total_capacity_gb);
                                storage._free_size = Math.round(storage.storage_metadata.capabilities.free_capacity_gb);
                                storage._used_size = (storage._total_size - storage._free_size < 0) ? storage._total_size : storage._total_size - storage._free_size;
                            });
                            if (typeof me.hostsById[item.id] !== 'undefined') {
                                me.hostsById[item.id].storages = item.storages;
                            }

                        });
                        //载入数据后设置默认选择
                        if (typeof me.hostsById[host.uuid] !== 'undefined') {
                            $scope.n.image_storage_performance = me.hostsById[host.uuid].storages.filter(storage => {

                                return storage.uuid === me.hostsById[host.uuid].image_storage_performance;
                            })[0];
                            $scope.n.image_storage_capacity = me.hostsById[host.uuid].storages.filter(storage => {
                                return storage.uuid === me.hostsById[host.uuid].image_storage_capacity;
                            })[0];
                            $scope.onChangeStorage($scope.n.image_storage_performance, 'sysLuns');
                            $scope.onChangeStorage($scope.n.image_storage_capacity, 'dataLuns');
                        }
                    }, function (errRes) {
                        $scope.n.isLoading = false;
                    });
            };
            //切换主机，载入补充数据
            $scope.onChangeHost = function () {
                //$scope.n.selectedHost = null;
                if (!$scope.n.selectedHost) {
                    return false;
                }
                let host = $scope.n.selectedHost;
                //$scope.n.selectedHost
                if (!host.storages) {
                    me.loadHostStorage(host);
                    return false;
                }
                $scope.n.image_storage_performance = host.storages.filter(function (storage) {
                    return storage.uuid === host.image_storage_performance;
                })[0];
                $scope.n.image_storage_capacity = host.storages.filter(function (storage) {
                    return storage.uuid === host.image_storage_capacity;
                })[0];
                $scope.onChangeStorage($scope.n.image_storage_performance, 'sysLuns');
                $scope.onChangeStorage($scope.n.image_storage_capacity, 'dataLuns');
            };
            //切换存储
            $scope.onChangeStorage = function (storage, type) {
                let selectStorage;
                if (!storage) {
                    return false;
                }
                /*
                if (angular.isArray($scope.n.selectedHost[type])) {
                    selectStorage = $scope.n.selectedHost[type].filter(function (item) {
                        if (type === 'sysLuns') {
                            return item.uuid === $scope.n.selectedHost.storage_performance;
                        }
                        if (type === 'dataLuns') {
                            return item.uuid === $scope.n.selectedHost.storage_capacity;
                        }
                    })[0];
                    if (type === 'sysLuns') {
                        $scope.n.storage_performance = selectStorage;
                    }
                    if (type === 'dataLuns') {
                        $scope.n.storage_capacity = selectStorage;
                    }
                    return false;
                }
                */

                let node_uuid = storage.node_uuid;
                if (storage.device_type === "glusterfs") {
                    node_uuid = $scope.n.selectedHost.storage_uuid
                }
                $http.get('/thor/filter_available_storages', {
                    params: {
                        device_type: storage.device_type,
                        node_uuid: node_uuid,
                        storage_id: storage.uuid
                    }
                }).then(function (okRes) {

                    okRes.data.result.forEach(storage => {
                        storage._total_size = Math.round(storage.storage_metadata.capabilities.total_capacity_gb);
                        storage._free_size = Math.round(storage.storage_metadata.capabilities.free_capacity_gb);
                        storage._used_size = (storage._total_size - storage._free_size < 0) ? storage._total_size : storage._total_size - storage._free_size;
                    });

                    $scope.n.selectedHost[type] = okRes.data.result;

                    if ($scope.n.selectedHost[type].length > 0) {

                        /*
                        selectStorage = $scope.n.selectedHost[type].filter(function (item) {
                            if (type === 'sysLuns') {
                                return item.uuid === $scope.n.selectedHost.storage_performance;
                            }
                            if (type === 'dataLuns') {
                                return item.uuid === $scope.n.selectedHost.storage_capacity;
                            }
                        })[0];
                        if (type === 'sysLuns') {
                            $scope.n.storage_performance = selectStorage;
                        }
                        if (type === 'dataLuns') {
                            $scope.n.storage_capacity = selectStorage;
                        }
                        */
                        if (type === 'sysLuns')
                            $scope.n.storage_performance = ($scope.n.selectedHost['sysLuns'].filter(function (item) {
                                return item.uuid === $scope.n.selectedHost.storage_performance
                            })[0]) || $scope.n.selectedHost['sysLuns'][0];
                        if (type === 'dataLuns')
                            $scope.n.storage_capacity = ($scope.n.selectedHost['dataLuns'].filter(function (item) {
                                return item.uuid === $scope.n.selectedHost.storage_capacity
                            })[0]) || $scope.n.selectedHost['dataLuns'][0];

                    }
                }, function (errRes) {
                })
            };

            if ($scope.n.hosts && $scope.n.hosts.length !== 0) {

                //将配置覆盖本身，用于回显
                $scope.n.hosts.forEach(host => {
                    if (typeof cfgsByHostId[host.uuid] !== 'undefined') {
                        Object.assign(host, cfgsByHostId[host.uuid]);
                    }
                });
                $scope.n.selectedHost = $scope.n.hosts[0];
                me.hostsById = me.groupRecordBy('uuid', $scope.n.hosts);
                $scope.onChangeHost($scope.n.selectedHost);

            }


            //当点击保存时把数据写入当前已选择的主机
            $scope.save = function () {

                let selectedHost = $scope.n.selectedHost;
                selectedHost.storage_capacity = $scope.n.storage_capacity ? $scope.n.storage_capacity.uuid : null;
                selectedHost.storage_performance = $scope.n.storage_performance ? $scope.n.storage_performance.uuid : null;
                selectedHost.image_storage_capacity = $scope.n.image_storage_capacity ? $scope.n.image_storage_capacity.uuid : null;
                selectedHost.image_storage_performance = $scope.n.image_storage_performance ? $scope.n.image_storage_performance.uuid : null;
            };

            $scope.ok = function () {
                $scope.save();

                let allHosts = $scope.n.hosts,
                    result = {};

                //把所有设置放入返回的对像中
                angular.forEach(allHosts, function (host) {
                    result[host.uuid] = {
                        storage_capacity: host.storage_capacity,
                        storage_performance: host.storage_performance,
                        image_storage_capacity: host.image_storage_capacity,
                        image_storage_performance: host.image_storage_performance,
                        uuid: host.uuid
                    };
                });
                $modalInstance.close(result);
            };

            $scope.close = function () {
                $modalInstance.close();
            };


        }])
    //编辑个人桌面窗口控制器
    .controller('voiEditRoamDesktopWinCtrl', [
        '$scope', '$modalInstance', '$http', '$modal', '$q', 'params', 'i18n',
        function ($scope, $modalInstance, $http, $modal, $q, params, i18n) {
            let me = this, key;
            me.ipModes = [
                {name: i18n.translate('不分配'), value: 'none'},
                {name: i18n.translate('系统分配'), value: 'auto'},
                {name: i18n.translate('固定IP'), value: 'static'}
            ];

            $scope.init = {
                isLoading: false,
                dataDisks: [],
                extra_data_restore: null,
                user: null,
                ipModes: []
            };

            $scope.m = {
                attach_volumes: [],
                display_name: null,
                enable_share: false,
                expand_enabled: false,
                gpu_auto_assignment: false,
                id: null,
                ip: null,
                memory_mb: 0,
                network_id: null,
                rollback: 1,
                rollback_weekday: null,
                rollback_monthday: null,
                data_rollback: 1,
                data_rollback_weekday: null,
                data_rollback_monthday: null,
                subnet_id: null,
                usb_redir: true,
                usb_version: '2.0',
                user_id: null,
                vcpu: 2,
                vm_hostname: null
            };

            me.selectRecord = angular.copy(params.selectRecord);

            $scope.init.user = me.selectRecord.user;

            me.loadBaseData = function () {
                $scope.init.isLoading = true;
                $q.all([
                    $http.get('/thor/get_instance_details/' + me.selectRecord.id),
                    $http.get('/thor/networks')
                ]).then(function (okRes) {
                    $scope.init.isLoading = false;
                    angular.extend(me.selectRecord, okRes[0].data.result);
                    $scope.init.networks = okRes[1].data.networks;
                    for (key in $scope.m) {
                        if (me.selectRecord.hasOwnProperty(key)) {
                            $scope.m[key] = me.selectRecord[key];
                        }
                    }
                    $scope.m.memory_mb = $scope.m.memory_mb / 1024;
                    $scope.init.selectedNetwork = okRes[1].data.networks.filter(function (item) {
                        return item.id === me.selectRecord.network.id;
                    })[0];
                    if (!$scope.init.selectedNetwork) {
                        $scope.init.selectedNetwork = $scope.init.networks[0];
                    }
                    $scope.onChangeNetWork($scope.init.selectedNetwork);
                }, function (errRes) {
                    $scope.init.isLoading = false;
                });

            };
            me.loadBaseData();

            me.formatData = function (subnets) {
                angular.forEach(subnets, function (item) {
                    item.name = item.name + '(' + item.start_ip + ' - ' + item.end_ip + ')';
                });
            };

            me.loadSubnet = function (networkId) {
                $scope.init.isLoading = true;
                $http.get('/thor/network/' + networkId + '/subnets')
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        me.formatData(okRes.data.result);
                        $scope.init.subnets = okRes.data.result;
                        $scope.init.subnets.unshift({name: i18n.translate('不分配'), id: 'none'});


                        $scope.init.selectedSubnet = okRes.data.result.filter(function (item) {
                            return item.id === me.selectRecord.subnet_id;
                        })[0];
                        if (!$scope.init.selectedSubnet) {
                            $scope.init.selectedSubnet = $scope.init.subnets.length > 1 ? $scope.init.subnets[1] : $scope.init.subnets[0];
                        }
                        if (!me.selectRecord.subnet_id) {
                            $scope.init.selectedSubnet = $scope.init.subnets[0];
                        }
                        me.selectRecord.subnet_id = null;
                        $scope.onChangeSubnet($scope.init.selectedSubnet);
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };

            $scope.onChangeNetWork = function (network) {
                $scope.m.network_id = null;
                if (!network) {
                    return false;
                }
                $scope.m.network_id = network.id;

                me.loadSubnet(network.id);
            };
            $scope.onChangeSubnet = function (subnet) {
                $scope.m.subnet_id = null;
                $scope.m.band_type = 'none';
                $scope.m.ip = null;
                if (!subnet) {
                    return false;
                }
                $scope.m.subnet_id = subnet.id;
                $scope.init.ipModes = angular.copy(me.ipModes);
                $scope.init.ipModes.shift();
                if (subnet.id === 'none') {
                    $scope.init.ipModes = [me.ipModes[0]];
                }
                $scope.m.band_type = $scope.init.ipModes[0].value;

                $scope.m.ip = me.selectRecord.ips;
                if ($scope.m.ip) {
                    $scope.m.band_type = 'static';
                    me.selectRecord.ips = null;
                }

            };

            //提交表单数据
            me.submitForm = function (submitData) {
                $scope.init.isLoading = true;
                $http.put('/thor/instance/' + me.selectRecord.id, submitData)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };

            $scope.ok = function () {
                let submitData;
                submitData = angular.copy($scope.m);
                submitData.memory_mb = submitData.memory_mb * 1024;
                if (submitData.subnet_id === 'none') {
                    submitData.subnet_id = null;
                }

                if (submitData.band_type === 'auto') {
                    submitData.ip = '';
                }
                me.submitForm(submitData);
            };
            $scope.close = function () {
                if (me.treeInterval) {
                    clearInterval(me.treeInterval);
                }
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
    //移动窗口控制器
    .controller("voiMoveRoamWinCtrl", [
        '$scope', '$modalInstance', '$http', 'param',
        function ($scope, $modalInstance, $http, param) {

            //离线迁移获取主机URL
            let getHostUrl = '/thor/ha/instance/move';

            $scope.init = {
                isLoading: false,
                hosts: [],
                winType: false
            };
            $scope.m = {
                host: null,
                instance_ids: []
            };

            //true 动态迁移 / false 移动
            $scope.init.winType = param.winType;
            $scope.m.instance_ids = param.instanceIds;
            $scope.init.isLoading = true;

            if ($scope.init.winType) {
                getHostUrl = '/thor/ha/instance/live/move';
            }

            $http.get(getHostUrl, {
                params: {
                    instance_ids: $scope.m.instance_ids
                }
            }).then(function (okRes) {
                $scope.init.hosts = okRes.data.result;
                if ($scope.init.hosts.length !== 0) {
                    $scope.m.host = $scope.init.hosts[0];
                }
                $scope.init.isLoading = false;
            }, function (errRes) {
                $scope.init.isLoading = false;
            });


            $scope.ok = function () {
                let submitUrl = '/thor/ha/instances/move';

                $scope.init.isLoading = true;
                if ($scope.init.winType) {
                    submitUrl = '/thor/ha/instance/live/move';
                }
                $http.post(submitUrl, $scope.m)
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                $modalInstance.dismiss();
            };
        }])
    //帐号选择框
    .controller("voiUserSelectWinCtrl", [
        '$scope', '$modalInstance',
        function ($scope, $modalInstance) {
            $scope.m = {
                selectUser: null
            };
            $scope.ok = function () {
                $modalInstance.close($scope.m);
            };
            $scope.close = function () {
                $modalInstance.close();
            }
        }])
    //另存为模板窗口控制器
    .controller('voiSaveRoamTplWinCtrl', [
        '$scope', '$modalInstance', '$http', '$modal', '$q', 'params', 'i18n',
        function ($scope, $modalInstance, $http, $modal, $q, params, i18n) {
            let me = this, key;

            me.ipModes = [
                {name: i18n.translate('不分配'), value: 'none'},
                {name: i18n.translate('系统分配'), value: 'auto'},
                {name: i18n.translate('固定IP'), value: 'static'}
            ];

            $scope.init = {
                isLoading: false,
                hosts: [],
                extra_data_restore: null,
                users: [],
                ipModes: [],
                selectedUser: null,
                selectedSubnet: null,
                selectedNetwork: null
            };

            $scope.m = {
                band_type: 'auto',
                display_name: null,
                description: null,
                host_uuid: null,
                instance_id: null,//虚拟机ID
                image_id: null,//模板id
                name: null,
                network: null,
                owner: null,
                subnet: null,
                type: 1,
                band_ip: null,
                //class_refers: [],//教学模板才需要
                product_type: 'vdi',
                os: ''
            };

            me.selectRecord = angular.copy(params.selectRecord);


            me.loadBaseData = function () {

                $scope.init.isLoading = true;

                $q.all([
                    $http.get('/thor/get_instance_details/' + me.selectRecord.id),
                    $http.get('/thor/user/manager'),
                    $http.get('/thor/hosts_with_virtual_type', {
                        params: {
                            virtual_type: me.selectRecord.virtual_type,
                            rbd_enabled: me.selectRecord.rbd_enabled
                        }
                    })
                ]).then(function (okRes) {
                    $scope.init.isLoading = false;
                    angular.extend(me.selectRecord, okRes[0].data.result);
                    for (key in $scope.m) {
                        if (me.selectRecord.hasOwnProperty(key)) {
                            $scope.m[key] = me.selectRecord[key];
                        }
                    }

                    $scope.m.os = me.selectRecord.os_type;
                    $scope.init.users = okRes[1].data.users;
                    $scope.init.hosts = okRes[2].data.result;

                    $scope.init.selectedUser = $scope.init.users.filter(function (item) {
                        return item.id === me.selectRecord.user_id;
                    })[0];

                    if (!$scope.init.selectedUser) {
                        $scope.init.selectedUser = $scope.init.users[0];
                    }
                    $scope.m.owner = $scope.init.selectedUser.id;
                    if ($scope.init.hosts.length > 0) {
                        $scope.onChangeHost($scope.init.hosts[0].host_uuid);
                    }


                }, function (errRes) {
                    $scope.init.isLoading = false;
                });

            };
            me.loadBaseData();

            me.formatData = function (subnets) {
                angular.forEach(subnets, function (item) {
                    item.name = item.name + '(' + item.start_ip + ' - ' + item.end_ip + ')';
                });
            };

            me.loadNetwork = function (hostId) {
                $scope.init.isLoading = true;
                $http.get('/thor/list_network_with_host', {
                    params: {
                        host: hostId
                    }
                }).then(function (okRes) {
                    $scope.init.isLoading = false;
                    $scope.init.networks = okRes.data.result;
                    $scope.init.selectedNetwork = okRes.data.result.filter(function (item) {
                        return item.id === me.selectRecord.network.id;
                    })[0];
                    if (!$scope.init.selectedNetwork) {
                        $scope.init.selectedNetwork = $scope.init.networks[0];
                    }
                    $scope.onChangeNetWork($scope.init.selectedNetwork);

                }, function (errRes) {
                    $scope.init.isLoading = false;
                });
            };
            me.loadSubnet = function (networkId) {
                $scope.init.isLoading = true;
                $http.get('/thor/network/' + networkId + '/subnets')
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        me.formatData(okRes.data.result);
                        $scope.init.subnets = okRes.data.result;
                        $scope.init.subnets.unshift({name: i18n.translate('不分配'), id: 'none'});

                        $scope.init.selectedSubnet = okRes.data.result.filter(function (item) {
                            return item.id === me.selectRecord.subnet_id;
                        })[0];
                        if (!$scope.init.selectedSubnet) {
                            $scope.init.selectedSubnet = $scope.init.subnets.length > 1 ? $scope.init.subnets[1] : $scope.init.subnets[0];
                        }
                        if (!me.selectRecord.subnet_id) {
                            $scope.init.selectedSubnet = $scope.init.subnets[0];
                        }
                        me.selectRecord.subnet_id = null;
                        $scope.onChangeSubnet($scope.init.selectedSubnet);
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };


            $scope.onChangeHost = function (hostId) {

                if (!hostId) {
                    return false;
                }

                $scope.m.host_uuid = hostId;

                me.loadNetwork(hostId);
            };

            $scope.onChangeNetWork = function (network) {
                $scope.m.network = null;
                if (!network) {
                    return false;
                }
                $scope.m.network = network.id;

                me.loadSubnet(network.id);

            };

            $scope.onChangeSubnet = function (subnet) {
                $scope.m.subnet = null;
                $scope.m.band_type = 'none';
                $scope.m.band_ip = null;
                if (!subnet) {
                    return false;
                }
                $scope.m.subnet = subnet.id;
                $scope.init.ipModes = angular.copy(me.ipModes);
                $scope.init.ipModes.shift();
                if (subnet.id === 'none') {
                    $scope.init.ipModes = [me.ipModes[0]];
                }
                $scope.m.band_type = $scope.init.ipModes[0].value;

                /*$scope.m.band_ip = me.selectRecord.ips;
                if ($scope.m.band_ip) {
                    $scope.m.band_type = 'static';
                    me.selectRecord.ips = null;
                }*/
            };


            $scope.ok = function () {
                let submitData;
                submitData = angular.copy($scope.m);
                $scope.init.isLoading = true;
                if (submitData.subnet === 'none') {
                    submitData.subnet = null;
                }

                if (submitData.type * 1 === 1) {
                    submitData.class_refers = [];
                }
                if (submitData.type * 1 === 3) {
                    submitData.class_refers = [];
                    submitData.product_type = '3v';
                    submitData.type = 1;
                }
                //2019-07-02换胡海新接口
                $http.post('/api/images', {data: submitData})
                    .then(function (okRes) {
                        $scope.init.isLoading = false;
                        $scope.close();
                    }, function (errRes) {
                        $scope.init.isLoading = false;
                    });
            };
            $scope.close = function () {
                if (me.treeInterval) {
                    clearInterval(me.treeInterval);
                }
                if ($scope.init.isLoading) {
                    return false;
                }
                $modalInstance.close();
            };
        }
    ])
;


