angular.module("vdi", [])
    .factory("Task", ["$resource", function ($resource) {
        return $resource( "/thor/home/tasklog", null, {
            query: {method: "GET", isArray: false},
            post: {method: "POST"},
            put: {method: "PUT"}
        });
    }])


    .factory("VNC", ["$resource", function ($resource) {
        return $resource( "/thor/instance/vnc/:id", {id: "@id"}, {
            loadISO:
                {method: "POST", url:  "/thor/image/loadISO"},
            save:
                {method: "POST", url:  "/thor/image/update_template"}
        });
    }])

    .factory("loginResource", ["$resource", function ($resource) {
        return $resource( "/thor/version", null, {
            query: {method: "GET"}
        })
    }])

    .factory("MessageBox", ["$modal", function ($modal) {
        let MessageBox = {};
        MessageBox.confirm = function (content, title) {
            let modalInstance = $modal.open({
                template: `
                <section>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <button type='button' class='close' data-ng-click='close(2)'>
                                <span aria-hidden='true'>×</span>
                                <span class='sr-only'>Close</span>
                            </button>
                            <h4 class='modal-title'>${title}</h4>
                        </div>
                        <div class='modal-body'>
                            <form class='form-horizontal'>
                                <p style='margin-bottom:10px;'>${content}</p>
                                <footer class='text-right'>
                                    <button class='btn btn-default ' data-ng-click='close(1)' localize='确定'></button>
                                    <button class='btn btn-default' data-ng-click='close(0)' style='margin-left:5px;' localize='取消'></button>
                                </footer>
                            </form>
                        </div>
                    </div>
                </section>
`,
                controller: function ($scope, $modalInstance) {
                    $scope.close = function (from) {
                        let res = from === 1;
                        $modalInstance.close(res, from); // 实测只能传递一个值
                    };
                },
                size: "sm"
            });
            return modalInstance;
        }
        return MessageBox;
    }])

    .filter('lun_name', function () {
        return function (lun) {
            if (!angular.isUndefined(lun)) {
                lun.map(function (item) {
                    item.value = item.vendor + " lun-" + item.lun + " " + item.size;
                });
            }
            return lun;
        };
    })
    .filter('storage_type', function () {
        var type2str = {
            local: "本地磁盘",
            iscsi: 'iscsi 磁盘',
            netfs: '网络文件系统',
            fc: 'FC 光纤存储'
        };
        return function (type) {
            return type2str[type]
        }
    })
    .filter('storage_status', function () {
        var stauts2str = {
            running: "正常",
            building: "准备中",
            error: '异常'
        };
        return function (stauts) {
            return stauts2str[stauts]
        }
    })
    .filter('unsafe', function ($sce) {
        return function (val) {
            return $sce.trustAsHtml(val + "");
        };
    })
    .filter('join', function () {
        return function (val, slash) {
            return val.filter(function (d) {
                return d;
            }).join(slash)
        };
    })
    .filter('network_type', function () {
        var type2str = {
            nat: 'NAT',
            bridge: '桥接',
            vlan: 'VLAN'
        };
        return function (val) {
            return type2str[val];
        };
    })
    .filter('yesorno', function () {
        return function (val) {
            return val ? '是' : '否';
        };
    })
    .filter('to_mb', function () {
        return function (val) {
            return (val / 1024 / 1024).toFixed(2);
        };
    })
    .filter('reverse', function () {
        return function (input, searchText, searchName) {
            if (input && searchText) {
                var outPut = [];
                outPut = input.filter(function (item) {
                    if (item[searchName].indexOf(searchText) > -1)
                        return item;
                })
                return outPut;
            }
            return input;
        };
    })
    .config(["$filterProvider", function ($filterProvider) {
        $filterProvider.register("paging", function () {
            return function (items, index, pageSize) {
                if (!angular.isArray(items)) {
                    return items;
                }
                if (pageSize > 0 && index > 0) {
                    var total = items.length;
                    var totalPage = Math.ceil(total / pageSize);
                    index = Math.min(totalPage, Math.max(1, index));
                    return items.slice((index - 1) * pageSize, index * pageSize);
                }
                return items;
            };
        });
    }])

    .directive("dialog", ["uihelper", function (uihelper) {
        return {
            restrict: "A",
            link: function ($scope, element, attrs) {
                let dialog;
                element.click(function () {
                    if (attrs.disabled) {
                        uihelper.alert(attrs.error);
                    } else {
                        if (dialog) {
                            return;
                        }
                        dialog = uihelper.openModal({
                            templateUrl: "views/vdi/dialog/" + attrs.dialogUrl,
                            controller: attrs.dialog,
                            scope: $scope,
                            size: attrs.dialogSize
                        });
                        dialog.result.finally(function () {
                            dialog = null;
                            $scope.$emit("dialog-closed");
                        });
                    }
                });
                $scope.$on("$destroy", function () {
                    dialog && dialog.dismiss();
                });
            }
        };
    }])
    // 添加注释：这里的分页指令（pagination指令）引用：是在includes/pagination.html 中应用的
    // （pagination指令）的实现：使用的是库里面的js/libs/ui-bootstrap-custom-tpls-0.11.0.js     selectPage
    //  关键需要传递过去的是 changePage
    // 这里的logPageChange相关代码是为了兼容 logs 页面后端分页
    .directive("widgetGrid", ["$filter", function ($filter) {
        function getPosition(e, ele) {
            var st = Math.max(
                document.documentElement.scrollTop,
                document.body.scrollTop
            );
            var sl = Math.max(
                document.documentElement.scrollLeft,
                document.body.scrollLeft
            );
            var cw = document.documentElement.clientWidth;
            var ch = document.documentElement.clientHeight;
            var ow = ele.offsetWidth;
            var oh = ele.offsetHeight;
            return {
                x: Math.max(0, e.pageX + ow > sl + cw ? sl + cw - ow : e.pageX),
                y: Math.max(0, e.pageY + oh > st + ch ? st + ch - oh : e.pageY)
            }
        }

        return {
            restrict: "A",
            controller: function ($scope) {
                "ngInject";
                this.getCurrentPage = function () {
                    return Number($scope.currentPage) > 0 ? $scope.currentPage : 0;
                };
                this.getCurrentRows = function () {
                    return $scope.getCurrentRows();
                }
                this.getPageSize = function () {
                    return Number($scope.pagesize) > 0 ? Number($scope.pagesize) : 0;
                };
            },
            link: function ($scope, element, attrs) {
                var context_wrapper = element.find(".context_wrapper");
                context_wrapper.on("mousedown", function (e) {
                    if (e.target === this) {
                        context_wrapper.hide();
                        element.find(".contextmenu_selected").removeClass("contextmenu_selected");
                    }
                }).on("click", function () {
                    context_wrapper.hide();
                    element.find(".contextmenu_selected").removeClass("contextmenu_selected");
                }).on("contextmenu", function (e) {
                    e.preventDefault();
                });
                context_wrapper.hide();
                // $scope.searchText = "";
                //$scope.pagesize = 5;
                $scope.currentPage = 1;

                $scope.getCurrentRows = function () {
                    return $filter("paging")(
                        $scope.getFilterRows(),
                        $scope.currentPage, $scope.pagesize
                    );
                };
                $scope.getFilterRows = function () {
                    return $filter("filter")($scope.rows || [], $scope.searchText);
                };

                $scope.checkAll = function () {
                    var rows = $scope.getCurrentRows();
                    var _all = rows.length && rows
                        .filter(item => !item._ignore).length && rows
                        .filter(item => !item._ignore)
                        .every(row => row._selected);
                    $scope.checkedAll = _all;
                    return _all;
                };
                $scope.selectAllChange = function (checkAll) {
                    var rows = $scope.getCurrentRows();
                    rows.filter(item => !item._ignore && !item.disabled).forEach(function (row) {
                        row._selected = checkAll;
                    });
                    $scope.checkedAll = checkAll;
                };
                let filterFn = item => !item._ignore && item._selected;
                // 获取当前勾选
                $scope.getCheckedRows = function(){
                    var rows = $scope.getCurrentRows();
                    return rows.filter(filterFn);
                };
                $scope.checkOne = function () {
                    var rows = $scope.getCurrentRows();
                    return rows.filter(item => !item._ignore).some(function (row) {
                        return row._selected;
                    });
                };
                $scope.checkOnlyOne = function () {
                    var rows = $scope.getCurrentRows();
                    return rows.filter(item => !item._ignore && item._selected).length == 1;
                };
                $scope.sort = function (name, asc) {
                    $scope.rows.sort(function (a, b) {
                        return (a[name] > b[name] ? 1 : -1) * (asc ? 1 : -1);
                    });
                };
                let pageChangeCb = null;
                if ($scope.pageChange) {
                    pageChangeCb = $scope.pageChange;
                    $scope.paginationType = 1;
                }
                $scope.pageSizeChange =
                    $scope.pageChange = function () {
                        pageChangeCb && pageChangeCb();
                        $scope.rows.forEach(function (item, i) {
                            item._selected = false;
                        });
                    };
                $scope.currentItem = null;
                $scope.$on("contextmenu", function (e, item, de, el) {
                    // 添加如果当前行中的checkbox控件是disabled的状态或者_ignore时，直接return
                    // let isRowDisabled = el.find("input").prop("disabled");
                    if (item._ignore) return;
                    $scope.currentItem = item;
                    el.addClass("contextmenu_selected");
                    $scope.rows.forEach(function (item) {
                        item._selected = false;
                    });
                    $scope.$apply();
                    context_wrapper.fadeIn(200);
                    var menu = element.find(".grid_context_menu");
                    var offset = context_wrapper.offset();
                    var pos = getPosition(de, menu[0]);
                    menu.css({
                        top: pos.y - offset.top + "px",
                        left: pos.x - offset.left + "px"
                    });
                    $scope.rows.forEach(function (item) {
                        item._selected = false;
                    });
                    item._selected = true;
                    $scope.$apply();
                    e.stopPropagation();
                    de.preventDefault();
                });
            }
        };
    }])
    .directive("gridPagination", [function () {
        return {
            restrict: "A",
            require: ["^widgetGrid"],
            conroller: function ($scope) {

            },
            link: function ($scope, element, attrs, ctrls) {
                var grid = ctrls[0];
                let paginationType = 0;
                if ($scope.paginationType) {
                    paginationType = 1;
                }
                $scope.getStart = function () {
                    var current = grid.getCurrentPage();
                    var pagesize = grid.getPageSize();
                    return pagesize > 0 ? (current - 1) * pagesize + 1 : 0;
                };
                $scope.getEnd = function () {
                    var pagesize = grid.getPageSize();
                    if (!paginationType) {
                        var current = $scope.currentPage;
                        var currentCount = $scope.getFilterRows().length;
                        var end = pagesize ? current * pagesize : currentCount;
                        return end < currentCount ? end : currentCount;
                    } else {
                        let total = $scope.totalCount || 0;
                        if(total) {
                            let start = ($scope.getStart() - 1);
                            if ((total - start) < pagesize) {
                                return start + (total - start);
                            } else {
                                return (start + pagesize);
                            }
                        }
                        return 0;
                    }
                };
                $scope.getCurrentCount = function () {
                    return $scope.getCurrentRows().length;
                };
            }
        }
    }])
    .directive("helpTip", ["$location", function ($location) {
        return {
            restrict: "A",
            link: function ($scope, element) {
                var updateTip = function () {
                    var path = $location.$$path;
                    function getSceneTipKey (pKey, key, localKey) {
                        let isIdv = $$$storage.getSessionStorage(localKey) == key;
                        if (isIdv) {
                            $scope.tipKey = `${pKey}?kw=${key}`;
                        } else {
                            $scope.tipKey = pKey;
                        }
                    }
                    $("#content").on("click", ".nav.nav-tabs li", function () {
                        if (/^\/terminal\/client\/?$/.test(path)) {
                            getSceneTipKey("/terminal/client", "voi", "TERMINAL_TAB");
                        }
                        if (/^\/desktop\/scene\/?$/.test(path)) {
                            getSceneTipKey("/desktop/scene", "idv", "SCENE_TAB");
                        }
                    });
                    if (/^\/resource\/network\/\d+\/?$/.test(path)) {
                        path = "/resource/network/:id";
                    } else if (/^\/desktop\/teach\/\d+\/?$/.test(path)) {
                        path = "/desktop/teach/:id";
                    } else if (/^\/terminal\/client\/?$/.test(path)) {
                        getSceneTipKey("/terminal/client", "voi", "TERMINAL_TAB");
                    } else if (/^\/desktop\/scene\/?$/.test(path)) {
                        getSceneTipKey("/desktop/scene", "idv", "SCENE_TAB");
                    }
                    $scope.tipKey = path;
                    // 隐藏正在显示的 popover
                    element.popover("hide");
                };
                $scope.$on("$routeChangeSuccess", updateTip);
                updateTip();
            }
        };
    }])
    .directive("ribbonTips", ["i18n", function (i18n) {
        return {
            restrict: "A",
            link: function ($scope, element, attrs) {
                var fn_update_help_info = function () {
                    var help_text = i18n.translate(attrs.myTips);
                    element.attr("data-content", help_text);
                    if (help_text) {
                        element.parent().show();
                    } else {
                        element.parent().hide();
                    }
                };
                $scope.$on("$routeChangeSuccess", function () {
                    fn_update_help_info();
                });
                fn_update_help_info();
            }
        };
    }])
    .directive("contextmenu", [function () {
        return {
            restrict: "A",
            link: function ($scope, element, attrs) {
                if (attrs.contextmenuDisabled !== "true") {
                    element.bind("contextmenu", function (e) {
                        $scope.$emit(attrs.contextmenuEventName || "contextmenu", $scope.item, e, element);
                    });
                }
            }
        };
    }])

    .directive("wizard", [function () {
        return {
            restrict: "A",
            transclude: true,
            scope: {
                lastText: "@",
                btnUnable: "="
            },
            controller: function ($scope, i18n) {
                "ngInject";
                var steps = $scope.steps = [];
                $scope.currentStep = null;
                $scope.moveWth = 0;
                var defaults = {
                    prevBtnText: "上一步",
                    nextBtnText: "下一步",
                    doneBtnText: "完成"
                };
                $scope.$on("currentStepChange", function (e, stepIndex) {
                    $scope.go(stepIndex);
                });
                $scope.select = function (step) {
                    var index;
                    steps.forEach(function (s, i) {
                        s.selected = s === step;
                        if (s.selected) {
                            index = i;
                        }
                    });
                    $scope.currentStep = step;
                    ["prev", "next", "done"].forEach(function (s) {
                        var key = s + "BtnText";
                        $scope[key] = i18n.translateText(step[key] || defaults[key]);
                    });
                    $scope.$emit("selectStepChange", {index: index, stepScope: step});
                };
                $scope.getCurrentIndex = function () {
                    return steps.indexOf($scope.currentStep);
                };

                $scope.prev = function () {
                    var index = $scope.getCurrentIndex();
                    //var e = $scope.$emit(($scope.stepEventName || "WizardStep"), $scope.currentStep);
                    var prev = steps[index - 1];
                    prev && $scope.select(prev);
                    $scope.moveWth = $scope.getMarginValue();

                };
                $scope.next = function () {
                    var index = $scope.getCurrentIndex();
                    $scope.currentStep.is_dirty = true;
                    var e = $scope.$emit(($scope.stepEventName || "WizardStep") + "_" + index, $scope.currentStep, $scope.currentStep.$$nextSibling);
                    // 不能下一步的条件
                    if ($scope.currentStep.done !== false) {
                        var next = steps[index + 1];
                        next && $scope.select(next);
                        $scope.moveWth = $scope.getMarginValue();
                    }

                };
                $scope.go = function (index) {
                    $scope.select(steps[index]);
                    $scope.moveWth = $scope.getMarginValue();
                }
                $scope.showPrev = function () {
                    return steps.indexOf($scope.currentStep) > 0 && $scope.currentStep.prevBtnText !== "";
                };
                $scope.isLast = function () {
                    return steps.indexOf($scope.currentStep) >= steps.length - 1;
                };
                $scope.done = function () {
                    var index = $scope.getCurrentIndex();
                    $scope.currentStep.is_dirty = true;
                    var e = $scope.$emit(($scope.stepEventName || "WizardStep") + "_" + index, $scope.currentStep, $scope.currentStep.$$nextSibling);
                    if ($scope.currentStep.done !== false) {
                        var next = steps[index + 1];
                        next && $scope.select(next);
                        $scope.$emit($scope.doneEventName || "WizardDone", steps, steps.map(function (step) {
                            return step.$$nextSibling
                        }));
                    }
                };
                this.addStep = function (step) {
                    steps.push(step);
                    if (steps.length === 1) {
                        $scope.select(step);
                    }
                };
                this.jumpStep = function (index) {

                };
                this.removeStep = function (index) {

                };
                this.insertStep = function (step) {

                };
            },
            link: function ($scope, element, attrs) {
                $scope.getMarginValue = function () {
                    var _idx = $scope.getCurrentIndex();
                    var wizardWth = element.find('.wizard').outerWidth();
                    var _wth = 60;
                    for (var i = 0; i <= _idx + 1; i++) {
                        _wth += element.find(".steps>li").eq(i).outerWidth();
                    }
                    if (wizardWth - _wth < 0) {
                        return (wizardWth - _wth);
                    } else {
                        return 0;
                    }
                };
                // if(attrs.disableNav !== "true") {
                //     element.find(".steps").delegate("li.complete","click",function(e){
                //         var _idx = $(this).index();
                //         $scope.go(_idx);
                //     });
                // }
            },
            template: `<div class="wizard" style="margin-bottom:20px;">
            <ul class="steps" style="margin-left:{{moveWth}}px">
                <li data-ng-repeat="step in steps" data-target="#step{{ $index }}" data-ng-class="{ active: getCurrentIndex() >= $index ,complete:getCurrentIndex() > $index }">
                    <span class="badge badge-info">{{ $index + 1 }}</span><span localize="{{step.name}}"></span><span class="chevron"></span>
                </li>
            </ul>
            <div class="actions">
                <button ng-show="!btnUnable" type="button" data-ng-if="showPrev()" data-ng-click="prev()" ng-disabled="currentStep.showLoading === true" class="btn btn-sm btn-default btn-prev">
                    <i class="fa fa-arrow-left"></i><span ng-bind="prevBtnText"></span>
                </button>
                <button ng-show="!btnUnable" type="button" data-ng-if="!isLast()" data-ng-click="next()" ng-disabled="currentStep.showLoading === true" class="btn btn-sm btn-default btn-next">
                    <span ng-bind="nextBtnText"></span> <i class="fa fa-arrow-right"></i>
                </button>
                <button id='finish' ng-show="!btnUnable && isLast()" type="button" data-ng-click="done()" ng-disabled="currentStep.showLoading === true" class="btn btn-sm btn-default btn-next">
                    <span ng-bind="doneBtnText"></span><i class="fa fa-check" ></i>
                </button>
                <img ng-show="btnUnable" src="img/loadingtext.gif" width="24px" height="24px"/>
                <img ng-show="currentStep.showLoading === true" src="img/loadingtext.gif" width="24px" height="24px"/>
            </div>
        </div>
        <div class="step-content">
            <form data-ng-transclude class="form-horizontal" id="fuelux-wizard" method="post" novalidate>
            </form>
        </div>
        <div ng-show="currentStep.showLoading === true" style="position: absolute;top:0;right:0;bottom:0;left:0;z-index:999;"></div>`
        };
    }])
    .directive("wizardStep", [function () {
        return {
            restrict: "A",
            require: "^wizard",
            transclude: true,
            replace: true,
            scope: {
                name: "@",
                prevBtnText: "@",
                nextBtnText: "@",
                doneBtnText: "@",
                testValid: "="
            },
            link: function (scope, element, attrs, wizard) {
                wizard.addStep(scope);
            },
            template: `<div class="step-pane" data-ng-class="{ active: selected }" data-ng-show="selected" data-ng-transclude></div>`
        };
    }])


    .directive('ipPattern', function (ip_pattern) {

        return {
            require: ['ngModel', '?ngRequired'],
            link: function (scope, elm, attrs, ctrls) {
                var ngmodelctl = ctrls[0];
                var ngrequiredctl = ctrls[1];

                ngmodelctl.$parsers.push(function (viewValue) {

                    if (ip_pattern.test(viewValue) || (!ngrequiredctl && !viewValue)) {

                        ngmodelctl.$setValidity('ipcheck', true);
                        return viewValue;
                    } else {

                        ngmodelctl.$setValidity('ipcheck', false);
                        return undefined;
                    }
                });
            }
        }

    })
    .directive("preventSpace", [function () {
        return {
            restrict: "A",
            link: function (scope, element, attrs) {
                element.on("keypress", function (e) {
                    if (e.keyCode === 32) {
                        e.preventDefault();
                    }
                })
            }
        };
    }])
    .directive("inputNumber", [function () {
        var KEYCODE_MAP = {109: "-", 110: ".", 189: "-", 190: "."};
        return {
            restrict: "AE",
            link: function (scope, element, attrs) {
                var numKey = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105];
                var controlKeys = [
                    8, // backspace
                    46, // delete
                    37, // left arrow
                    39 // right arrow
                ];
                var ignoredKeys = attrs.inputNumberIgnore;
                element.on("keydown", function (e) {
                    var code = e.which || e.keyCode;
                    if (numKey.indexOf(code) > -1) {
                        var num = code < 60 ? code - 48 : code - 96;
                        var nextValue = this.value + num;
                        // 指令允许指定 max="300" 属性，用于限制最大可输入的整数
                        if (!attrs.max) {
                            return;
                        }
                        var max = attrs.max * 1;
                        if (!isNaN(max) && nextValue <= max) {
                            return;
                        }
                    } else if (controlKeys.indexOf(code) > -1) {
                        return;
                    } else if (ignoredKeys && !e.shiftKey && ignoredKeys.indexOf(KEYCODE_MAP[code]) > -1) {
                        return;
                    }
                    e.preventDefault();
                    return false;
                });
                element.on("input", function (e) {
                    var chars = e.target.value.split("");
                    var allowedChars = "0123456789" + (ignoredKeys || "");
                    var c, fix = false;
                    while (chars.length > 0) {
                        c = chars[chars.length - 1];
                        if (allowedChars.indexOf(c) === -1) {
                            chars.pop();
                            fix = true;
                        } else {
                            break;
                        }
                    }
                    fix && scope.$evalAsync(attrs.ngModel + " = " + JSON.stringify(chars.join("")));
                });
            }
        };
    }])
    .directive("formatIp", /** @param {vdi.INetworkUtils} networkUtils */function (networkUtils) {
        "ngInject";
        return {
            restrict: "EA",
            require: "ngModel",
            scope: {
                start: "=",
                end: "="
            },
            /**
             *
             * @param {ng.IScope} scope
             * @param {JQuery} element
             * @param {ng.IAttributes} attrs
             * @param {ng.INgModelController} ctrl
             */
            link: function (scope, element, attrs, ctrl) {
                var ngModelCtrl = ctrl;

                if (!ngModelCtrl) {
                    return;
                }
                element.addClass("ng-hide");
                element.after(`
            <span role="ipgroup">
                <input type="text" maxlength="3"/>
                <span class="dot">.</span>
                <input type="text" maxlength="3"/>
                <span class="dot">.</span>
                <input type="text" maxlength="3"/>
                <span class="dot">.</span>
                <input type="text" maxlength="3"/>
            </span>`);
                let inputs = element.next("span");
                let readKeyStroke = require("./utils/events").readKeyStroke;
                inputs.on("keydown", "input", function (e) {
                    let keys = readKeyStroke(e);
                    if (/^[0-9]$/.test(keys)) {
                        return;
                    }
                    // 对一部分特殊按键重新定义
                    let me = $(this), stop = false;
                    switch (keys) {
                        // 允许这些特殊按键
                        case "tab":
                        case "ctrl+c":
                        case "ctrl+v":
                            break;
                        case ".":
                            me.next("span").next("input").focus();
                            stop = true;
                            break;
                        case "backspace":
                            if (!me.val()) {
                                me.prev("span").prev("input").focus();
                            }
                            break;
                        case "left":
                            if (this.selectionStart === 0) {
                                me.prev("span").prev("input").focus();
                            }
                            break;
                        case "right":
                            if (this.selectionStart === me.val().length) {
                                me.next("span").next("input").focus();
                            }
                            break;
                    }
                    if (stop) {
                        event.preventDefault();
                    }
                });
                let onlyNumberRE = /^(\d*).*$/;
                let prefixZeroRE = /^0+/;
                inputs.on("input", "input", function () {
                    let me = $(this);
                    let value = me.val();
                    if (value && onlyNumberRE.test(value)) {
                        me.val(value.replace(onlyNumberRE, "$1"));
                    }
                    if (prefixZeroRE.test(value)) {
                        me.val(value.replace(prefixZeroRE, "") || "0");
                    }
                    let ipValue = [].map.call(inputs.find("input"), x => x.value).join(".");
                    ngModelCtrl.$setViewValue(ipValue);
                    scope.$apply();
                });
                inputs.on("focus", "input", function () {
                    inputs.addClass("focus");
                });
                inputs.on("blur", "input", function () {
                    inputs.removeClass("focus");
                });

                const validateKey = "ip";
                const ipValidator = function (value) {
                    if (ngModelCtrl.$isEmpty(value) || value == "...") {
                        ngModelCtrl.$setValidity(validateKey, true);
                        return value == "..." ? "" : value;
                    }
                    if (networkUtils.isIP(value)) {
                        let numberValue = networkUtils.ip2number(value);
                        let isValid = true;
                        if (scope.start && networkUtils.isIP(scope.start)) {
                            isValid = numberValue >= networkUtils.ip2number(scope.start);
                        }
                        if (scope.end && networkUtils.isIP(scope.end)) {
                            isValid = isValid && numberValue <= networkUtils.ip2number(scope.end);
                        }
                        ngModelCtrl.$setValidity(validateKey, isValid);
                        return isValid ? value : undefined;
                    } else {
                        ngModelCtrl.$setValidity(validateKey, false);
                        return undefined;
                    }
                };

                ngModelCtrl.$formatters.unshift(ipValidator);
                ngModelCtrl.$parsers.unshift(ipValidator);

                ngModelCtrl.$render = function () {
                    let parts = (ngModelCtrl.$modelValue || "").split(".");
                    let els = inputs.find("input");
                    els.each(function (i) {
                        this.value = parts[i] || "";
                    });
                };
                scope.$watch("start + '-' + end", function () {
                    let ip = ngModelCtrl.$viewValue || ngModelCtrl.$modelValue;
                    if (!ip) {
                        return;
                    }
                    let result = ipValidator(ip);
                    if (!result && !element.hasClass("ng-dirty")) {
                        element.removeClass("ng-pristine").addClass("ng-dirty");
                    }
                });
            }
        }
    })
    .directive("validateIp", function(networkUtils){
        return {
            restrict: "A",
            require: "ngModel",
            link: function(scope, element, attrs, ctrl){
                const validateFn = function(myValue){
                    if(ctrl.$isEmpty(myValue)) {
                        ctrl.$setValidity("ip", true);
                        return myValue;
                    }
                    let isValid = networkUtils.isIP(myValue);
                    ctrl.$setValidity("ip", isValid);
                    return isValid ? myValue : undefined;
                };
                ctrl.$formatters.push(validateFn);
                ctrl.$parsers.push(validateFn);
            }
        };
    })
    .directive("treeNodeParent", [function () {
        return {
            restrict: 'EA',
            replace: true,
            scope: {users: '=', filtertext: '='},
            template: '<ul role="tree" class="menu menu-tree" ng-repeat="item in getUsers()">' +
            '<div class="menu_header">' +
            '<span class="fa icon-jj"></span>' +
            '<span class="menu-name">{{item.dept_name}}</span>' +
            '<span class="pull-right fa icon-jj-add" data-ng-click="add_selected(item);$event.stopPropagation()"></span>' +
            '</div>' +
            '<div class="menu_body">' +
            '<tree-node ng-repeat="node in item.children" data-nodes="item.children" data-node="node"></tree-node>' +
            '</div>' +
            '</ul>',
            controller: function ($scope) {
                "ngInject";
                var lastFilter;
                var lastFiltedResult;
                $scope.add_selected = function (children) {
                    $scope.$emit('add_selected', children);
                }

                $scope.getUsers = function () {
                    var text = $scope.filtertext || "";
                    var users = $scope.users;
                    text = text.trim();
                    if (!text) {
                        return users;
                    }
                    if (text !== lastFilter) {
                        lastFilter = text;
                        lastFiltedResult = filterUser(angular.copy(users), text);
                    }
                    return lastFiltedResult;
                };

                function filterUser(users, text) {
                    return users.filter(function (user) {
                        if (user.children) {
                            user.children = filterUser(user.children, text);
                            return user.children.length > 0;
                        } else {
                            return user.user_name.indexOf(text) > -1 || user.real_name.indexOf(text) > -1;
                        }
                    });
                }
            },
            link: function (scope, element, attrs) {
            }
        };
    }])
    .directive("treeNode", ["$compile", function ($compile) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {node: '=', nodes: '='},
            template: '<div></div>',
            controller: function ($scope) {
                "ngInject";
                $scope.add_selected = function (children) {
                    $scope.$emit('add_selected', children);
                }
                $scope.add_select_rows = function ($event, node, nodes) {
                    $scope.$emit('add_select_rows', $event, node, nodes);
                }
            },
            link: function (scope, element, attrs) {
                if (scope.node.children) {
                    element.append('<ul role="group" class="menu menu-tree">' +
                        '<div class="menu_header">' +
                        '<span class="fa icon-jj"></span>' +
                        '<span class="menu-name">{{node.dept_name}}</span>' +
                        '<span class="pull-right fa icon-jj-add" data-ng-click="add_selected(node);$event.stopPropagation()"></span>' +
                        '</div>' +
                        '<div class="menu_body">' +
                        '<tree-node ng-repeat="sub in node.children" data-nodes="node.children" data-node="sub"></tree-node>' +
                        '</div>' +
                        '</ul>')
                } else {
                    element.append('<li class="menuitem" ng-click="add_select_rows($event,node,nodes)" ng-dblclick="add_selected(node)">' +
                        '<span class="text-overflow text-overflow-half">{{node.name}}</span>' +
                        '<span class="text-overflow text-overflow-half">{{node.real_name}}</span>' +
                        '</li>')
                }
                $compile(element.contents())(scope)
            }
        };
    }])
    .directive("uiMenuList", ["Admin", "User", "Domain", "$q", "i18n", function (APIadmin, APIuser, APIdomain, $q, i18n) {
        return {
            restrict: "AE",
            scope: {
                selected: "=menuListData"
                // domain:"=menuListDomain"
            },
            templateUrl: "includes/userMenu.html",
            controller: function ($scope) {
                "ngInject";
                // 原代码是刻意忽略了部门中间的那么多层级，只加显示了一个层级
                // 2020/08/20 新增改动用#号标明
                $scope.expandedNodes = [];
                $scope._users = [];
                $scope.selected = $scope.selected || [];
                $scope.seRows = [];
                $scope.rmRows = [];
                $scope.common_users = [];

                function formatData(d, name, flag) {
                    iteration(d, name, flag);
                    return d;
                }

                function iteration(data, childName) {
                    for (var i = 0; i < data.length; i++) {
                        $scope.expandedNodes.push(data[i]);
                        if (data[i][childName] && data[i][childName].length) {
                            var len = iteration(data[i][childName], childName);
                            if (len === 0) {
                                data[i] = undefined;
                            }
                        }
                        if (!data[i]) {
                            continue;
                        }
                        if (data[i].users && data[i].users.length > 0) {
                            data[i].users.map(user => {
                                user.name = user.name || user.user_name;
                                user._is_last = true;
                                return user;
                            });
                            data[i][childName] = data[i].users;
                        }
                        if (data[i][childName] && data[i][childName].length === 0) {
                            data[i] = undefined;
                        }
                    }
                    while (data.length > 0) {
                        // 如果有数组元素为空，每次删除一个
                        var oldlen = data.length;
                        for (var i = 0; i < oldlen; i++) {
                            if (data[i] === undefined) {
                                data.splice(i, 1);
                                break;
                            }
                        }
                        if (oldlen === data.length) {
                            break;
                        }
                    }

                    return data.length;
                }

                function removeNoChildrenDeparts(data, userFilter) { // 新增改动#1 加了一个参数userFilter,用来过滤是普通帐号还是uaa普通帐号
                    data = data.filter(noUserFilter);
                    data.forEach(walk);
                    return data;

                    function walk(node) {
                        if (!node.dept_id) {
                            return;
                        }
                        // 用户上级是没有 children 的
                        if (node.children) {
                            node.children = node.children.filter(noUserFilter);
                            node.children.forEach(walk);
                        }
                    }

                    function noUserFilter(node) {
                        if(node.users) {
                            node.users = node.users.filter(userFilter); // 新增改动#2 过滤为是只有本地普通帐号还是，uaa普通帐号
                            if (node.dept_id && !node.children && node.users.length === 0) {
                                return false;
                            }
                            return true;
                        } else {
                            return false;
                        }
                    }
                }

                function get_admin() {
                    var deferred = $q.defer();
                    APIadmin.query(function (res) {
                        deferred.resolve(res);
                    });
                    return deferred.promise;
                }

                function get_user() {
                    var deferred = $q.defer();
                    APIuser.query_tree(function (res) {
                        deferred.resolve(res);
                    });
                    return deferred.promise;
                }

                function get_domain() {
                    var deferred = $q.defer();
                    APIdomain.list(function (res) {
                        deferred.resolve(res);
                    });
                    return deferred.promise;
                }

                $q.all([get_admin(), get_user(), get_domain()]).then(function (arr) {
                    let allAdmins = arr[0].users;
                    let admins = allAdmins.filter(function (a) { return !a.is_uaa });
                    let uaaAdmins = allAdmins.filter(function (a) { return a.is_uaa });
                    let allCommonUsers = arr[1].result;
                    $scope._users = [{
                        typeName: i18n.translateText("管理用户"),
                        userData: admins
                    }, {
                        typeName: i18n.translateText("UAA管理用户"),
                        userData: uaaAdmins
                    }];
                    $scope.domain_users = arr[2].result.map(function (res) {
                        res._name = i18n.translateText("域") + "(" + res.name + ")";
                        return res;
                    });
                    // 新增改动#3 应用过滤参数
                    $scope.common_users = formatData(removeNoChildrenDeparts(angular.copy(allCommonUsers), (u) => !u.uaa_flag), "children");
                    $scope.common_users_uaa = formatData(removeNoChildrenDeparts(angular.copy(allCommonUsers), (u) => u.uaa_flag), "children");
                });

                function getLastLevelNodes(obj_levels, arrays) {
                    if (obj_levels.children) {
                        obj_levels.children.forEach(function (item) {
                            getLastLevelNodes(item, arrays);
                        })
                    } else {
                        arrays.push(obj_levels);
                    }
                }

                $scope.$on('add_selected', function (e, levels) {
                    var arrays = [];
                    getLastLevelNodes(levels, arrays);
                    $scope.add_selected(arrays);
                })
                $scope.$on('add_select_rows', function (e, $event, node, nodes) {
                    $scope.add_select_rows($event, node, nodes);
                })
                $scope.add_selected = function (items) {
                    var rows = items instanceof Array ? items : [items];
                    rows.forEach(function (i) {
                        if ($scope.selected.indexOf(i) === -1) {
                            $scope.selected.push(i);
                        }
                    });
                };
                $scope.remove_selected = function (items) {
                    var rows = items instanceof Array ? items : [items];
                    rows.forEach(function (i) {
                        $scope.selected.splice($scope.selected.indexOf(i), 1);
                    });
                    $scope.rmRows = [];
                };
                var lastRow2 = null;
                $scope.add_select_rows = function (e, item, items) {
                    var idx = $scope.seRows.indexOf(item);
                    if (e.ctrlKey) {
                        idx === -1 ? $scope.seRows.push(item) : $scope.seRows.splice(idx, 1);
                        lastRow2 = item;
                    } else if (e.shiftKey) {
                        var begin_idx = items.indexOf(lastRow2);
                        var end_idx = items.indexOf(item);
                        if (begin_idx === -1) {
                            lastRow2 = item;
                            $scope.seRows = [item];
                        } else {
                            $scope.seRows = items.slice(Math.min(begin_idx, end_idx), Math.max(begin_idx, end_idx) + 1);
                        }
                    } else {
                        $scope.seRows.splice(0, $scope.seRows.length, item);
                        lastRow2 = item;
                    }
                };
                var lastRow = null;
                $scope.add_remove_rows = function (e, item) {
                    var idx = $scope.rmRows.indexOf(item);
                    if (e.ctrlKey) {
                        idx === -1 ? $scope.rmRows.push(item) : $scope.rmRows.splice(idx, 1);
                        lastRow = item;
                    } else if (e.shiftKey) {
                        var begin_idx = $scope.selected.indexOf(lastRow);
                        var end_idx = $scope.selected.indexOf(item);
                        if (begin_idx !== -1 && end_idx !== -1) {
                            $scope.rmRows = $scope.selected.slice(Math.min(begin_idx, end_idx), Math.max(begin_idx, end_idx) + 1);
                        } else {
                            $scope.rmRows = [item];
                            lastRow = item;
                        }
                    }
                    else {
                        $scope.rmRows.splice(0, $scope.rmRows.length, item);
                        lastRow = item;
                    }
                };
                $scope.ltor = function () {
                    $scope.add_selected($scope.seRows);
                };
                $scope.rtol = function () {
                    $scope.remove_selected($scope.rmRows);
                }
            },
            link: function (scope, element, attrs) {
                var last = null;
                element.on("keyup", 'input[ng-model="searchText"]', function (e) {
                    $(".menu_header").addClass("open");
                });
                element.on("click", ".menu_header", function (e) {
                    $(this).toggleClass("open");
                });
                element.on("click", ".menuitem", function (e) {
                    var ele = $(this);
                    var menuItems = ele.parent().parent(".menu_body").find(".menuitem");
                    var allMenuItems = ele.parents(".menus").find(".menuitem");
                    if (e.ctrlKey) {
                        ele.hasClass("itemActive") ? ele.removeClass("itemActive") : ele.addClass("itemActive");
                        last = ele;
                    } else if (e.shiftKey) {
                        var begin_idx = [].indexOf.apply(menuItems, last);
                        var end_idx = [].indexOf.apply(menuItems, ele);
                        allMenuItems.removeClass("itemActive");
                        if (begin_idx !== -1 && end_idx !== -1) {
                            for (var i = 0; i < menuItems.length; i++) {
                                if (i > Math.max(begin_idx, end_idx) || i < Math.min(begin_idx, end_idx)) {
                                    menuItems.eq(i).removeClass("itemActive");
                                } else {
                                    menuItems.eq(i).addClass("itemActive");
                                }
                            }
                        } else {
                            ele.addClass("itemActive");
                            last = ele;
                        }
                    } else {
                        allMenuItems.removeClass("itemActive");
                        ele.addClass("itemActive");
                        last = ele;
                    }

                });
            }
        };
    }])
    .directive("uiInputNumber", ["$compile", function ($compile) {
        return {
            restrict: "AE",
            scope: {
                step: "@",
                max: "@",
                userNumber: "=ngModel",
                min: "@"
            },
            priority: 2,
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {

                scope.addStep = Number(scope.step) || 1;
                scope.addMax = Number(scope.max) || null;
                scope.addMin = Number(scope.min) || null;

                var is_dot = String(Number(scope.step)).indexOf(".") === -1 ? false : true;

                var modelCtrl = ctrl;
                var temp = $compile($("<div ui-input-number-wrapper></div>")[0])(scope);
                element.hide();
                element.after(temp);

                var numKey = [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105];
                var ctrKey = [8, 9, 13, 35, 36, 37, 38, 39, 40, 45, 46, 144, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 110, 190];
                scope.keydown = function (e) {
                    var _code = e.keyCode;
                    var _valsplit = e.target.value.split(".");

                    if (numKey.indexOf(_code) === -1 && ctrKey.indexOf(_code) === -1) {
                        e.preventDefault();
                    }
                    // 小数点后只能输入一位
                    if (numKey.indexOf(_code) > -1 && _valsplit.length > 1 && _valsplit[1].length > 0 && e.target.selectionStart > e.target.value.indexOf(".")) {
                        e.preventDefault();
                    }
                    // 屏蔽小数点
                    if (_code === 110 || _code === 190) {
                        if (!is_dot) {
                            e.preventDefault();
                        } else {
                            if (e.target.value.indexOf(".") !== -1) {
                                e.preventDefault();
                            }
                        }

                    }
                    // 键盘上键加法
                    if (_code === 38) {
                        e.preventDefault();
                        scope.add(scope.addStep);
                        scope.round();
                    }
                    // 键盘下键减法
                    if (_code === 40) {
                        e.preventDefault();
                        scope.add(-scope.addStep);
                        scope.round();
                    }

                };
                scope.round = function () {
                    scope.userNumber = is_dot ? Math.round(Number(scope.userNumber) * 2) / 2 : Math.round(scope.userNumber);
                }

                modelCtrl.$render = function () {
                    scope.setValidation();
                };
                scope.setValidation = function () {
                    var newval = modelCtrl.$modelValue;
                    var exp = /^-?([1-9]\d*\.?\d*|0\.?\d*[1-9]\d*|0?\.?0+|0)$/;
                    if (exp.test(newval)) {
                        if ((Math.abs(scope.addMax) >= 0 && newval > scope.addMax) || (Math.abs(scope.addMin) >= 0 && newval < scope.addMin)) {
                            modelCtrl.$setValidity("number", false);
                        } else {
                            modelCtrl.$setValidity("number", true);
                        }
                    } else {
                        if (newval) {
                            modelCtrl.$setValidity("number", false);
                        } else {
                            modelCtrl.$setValidity("number", true);
                        }
                    }
                };
                scope.add = function (num) {
                    scope.userNumber = Number(scope.userNumber) ? Number(scope.userNumber) + Number(num) : Number(num);
                    scope.setValidation();
                };
            }
        };
    }])
    .directive("uiInputNumberWrapper", [function () {
        return {
            restrict: "A",
            replace: true,
            templateUrl: "./views/vdi/common/input-number-temp.html",
            link: function (scope, element) {
            }
        };
    }])
    .directive("uiInputNumberFormatter", [function () {
        return {
            restrict: "A",
            require: "ngModel",
            link: function (scope, element, attrs, ctrl) {
                var exp = /^-?([1-9]\d*\.?\d*|0\.?\d*[1-9]\d*|0?\.?0+|0)$/;

                ctrl.$parsers.push(function (value) {
                    if (exp.test(value)) {
                        return Number(value);
                    }
                });
                ctrl.$formatters.push(function (value) {

                    if (exp.test(value)) {
                        return Number(value);
                    }
                });
            }
        };
    }])
    .directive("uiWebUpload", ["$http", "$rootScope", "i18n", function ($http, $rootScope, i18n) {
        var org = XMLHttpRequest;
        var org_open = org.prototype.open;
        var allowUpload = window.FormData && typeof window.FormData === "function";
        $rootScope.uploadPool = $rootScope.uploadPool || {};
        return {
            restrict: "A",
            templateUrl: function (ele, attrs) {
                if (attrs.templateUrl) {
                    return attrs.templateUrl;
                }
                return "views/vdi/common/ui-web-upload.html";
            },
            scope: {
                config: "=uiUploadConfig",
                finishHandel: "="
            },
            controller: ["$scope", function (scope) {
                scope.$on("progress", function (e, size) {
                    if (size.id === scope.upload_id) {
                        scope.progressName = size.name
                        scope.isUploading = true;
                        var percent = size.loaded / size.total * 100;
                        if (isNaN(percent)) {
                            percent = 0;
                        }
                        scope.progressPercent = percent.toFixed(2) + "%";
                        // if (scope.progressPercent === "100.00%") {
                        //     scope.isUploading = false;
                        // }
                        // 初始化页面上传不更新问题
                        scope.$apply();
                    }
                });
                scope.allowUpload = allowUpload;
                scope.uploadISOSize = null;

            }],
            link: function (scope, element, attrs) {
                scope.upload_id = attrs.uiWebUpload;
                scope.btnName = attrs.uiUploadBtnName;

                // 绑定一个测试提交，如果条件为 true 则按钮可点击，否则不可点击
                // 这种方式需要父 scope 配合
                if (attrs.uiWebUploadTest) {
                    var degfn = scope.$parent.$watch(attrs.uiWebUploadTest, function (v) {
                        scope.disableTest = v;
                    });
                    scope.$on("$destroy", degfn);
                    scope.disableTest = false;
                } else {
                    scope.disableTest = true;
                }

                var url;
                var form = element.find("form");
                form.attr("action", url);

                function checkConfig(file, config) {
                    var filetype = attrs.uiUploadType;
                    var maxSize = attrs.uiUploadLimit;
                    var url = attrs.uiUploadUrl;

                    if (!url) {
                        throw new Error("no url config");
                    }
                    var typematch = true;
                    if (filetype && file) {
                        typematch = (new RegExp("\\.(" + filetype + ")$")).test(file.name);
                        if (!typematch) {
                            $.bigBox({
                                title: i18n.translateText("INFOR_TIP"),
                                content: i18n.translateText("不是一个可接受的文件类型"),
                                icon: "fa fa-warning shake animated",
                                timeout: 6000
                            });
                            return false;
                        }
                    }

                    if (maxSize) {
                        maxSize = parseInt(maxSize);
                        if (isNaN(maxSize)) {
                            return console.error("invalid upload limit:", attrs.uiUploadLimit);
                        }
                        if (file.size > maxSize * Math.pow(2, 30)) {
                            $.bigBox({
                                title: i18n.translateText("INFOR_TIP"),
                                content: i18n.translateText("超出文件大小限制") + "(" + maxSize + "G)",
                                icon: "fa fa-warning shake animated",
                                timeout: 6000
                            });
                            return false;
                        }
                    }
                    if (file.size === 0) {
                        $.bigBox({
                            title: i18n.translateText("INFOR_TIP"),
                            content: i18n.translateText("文件为空"),
                            icon: "fa fa-warning shake animated",
                            timeout: 6000
                        });
                        return false;
                    }
                    else {
                        return true;
                    }
                }

                function clearDOM() {
                    var input = element.find("input[type=file]");
                    input.after(input.clone(true).val(''));
                    input.remove();
                    scope.isUploading = false;
                    scope.progressSize = 0;
                }

                function finish() {
                    $rootScope.uploadPool[attrs.uiWebUpload] = undefined;
                    delete $rootScope.uploadPool[attrs.uiWebUpload];
                }

                function success(res) {
                    if (typeof scope.finishHandel === "function") {
                        scope.finishHandel(res);
                    }
                }

                element.find("input[type=file]").on("change", function (e) {
                    var file = e.target.files[0];
                    if (!file) {
                        return;
                    }
                    // var conf = scope.config;
                    var isValid = checkConfig(file);

                    if (isValid) {
                        // $.bigBox({
                        //  title : i18n.translateText("INFOR_TIP"),
                        //  content : i18n.translateText("INFOR_UPISO"),
                        //  iconSmall : "fa fa-warning shake animated",
                        //  timeout : 5000
                        // });

                        var data = new FormData();
                        // 允许绑定额外的参数
                        if (attrs.uiWebUploadParams) {
                            $.each(scope.$eval(attrs.uiWebUploadParams), function (k, v) {
                                data.append(k, v);
                            });
                        }
                        data.append(attrs.uiWebUploadName || e.target.name, file);
                        scope.progressName = file.name;
                        scope.progressSize = "(" + (file.size / Math.pow(2, 20)).toFixed(2) + "M)";

                        $http.post( attrs.uiUploadUrl, data, {
                            transformRequest: function (config) {
                                window.XMLHttpRequest = function (a, b, c, e) {
                                    window.XMLHttpRequest = org;
                                    var xhr = new org(a, b, c, e);
                                    $rootScope.uploadPool[attrs.uiWebUpload] = xhr;
                                    xhr.open = function (q, w, e, r, t, y) {
                                        xhr.open = undefined;
                                        delete xhr.open;
                                        if (xhr.upload) {
                                            xhr.upload.addEventListener("progress", function (e) {
                                                $rootScope.$broadcast("progress", {
                                                    id: attrs.uiWebUpload,
                                                    name: file.name,
                                                    loaded: e.loaded,
                                                    position: e.position,
                                                    total: e.total,
                                                    totalSize: e.totalSize
                                                });

                                            });
                                            xhr.addEventListener("abort", finish);
                                        }
                                        return org_open.call(xhr, q, w, e, r, t, y);
                                    }
                                    return xhr;
                                };
                                return config;
                            },
                            headers: {"Content-Type": undefined}
                        }).then(function (res) {
                            clearDOM();
                            finish(res);
                            success(res);
                            $rootScope.$broadcast("finishUpload", true, file.name);
                        }, function () {
                            clearDOM();
                            finish();
                        });
                    }
                });

                element.find("button[type='button']").on("click", function (e) {
                    $(this).prev("input[type=file]").click();
                });
                if (attrs.btnClass) {
                    element.find("button[type='button']").removeClass("btn-primary").addClass(attrs.btnClass);
                }
                if (attrs.iconClass) {
                    element.find(".icon").removeClass("icon-jj-Upload").addClass(attrs.iconClass);
                }

                element.find("#abortBtn").on("click", function (e) {
                    var xhr = $rootScope.uploadPool[attrs.uiWebUpload];
                    xhr && xhr.abort();
                    clearDOM();
                    scope.$apply();
                });
            }
        };
    }])
    .service("warnBox", [function () {
        this.warn = function (content, id, callback) {
            if (!$("#warnBox").length) {
                $("body").append("<div id='warnBox'></div>");
            } else {
                $("#warnBox").show();
            }
            $("body #warnBox").append("<div class='box warnBox" + id + "'><i class='fa fa-bell'></i><div class='content'><div class='btn-close'><span>×</span></div><p class='detail' title=" + content + ">" + content + "</p></div></div>")
            if ($("body .warnBox" + id + " .detail").height() > 38) {
                $("body .warnBox" + id + " .detail").addClass('highHeight');
            }
            $("#warnBox .warnBox" + id + " .btn-close").click(function (e) {
                callback(id);
            })
            setTimeout(function () {
                if ($("#warnBox .warnBox" + id + "")) {
                    callback(id);
                }
            }, 30000)
        },
            this.close = function (id) {
                $("body .box.warnBox" + id + "").remove();
                if (!$("#warnBox").children().length) {
                    $("#warnBox").hide();
                } else {
                    $("#warnBox").show();
                }
            }
    }])
    .controller("TaskListController", ["$scope", "Task", "i18n", "currentUser", "warnBox", function ($scope, task, i18n, currentUser, warnBox) {
        $scope.toggleTaskList = function () {
            $("body").toggleClass("show_prog");
        };
        let taskTimer = null;
        let ignoreLog = false;
        $scope.rows = [];
        let data = {};
        $scope.$on("NOAUTH", () => {
            clearTimeout(taskTimer);
            ignoreLog = true;
        });
        $scope.$on("STOPLOG", function () {
            clearTimeout(taskTimer);
            ignoreLog = true;
        });
        $scope.$on("RECOVERYLOG", function () {
            clearTimeout(taskTimer);
            ignoreLog = false;
            taskTimer = setTimeout(schedule, 3000);
        });
        $scope.$on("AUTHED", () => {
            ignoreLog = false;
            schedule();
        });
        $scope.$on("instanceIDS", function ($event, ids) {
            data.instances = ids;
        });
        $scope.$on("imageIDS", function ($event, ids) {
            data.images = ids;
        });
        $scope.$on("fusion_imagesIDS", function ($event, ids) {
            data.fusion_images = ids;
        });
        $scope.$on("clientIDS", function ($event, ids) {
            data.clients = ids;
        });
        $scope.$on("modeIDS", function ($event, ids) {
            data.modes = ids;
        });
        $scope.$on('voimodesIDS', function ($event, ids) {
            data.voimodes = ids;
        });
        $scope.$on('idvmodesIDS', function ($event, ids) {
            data.idvmodes = ids;
        });
        $scope.$on('voidesktopsIDS', function ($event, ids) {
            data.voidesktops = ids;
        });
        $scope.$on('idvdesktopsIDS', function ($event, ids) {
            data.idvdesktops = ids;
        });
        $scope.$on('voipersonalIDS', function ($event, ids) {
            data.voipersonals = ids;
        });
        $scope.$on('voiRoamsIDS', function ($event, ids) {
            data.voiroams = ids;
        });
        $scope.$on('nodes', function ($event, ids) {
            data.nodes = ids;
        });
        $scope.$on("manageNetworkIDS", function ($event, ids) {
            data.manage_networks = ids;
        });
        $scope.$on("personpools", function ($event, ids) {
            data.personpools = ids;
        });
        var lists = [];

        function schedule() {
            var postData = Object.keys(data).map(function (key) {
                return {
                    key: key,
                    ids: data[key]
                };
            });
            task.post(postData, function (res) {
                if (ignoreLog) {
                    return;
                }
                $scope.rows = res.results.tasks.filter(item => currentUser.real_name === item.user);

                Object.keys(res.results).forEach(function (key) {
                    if (key !== "tasks") {
                        $scope.$root && $scope.$root.$broadcast(key + "RowsUpdate", res.results[key]);
                    }
                });
                // 管理台左上角 提示消息
                for (var i in res.results.notifies) {
                    var item = res.results.notifies[i], color = "#004d60", content;
                    if (lists[item.id] == undefined) {
                        lists[item.id] = item;
                        if (item.waringtype === 0) {
                            warnBox.warn(item.content, item.id, function (ID) {
                                warnBox.close(ID);
                                task.put({notify_id: ID}, function (res) {
                                })
                            })
                        } else {
                            if (item.waringtype === 1) {
                                // 前端姣姐认为的全局提示消息
                                color = "#e0f0fd";
                                content = i18n.translate(item.name) + " (" + item.target + ")";

                            } else {
                                color = "#ed8686";
                                content = i18n.translate(item.name) + " (" + item.target + ")";
                            }
                            $.bigBox({
                                title: i18n.translate("waringtype" + item.waringtype),
                                content: content,
                                color: color,
                                timeout: 3000
                            }, function () {
                                task.put({notify_id: item.id}, function (res) {
                                })
                            });
                        }
                    }
                }
                taskTimer = setTimeout(schedule, 3000);
            }, function () {
                if (ignoreLog) {
                    return;
                }
                taskTimer = setTimeout(schedule, 10000);
            });
            data = {};
        }

    }])
    .controller("LogoController", ["$scope", "settings", "$$$version", "Domain", function ($scope, settings, $$$version, Domain) {
        $scope.domain = $Domain;
        $scope.version = $$$version;
        $scope.languages = settings.languages;
        $scope.currentLang = settings.currentLang;
    }])
    .controller("AlarmController", ["$scope", "AlarmHistory", function ($scope, AlarmHistory) {
        $scope.isOpen = false;
        $scope.open = function () {
            $scope.isOpen = true;
        }
        $scope.close = function (e) {
            if (e)
                e.stopPropagation();
            $scope.isOpen = false;
        }
        // function findDif(oldArray, newArray, difAttr){
        //     if(newArray.length){
        //         var length = oldArray.length>=newArray.length?oldArray.length:newArray.length;
        //         var difs = [];
        //         for(var i=0; i<length; i++){
        //             if(newArray[i]){
        //                 var different = oldArray.filter(function(item){ return item[difAttr] == newArray[i][difAttr] })[0];
        //                 if(!different){ difs.push(newArray[i]) };
        //             }
        //         }
        //         return difs;
        //     }else{ return []; }
        // };

        // var oldAlarms = [];
        $scope.$on("alarmsRowsUpdate", function ($event, data) {
            $scope.alarms = data;
            // if(!$scope.isOpen){
            //     var unreads = [];
            //     data.forEach(function(item){
            //         if(!item.is_read){ unreads.push(item) }
            //     })
            //     if(unreads.length){
            //         $scope.open();
            //         setTimeout(function(){
            //             $scope.close();
            //         }, 30000)
            //     }
            // }

            // var difs = findDif(oldAlarms, data, 'id');
            // if(!$scope.isOpen && difs.length){
            //     oldAlarms = data;
            //     $scope.open();
            //     setTimeout(function(){
            //         $scope.close();
            //     }, 30000)
            // }
        })
        $scope.delete = function () {
            AlarmHistory.setRead({
                ids: $scope.alarms.map(function (item) {
                    return item.id;
                })
            }, function (res) {
                $scope.alarms = [];
                $scope.isOpen = false;
            })
        }
    }])
    .controller("OnlineService", function ($scope, $modalInstance) {
        require("./help/online-service.css");
        $scope.close = function () {
            $modalInstance.close();
        }
    })
    // 帐号信息
    .controller("AccountController", ["$scope", "$modal", "$http", "uihelper", "currentUser",
        function ($scope, $modal, $http, uihelper, currentUser) {
            $scope.isUaaBan = false;
            $scope.$on("AUTHED", () => {
                if (currentUser.ready) {
                    $scope.isUaaBan = currentUser.is_uaa;
                }
            });
            window.vdiEnvironment == "development" && console.log('$scope.isUaaBan:', $scope.isUaaBan);
            // 设置账户信息
            $scope.accoutConfig = function () {
                $modal.open({
                    templateUrl: "views/vdi/common/account-config-info.html",
                    controller: function ($scope, $modalInstance) {
                        "ngInject";
                        let initInfo = {};
                        let models = $scope.m = {
                            name: "",
                            role: "",
                            loading: false,
                            info: {
                                real_name: "",
                                sex: "",
                                contact: "",
                                email: ""
                            },
                            unChanged: function () {
                                return angular.equals(initInfo, models.info);
                            }
                        }
                        models.loading = true;
                        $http({
                            method: "GET",
                            url: "/thor/users/current-user"
                        }).then(function (res) {
                            if (res && res.data && res.data.user) {
                                let data = res.data.user;
                                initInfo = {
                                    real_name: data.realname,
                                    sex: data.sex,
                                    contact: data.contact,
                                    email: data.email
                                }
                                models.name = data.username;
                                models.role = data.permission;
                                models.info = angular.copy(initInfo);
                            }
                        }).finally(function () {
                            models.loading = false;
                        })
                        $scope.ok = function () {
                            // 保存帐号信息接口
                            models.loading = true;
                            $http({
                                method: "PUT",
                                url: "/thor/users/current-user",
                                data: models.info
                            }).then(function (res) {
                                models.loading = false;
                                console.log(res);
                                // 成功修改之后
                                let loginInfo = JSON.parse(sessionStorage.getItem("vdi_loginInfo"));
                                angular.extend(loginInfo, models.info);
                                window.vdiEnvironment == "development" && console.log(loginInfo);
                                sessionStorage.setItem("vdi_loginInfo", JSON.stringify(loginInfo));
                                $modalInstance.close();
                            }).finally(function () {
                                models.loading = false;
                            })
                        }
                        $scope.close = function () {
                            $modalInstance.close();
                        }
                    },
                    resolve: {
                        params: () => ({})
                    },
                    size: "md"
                })
            }
            // 修改密码
            $scope.modifyPassword = function () {
                $modal.open({
                    templateUrl: "views/vdi/common/account-password-modify.html",
                    controller: function ($scope, $modalInstance) {
                        "ngInject";
                        let models = $scope.p = {
                            newPwd: "",
                            surePwd: "",
                            loading: false,
                            opt: {
                                new_password: "",
                                old_password: ""
                            }
                        }
                        $scope.ok = function () {
                            // 保存帐号信息接口
                            // 检测老密码是否正确
                            if (models.newPwd != models.surePwd) {
                                uihelper.i18nAlert("两次输入的新密码不一样！请重新输入新密码！");
                                models.newPwd = "";
                                models.surePwd = "";
                                return;
                            }
                            if (models.newPwd == models.opt.old_password) {
                                uihelper.i18nAlert("新密码和旧密码一样！请重新输入新密码！");
                                models.newPwd = "";
                                models.surePwd = "";
                                models.opt.old_password = "";
                                return;
                            }
                            models.opt.new_password = models.newPwd;
                            models.loading = true;
                            $http({
                                method: "PUT",
                                url: "/thor/users/current-user/password",
                                data: models.opt
                            }).then(function (res) {
                                console.log(res);
                                models.loading = false;
                                $modalInstance.close();
                            }).finally(function () {
                                models.loading = false;
                            })
                        }
                        $scope.close = function () {
                            $modalInstance.close();
                        }
                    },
                    resolve: {
                        params: () => ({})
                    },
                    size: "md"
                })
            }
            // 切换主题逻辑
            $scope.switchTheme = function () {
                $modal.open({
                    templateUrl: "views/vdi/common/account-change-theme.html",
                    controller: function ($scope, $rootScope, $modalInstance) {
                        "ngInject";
                        $scope.close = function () {
                            $modalInstance.close();
                        }
                        $scope.changeSkin = function (name) {
                            $rootScope.currentTheme = name;
                            // 用户修改主题后保存
                            $$$storage.setSessionStorage("current_theme", name);
                            $modalInstance.close();
                        };
                    },
                    resolve: {
                        params: () => ({})
                    },
                    size: "sm"
                })
            }

        }])
    .filter("interfaceFilter", [function () {
        return function (data, idx, nets) {
            var invalidArr = [];
            nets.forEach((n, i) => {
                if (i !== idx && n._data_dev && n._data_dev._dev) {
                    invalidArr.push(n._data_dev._dev);
                }
            });
            return data.filter(function (d) {
                if (invalidArr.indexOf(d._dev) === -1) {
                    return true;
                }
                return false;
            });
        }
    }])


    /**
     * 校验IP范围
     * formatIp启用范围校验时，按照某些路径会导致bug。
     * 这个指令是在formatIp的外层加一层div范围校验，后期看能否优化下formatIp。
     * @author wangchuan
     */
    .directive("validateIpRange", function (networkUtils) {
        "ngInject";
        return {
            restrict: "EA",
            require: "ngModel",
            scope: {
                start: "=",
                end: "="
            },
            link: function ($scope, element, attrs, ctrl) {
                const validateKey = "ipRange";
                const ipRangeValidator = function (start, end) {
                    if (!networkUtils.isIP(start) || !networkUtils.isIP(end)) {
                        return false;
                    }
                    return networkUtils.ip2number(start) <= networkUtils.ip2number(end);
                };
                const applyValidation = function(valid){
                    ctrl.$setValidity(validateKey, valid);
                };
                const applyClass = function(valid){
                    element.removeClass("ng-valid").removeClass("ng-invalid");
                    element.addClass(valid ? "ng-valid" : "ng-invalid");
                };
                const isEmpty = function(val){
                    return !val || ctrl.$isEmpty(val) || val == "...";
                }
                $scope.$watch("start + '-' + end", function (val, oldVal) {
                    if(attrs.disabled){
                        return false;
                    }

                    let valid;
                    if(isEmpty($scope.start) && isEmpty($scope.end)){
                        valid = !attrs.required;
                        applyValidation(valid);
                        if(element.hasClass("ng-dirty")){
                            applyClass(valid);
                        }
                        return false;
                    }
                    element.removeClass("ng-pristine").addClass("ng-dirty");
                    valid = ipRangeValidator($scope.start, $scope.end);
                    applyValidation(valid);
                    if(element.hasClass("ng-dirty")){
                        applyClass(valid);
                    }
                });
            }
        }
    })

    /**
     * ng-options 设置选项 disabled
     * @author wangchuan
     */
    .directive('disabledOnFinishRender', function ($timeout) {
        return {
            restrict: 'A',
            scope: {
                disabledOnFinishRender: "="
            },
            link: function (scope, element, attr) {
                scope.$watch('disabledOnFinishRender', function(list){
                    if(Array.isArray(list) && list.length > 0){
                        var options = element.find("option");
                        for(var index = 0; index < options.length; index++){
                            var elem = options[index];
                            elem.disabled = list[index].disabled;
                        }
                    }
                })
            }
        }
    })

    /**
     * 全局loading
     * 目前平台很少有全局loading，慎用！
     */
    .directive('loading', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                let position = element.css('position');
                scope.$watch(function () {
                    return scope.$eval(attr.loading);
                }, function (value) {
                    if (!angular.isDefined(value)) { return false; }
                    if (!value) {
                        element.find('.loading-mask').remove();
                        element.css({ position: position });
                        return false;
                    }
                    if (position === 'static') {
                        element.css({ position: 'relative' });
                    }
                    element.append(`<div ng-if="m.inGetPool" class="loading-mask">
                        <div class="loading-spinner">
                            <img src="img/loadingtext.gif">
                        </div>
                    </div>`);
                    let loadingBackground = attr.loadingBackground;
                    if(loadingBackground){
                        element.find('.loading-mask').css({
                            "background-color": loadingBackground
                        });
                    }
                });
            }
        }
    })
    .factory("Checkboxes", [function () {
        let cbx = {
            itemList: [],
            allCount: 0,
            checkedCount: 0,
            checkedAll: false
        };
        // 标志选中的字段
        let _checked = '';

        // 初始化
        cbx.init = function (list, config) {
            cbx.itemList = [];
            cbx.allCount = 0;
            cbx.checkedCount = 0;
            cbx.checkedAll = false;

            if (!Array.isArray(list)){ return false; }
            if(config === null || typeof config !== 'object'){
                config = {
                    checkedField: '_checked'
                };
            }
            let { checkedField } = config;
            _checked = checkedField;

            cbx.itemList = list;
            list.map(item => {
                cbx.allCount++;
                if(item[_checked]){
                    cbx.checkedCount++;
                }
            });
            cbx.getCheckAllStatus();
        };
        // 计算全选状态
        cbx.getCheckAllStatus = function(){
            cbx.checkedAll = cbx.checkedCount === cbx.allCount && cbx.allCount > 0;
        };
        // 设置 item 选择状态
        cbx.setItemCheckStatus = function(item, val){
            item[_checked] = val;
            if(item[_checked]){
                cbx.checkedCount++;
            } else {
                cbx.checkedCount--;
            }
            cbx.getCheckAllStatus();
        };
        // 切换 item 选择状态
        cbx.onCheckedChange = function(item){
            cbx.setItemCheckStatus(item, !item[_checked]);
        };
        // 点击全选
        cbx.onCheckedAllChange = function(checkedAll){
            // 这里不调 setItemCheckStatus, 避免重复计算产生的bug
            cbx.itemList.map(item => {
                item[_checked] = checkedAll;
            });
            cbx.checkedCount = checkedAll ? cbx.allCount : 0;
            cbx.checkedAll = checkedAll;
        };

        // todo
        // 获取选中
        return cbx;
    }])

    .service("formDate", function () {
        this.format = function (date, fmt) {
            var o = {
                "M+": date.getMonth() + 1,                 //月份   
                "d+": date.getDate(),                    //日   
                "h+": date.getHours(),                   //小时   
                "m+": date.getMinutes(),                 //分   
                "s+": date.getSeconds(),                 //秒   
                "q+": Math.floor((date.getMonth() + 3) / 3), //季度   
                "S": date.getMilliseconds()             //毫秒   
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
    
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        };
    })
    /**
     * 模态框服务，有open和close方法，用来统一管理modal开关
     */
    .factory("modalHelper", function (uihelper) {
        let modals = [];
        return {
            open: function (opt) {
                let modal = [];
                let {content} = opt;
                if (content) {
                    let {title, onSuccess} = opt;
                    modal = uihelper.confirmWithModal(title, content);
                    modal.then(() => onSuccess && onSuccess());
                } else {
                    let {url, ctrl, scope, size,  data, onSuccess} = opt;
                    let modalOpt = {
                        templateUrl: url,
                        controller: ctrl,
                        scope: scope,
                        size: size || "md"
                    };
                    if (data) {
                        modalOpt.resolve = {
                            params: function () {
                                return data;
                            }
                        }
                    }
                    modal = uihelper.openModal(modalOpt);
                    modal.result.then(() => {
                        onSuccess && onSuccess();
                    });
                    modal.modalShow = true;
                    modals.push(modal);
                }
            },
            close: function () {
                let last = modals.pop();
                if (last && last.modalShow) {
                    last.modalShow = false;
                    last.close();
                }
            },
            modals
        }
    })
    /**
     * 弹窗渲染指令：简化弹窗相关的html代码，集中关注业务逻辑，可配合modal-open指令使用
     * 这里跟vue的iview类似，默认不给slot=footer时，默认提供不支持验证的footer按钮，
     * 需要支持复杂的验证，使用自定义slot=footer,
     * 结合我们的管理台项目，存在另一种情况，modal不管理footer，根据需要自定义footer的行为
     * 1. 使用默认footer，简单弹窗弹出自定义内容，不支持表单验证，此时需要传递okcb，和cancelcb
     * 2. 不想本指令提供footer，不传递okcb和cancelcb
     * 3. 自定义footer，提供slot="footer"，同上不传递okcb和cancelcb
     * 使用方法1（极简）：
     *  <ui-modal name="xxx" ok="ok()" cancel="closeModal()">
     *     <p>some custom non-uniform message</p>
     *  </ui-modal>
     * 使用方法2：
     *  <ui-modal name="xxx">
     *     <form>
     *         maybe some custom footer staff here
     *     </form>
     *  </ui-modal>
     * 使用方法3：
     *  <ui-modal name="xxx">
     *     <form ></form>
     *     <div slot="footer">
     *       <img ng-if="m.isLoading" src="img/loadingtext.gif" height="24" width="24">
     *       <button type="button" ng-if="!m.isLoading" ng-click="ok()" ng-disabled="form.$invalid || !isScopeValid()" class="btn btn-default" localize="确定"></button>
     *       <button type="button" ng-if="!m.isLoading" ng-click="closeModal()" class="btn btn-default" localize="取消"></button>
     *     </div>
     *  </ui-modal>
     */ 
    .directive("uiModal", function (modalHelper) {
        return {
            restrict: "AE",
            template: `<div>
                            <div class="modal-header">
                                <button type="button" class="close" ng-click="cancel()"> 
                                    <span aria-hidden="true">×</span><span class="sr-only">Close</span> 
                                </button> 
                                <h4 class="modal-title" slot="header"></h4>
                            </div> 
                            <div class="modal-body" slot="body"></div>
                            <div ng-show="hasFooter" class="modal-footer" slot="footer">
                                <img ng-if="loading" src="img/loadingtext.gif" height="24" width="24">
                                <button type="button" ng-if="!loading" ng-click="ok()" class="btn btn-default" localize="{{okText}}"></button>
                                <button type="button" ng-if="!loading" ng-click="cancel()" class="btn btn-default" localize="{{cancelText}}"></button>
                            </div>
                        </div>`,
            replace: true,
            scope: {
                ok: "&",
                cancel: "&",
                loading: "="
            },
            transclude: true,
            controller: function ($scope, $element, $attrs, $transclude) {
                // 判断是否有ok和cancel回调，来决定了是否显示默认footer
                $scope.hasFooter = $attrs.cancel && $attrs.ok ? true : false;
                $scope.okText = $attrs.okText || "确定";
                $scope.cancelText = $attrs.cancelText || "取消";
                if (!$scope.hasFooter)
                    $scope.cancel = function () {
                        modalHelper.close();
                    }
                $transclude(function (clone) {
                    let sameMap = {};
                    let targets = $element.find("[slot]");
                    let slots = clone.filter("[slot]");
                    let anonymousSlot = clone.filter(":not([slot])");
                    let bodyTarget = $element.find("[slot=body]");
                    bodyTarget.append(anonymousSlot);
                    [].every.call(slots, (s) => {
                        let inname = angular.element(s).attr("slot");
                        if (!inname || inname == "default") { // 不给name值，或者值为default，以为是body
                            inname = "body";
                            angular.element(s).attr("slot", inname); 
                        }
                        if (!sameMap[inname]) {
                            if (inname == "footer") {
                                if ($scope.hasFooter) {
                                    console.error("指令中您设置了okcb和cancelcb，同时又设置了slot='footer'，请仅选中其中一种方式！");
                                }
                                $scope.hasFooter = true;
                            }
                            let item = [].filter.call(targets, (it) => angular.element(it).attr("slot") == inname)[0];
                            if (item) {
                                angular.element(item).empty();
                                item.append(s);
                                sameMap[inname] = true;
                            } else {
                                console.error("指令中您设置了无效的slot名");
                            }
                            return true; // 正确的slot名和设置了无效的slot名（不append），继续下一个循环
                        } else {
                            console.error("指令中包含相同的slot名称或者两条以上的默认slot名，请重新设置名称:", inname);
                            return false;
                        }
                    })
                });
            },
            compile: function (ele, attrs, transclude) {
                let name = attrs.name;
                ele.find("[slot=header]").html(`<span localize='${name}'></span>`);
            }
        }
    })
    /** 
     * 弹窗打开指令
     * 1. 支持弹窗种类：
     *   1.1 打开弹窗，模板地址（url），控制器（controller） 1.2 打开confirm框 title，content
     * 2. 通用功能：valid，打开弹窗之前先判断或者验证，onSuccess，成功关闭弹窗字后获取list列表和执行操作
     * 3. record记录：当需要使用单个记录时，需要传递，例如：编辑
     * 4. 使用方法1：针对复杂的表单提交的模态框打开
     *  <a modal-open="EditFuseTplCtrl" open-url="vdi/dialog/template/tpl_fuse_edit_new.html" on-success="refresh()" [record="record"] [valid="someValidFun"]></a>
     *  业务中EditFuseTplCtrl控制器,最后一个参数返回默认params，就是这里传进去record用于弹窗的渲染和表单的填入
     * 5. 使用方法2：简单的confirm操作，支持自定义title，content的模态框打开
     *  <a modal-open="删除融合模板" content="delContent" on-success="doDelete()" [valid="someValidFun"]></a>
     */ 
    .directive("modalOpen", function (modalHelper) {
        return {
            restrict: "A",
            scope: {
                onSuccess: "&",
                valid: "&",
                record: "=",
                content: "="
            },
            link: function ($scope, elem, attrs) { 
                // get options
                let onSuccess = attrs.onSuccess && $scope.onSuccess || null;
                let needValid = attrs.valid || undefined;
                let isValid = $scope.valid;
                let url = attrs.openUrl || "";
                let size = attrs.size || "md";
                if(typeof url == "string" && url.indexOf("views/") !== 0) {
                    url = "views/" + url;
                }
                elem.click(() => {
                    show();
                })
                function show () {
                    // get content when modal opened, as content is dynamic and is empty when initialized
                    let content = $scope.content;
                    if (needValid && isValid()) {
                        return;
                    }
                    let opt = {
                        content,
                        url,
                        size,
                        onSuccess,
                        title: attrs.modalOpen,
                        ctrl: attrs.modalOpen,
                        scope: $scope,
                        data: $scope.record
                    };
                    modalHelper.open(opt);
                }
                function hideAll () {
                    modalHelper.modals && modalHelper.modals.length && modalHelper.modals.forEach((m) => m && m.close());
                }
                $scope.$on("$destroy", () => hideAll());
            }
        }
    })
    /**
     * 步骤条指令
     */
    .directive("stepPanel", function () {
        return {
            restrict: "AE",
            require: ["stepPanel"],
            replace: true,
            transclude: true,
            scope: {
                commit: "&",
                model: "=",
                loading: "=stepLoading"
            },
            template: `
                <div class="step-panel">
                    <div class="step-header">
                        <ul class="steps">
                            <li ng-repeat="step in panelCtrl.steps" ng-class="{active: step.active, complete: step.complete}">
                                <span class="badge badge-info">{{$index + 1}}</span>
                                <span localize="{{step.name}}"></span>
                                <span class="chevron"></span>
                            </li>
                        </ul>
                    </div>
                    <div class="step-body" ng-transclude></div>
                    <div class="step-footer">
                        <img ng-if="loading" src="img/loadingtext.gif" height="24" width="24">
                        <button type="button" class="btn btn-sm btn-default" ng-show="showPrev()" ng-disabled="loading" ng-click="prev()">上一步</button>
                        <button type="button" class="btn btn-sm btn-default" ng-show="showNext()" ng-disabled="!valid() || loading" ng-click="next()">下一步</button>
                        <button type="button" class="btn btn-sm btn-default" ng-show="showFinal()" ng-disabled="!valid() || loading" ng-click="next()">完成</button>
                    </div>
                </div>
            `,
            // 自己的方法，并且调用别人的方法
            link: function ($scope, $elem, $attr, ctrls) {
                // 初始化loading为false
                $scope.loading = false;
                $scope.panelCtrl = ctrls[0];
                $scope.prev = function () {
                    $scope.panelCtrl.prev();
                }
                $scope.next = function () {
                    $scope.panelCtrl.next();
                }
                $scope.valid = function () {
                    if ($scope.panelCtrl.steps[$scope.panelCtrl.step] && !$scope.panelCtrl.steps[$scope.panelCtrl.step].valid()) return false;
                    return $scope.panelCtrl.step < $scope.panelCtrl.steps.length;
                }
                $scope.showPrev = () => $scope.panelCtrl.step > 0;
                $scope.showNext = () => $scope.panelCtrl.step < $scope.panelCtrl.steps.length - 1;
                $scope.showFinal = () => $scope.panelCtrl.step >= $scope.panelCtrl.steps.length - 1;
                $scope.panelCtrl.init();
            },
            // 公共方法
            controller: function ($scope, $element) {
                let self = this;
                self.step = 0;
                self.steps = [];
                self.next = function () {
                    self.steps[self.step].update();
                    if (self.steps[self.step].prevent()) {
                        window.vdiEnvironment == "development" && console.error("prevent true return!");
                        return;
                    }
                    self.step++;
                    if (self.step < self.steps.length) {
                        self.hideAll();
                        self.steps[self.step].populateModel($scope.model);
                        self.steps[self.step].show();
                    } else {
                        self.step = self.steps.length - 1;
                        $scope.commit({models:$scope.model});
                    }
                }
                self.hideAll = function () {
                    self.steps.forEach((s, index) => {
                        s.complete = self.step > index ? true : false;
                        s.hide();
                    });
                }
                self.prev = function () {
                    self.steps[self.step].update();
                    self.hideAll();
                    self.step--;
                    if (self.step >= 0) {
                        self.steps[self.step].populateModel($scope.model);
                        self.steps[self.step].show();
                    } else {
                        self.step = 0;
                    }
                }
                self.update = function (model) {
                    angular.extend($scope.model, model);
                }
                self.pushStep = function (step) {
                    self.steps.push(step);
                }
                self.init = function () {
                    self.step = 0;
                    self.steps[self.step].populateModel($scope.model);
                    self.steps[self.step].show();
                }
                $scope.$on("$destroy", function () {
                    self.setp = 0;
                    self.steps = [];
                })
            }
        }
    })
    /* 
     * 配合使用步骤指令TODO:
     *   1. 步骤表单要加上序号
     *   2. 下一步之前加特殊验证
     *   3. 步骤表单作用域和模态框控制器作用域共享了
     *  用法：<step-item name="模板配置" step="2" valid=""></step-item>
     *  这里step="2"中的数字，是当前步骤所对应的form的名称 myForm1,myForm2...方便获取到不同步骤的form表单，获取到不同的输入框的值,step后面的值可以是任何字符串，要求不能相同；
     *  valid方法返回false就弹出错误消息，如果true，就验证成功。 validOne: () => {let isValid = data.description; if(!isValid) uihelper.i18nAlert() return isValid;}
     */
    .directive("stepItem", function () {
        return {
            require: ['^^stepPanel', "stepItem"],
                restrict: 'E',
                transclude: true,
                replace: true,
                scope: {
                    name: '@',
                    valid: "&",
                    step: "@"
                },
                template:
                `<div class="step" ng-show="active">
                    <form class="form-horizontal" name="myForm{{step}}" autocomplete="off">
                        <div ng-transclude ></div>
                    </form>
                </div>`,
                link: function($scope, $element, $attrs, ctrls) {
                    $scope.isInValid = false;
                    $scope.needValid = !!$attrs.valid;
                    $scope.m = {};
                    $scope.panelCtrl = ctrls[0];
                    $scope.stepCtrl = ctrls[1];
                    $scope.panelCtrl.pushStep($scope.stepCtrl);
                },
                controller: function($scope) {
                    let self = this;
                    self.name = $scope.name;
                    self.complete = false;
                    self.show = function () { self.active = $scope.active = true; };
                    self.hide = function () { self.active = $scope.active = false; };
                    self.valid = function() {
                        return $scope['myForm' + $scope.step] && $scope['myForm' + $scope.step].$valid;
                    };
                    // 父指令用来判断是否需要阻止到下一步
                    self.prevent = function () {
                        return $scope.isInValid;
                    }
                    // 获取当前form的表单值，并且更新到父级中的model中去
                    self.update = function(){
                        var formName = 'myForm' + $scope.step;
                        var form = $scope[formName];
                        var data = {};
                        angular.forEach(form, function (value, key) {
                            if (value && value.hasOwnProperty('$modelValue'))
                                data[key] = value.$modelValue;
                        });
                        $scope.panelCtrl.update(data);
                        // 给父作用域传递当前步骤的data，用来验证属性值
                        $scope.isInValid = $scope.needValid && typeof $scope.valid({data}) != "undefined" && !$scope.valid({data});
                    };
                    // 把model的值赋值给当前作用域
                    self.populateModel = function(model){
                        $scope.m = model;
                        // 指向scope的第一个子作用域
                        // $scope.$$childHead.m = $scope.m;
                    };
                }
        }
    })
    .directive("uiPage", function () {
        return {
            restrict: "E",
            scope: {
                total: "=",
                page: "=",
                pageSize: "=",
                onPageChange: "&",
                simple: "@"
            },
            replace: true,
            template: `
            <div data-grid-pagination data-ng-show="total > 0" class="toolbar-vcenter">
                <div ng-if="!simple" role="status" data-localize="PAGE" localize-title="PAGE"
                    param1="{{ (page - 1) * pageSize + 1 }}"
                    param2="{{ (page * pageSize) < total ? (page * pageSize) : total }}"
                    param3="{{ total }}"></div>
                <div ng-if="simple" role="status" localize="SIMPLE_PAGE" localize-title="SIMPLE_PAGE"
                    param1="{{ total }}"></div>
                <div class="toolbar-glue"></div>
                <pagination
                    boundary-links="true"
                    boundary-link-numbers="true"
                    total-items="total"
                    items-per-page="pageSize"
                    data-ng-model="page"
                    data-ng-change="onPageChange()"
                    rotate="false"
                    force-ellipses="true"
                    max-size="2"
                    class="pagination-sm"
                    previous-text="&lsaquo;"
                    next-text="&rsaquo;"
                    first-text="&laquo;"
                    last-text="&raquo;"
                ></pagination>
            </div>
            `
        }
    })
    /**
     * 用户选择组件：1. 搜索过滤功能 2.选择树结构，3. 动态展示用户信息，4.移入，移除功能，5. 展示选择用户
     */
    .directive("uiUserSelector", function ($http, uihelper, $filter) {
        return {
            restrict: "E",
            scope: {
                selectItem: "="
            },
            replace: true,
            templateUrl: "includes/user-selector.html",
            controller: function ($scope, $attrs) {
                $scope.hasRegion = typeof $attrs.hasRegion != "undefined";
                $scope.singleMode = typeof $attrs.single != "undefined";
                function createObj () {
                    return {
                        data: [],
                        checkAll: false,
                        page: 1,
                        pageSize: 30
                    }
                }
                let models = $scope.m = {
                    searching: false
                }
                models.pack = createObj();
                models.origin = createObj();
                $scope.sortOrigin = function (name, asc) {
                    models["origin"].data.sort(function (a, b) {
                        if (!getPageItems("origin").map((item) => item.id).includes(a.id) ||
                         !getPageItems("origin").map((item) => item.id).includes(b.id)) {
                            return 0;
                        }
                        return (a[name] > b[name] ? 1 : -1) * (asc ? 1 : -1);
                    });
                };
                $scope.sortPack = function (name, asc) {
                    models["pack"].data.sort(function (a, b) {
                        if (!getPageItems("pack").map((item) => item.id).includes(a.id) ||
                         !getPageItems("pack").map((item) => item.id).includes(b.id)) {
                            return 0;
                        }
                        return (a[name] > b[name] ? 1 : -1) * (asc ? 1 : -1);
                    });
                }
                $scope.onPageChange = function (key) {
                    models[key].checkAll = false;
                    models[key].data.forEach(item => {
                        item.checked = false;
                    });
                };
                const getPageItems = $scope.getPageItems = function (key) {
                    return $filter("paging")(models[key].data, models[key].page, models[key].pageSize) || [];
                };
                $scope.onAllSel = function (key) {
                    uihelper.downCheck(getPageItems(key), models[key].checkAll);
                }
                $scope.onOneSel = function (key) {
                    uihelper.upCheck(getPageItems(key), (flag) => {
                        models[key].checkAll = flag;
                    });
                }
                const refreshMap = function () {
                    let map = {};
                    models.pack.data.forEach((u) => {
                        map[u.id] = u;
                        u.checked = false;
                        u.disabled = false;
                    })
                    models.origin.data.forEach((u) => {
                        u.checked = false;
                        u.disabled = !!map[u.id];
                    })
                }
                $scope.checkLen = function (key) {
                    return getPageItems(key).filter((d) => d.checked && !d.disabled).length;
                }
                $scope.validAllIn = function () {
                    return models.origin.data.filter((item) => !item.disabled).length;
                }
                $scope.allIn = function () {
                    let temp = [];
                    angular.copy(models.origin.data.filter((item) => !item.disabled), temp);
                    models.pack.data.push(...temp);
                    refreshMap();
                    models.pack.checkAll = false;
                    models.origin.checkAll = false;
                    $scope.selectItem = angular.copy(models.pack.data);
                }
                $scope.add = function () {
                    let temp = [];
                    angular.copy(models.origin.data.filter((a) => a.checked && !a.disabled), temp);
                    models.pack.data.push(...temp);
                    refreshMap();
                    models.pack.checkAll = false;
                    models.origin.checkAll = false;
                    $scope.selectItem = angular.copy(models.pack.data);
                }
                $scope.remove = function () {
                    let temp = [];
                    angular.copy(models.pack.data.filter((a) => a.checked && !a.disabled), temp);
                    models.pack.data = models.pack.data.filter((a) => temp.map((t) => t.id).indexOf(a.id) <= -1 );
                    refreshMap();
                    models.pack.checkAll = false;
                    models.origin.checkAll = false;
                    $scope.selectItem = angular.copy(models.pack.data);
                }
                $scope.onSingleChange = function (item) {
                    $scope.selectItem = item;
                }
                let self = this;
                self.selected = null;
                self.refresh = $scope.refresh = function () {
                    let node = self.selected;
                    if (!node) return;
                    let params = {};
                    let searchText = $scope.searchText ? $scope.searchText.trim() : "";
                    if (searchText) {
                        params.keyword = searchText;
                    }
                    models.searching = true;
                    models["origin"].checkAll = false;
                    models["origin"].data = [];
                    switch (node.type) {
                        case "admin":
                            params.role = 0;
                            break;
                        case "uaaAdmin":
                            params.role = 0;
                            params.is_uaa_user = true;
                            break;
                        case "common":
                            params.role = 2;
                            params.department_id = node.id;
                            break;
                        case "uaaCommon":
                            params.role = 2;
                            params.department_id = node.id;
                            params.is_uaa_user = true;
                            break;
                        case "domain":
                            params.role = 4;
                            params.ad_server_id = node.id;
                            break;
                        case "domainGroup":
                            params.role = 4;
                            params.ad_server_id = node.id;
                            params.group = node.name || "other";
                            break;
                        default:
                            params = {};
                            break;
                    }
                    $http.get("/thor/users/public", {
                        params
                    }).then((resp) => {
                        let users = resp.data.users || [];
                        models["origin"].data = users;
                        refreshMap();
                    }).finally(() => models.searching = false);
                }
            }
        }
    })
    /**
     * 用户类型选择器
     */
    .directive("uiUserTypeSelector", function (getUserTree) {
        return {
            restrict: "E",
            require: ['^^uiUserSelector'],
            replace: true,
            template: `
            <div>
                <treecontrol class="tree-clean tree-light" 
                    tree-model="treedata" options="opts" on-selection="onSelectionNode(node)">
                    <span class="label-node" title="{{node.name}}">{{node.name}}</span>
                </treecontrol>
            </div>
                `,
            link: function (scope, iElem, iAttrs, ctrls) {
                let hasRegion = typeof iAttrs.hasRegion != "undefined";
                let parentCtrl = ctrls[0];
                let adminArr = [
                        {
                            type: "admin",
                            name: "管理帐号",
                            role: 0
                        },
                        {
                            type: "uaaAdmin",
                            name: "UAA管理帐号",
                            role: 0,
                            isUaa: true
                        }
                    ], commonArr = [
                        {
                            type: "common",
                            name: "普通帐号",
                            role: 2,
                            disabled: true,
                            children: []
                        },
                        {
                            type: "uaaCommon",
                            name: "UAA普通帐号",
                            isUaa: true,
                            disabled: true,
                            role: 2,
                            children: []
                        }
                    ], domainArr = [];
                if (hasRegion) {
                    adminArr.push({
                        type: "regionAdmin",
                        name: "区域管理帐号",
                        role: 7
                    });
                    commonArr.push({
                        type: "regionCommon",
                        name: "区域普通帐号",
                        disabled: true,
                        role: 8,
                        children: []
                    })
                }
                getUserTree(hasRegion).then((resp) => {
                    commonArr[0].children = resp.departTree;
                    commonArr[1].children = resp.uDepartTree;
                    if (hasRegion) {
                        commonArr[2].children = resp.rDepartTree;
                    }
                    domainArr = resp.domainTree;
                    scope.treedata = scope.expandedNodes = [
                        ...adminArr,
                        ...domainArr,
                        ...commonArr
                    ]
                })
                scope.opts = {
                    nodeChildren: "children",
                    dirSelectable: true,
                    allowDeselect: false,
                    injectClasses: {
                        "iExpanded": "light-expanded",
                        "iCollapsed": "light-collapsed"
                    }
                };
                scope.onSelectionNode = function (node) {
                    parentCtrl.selected = node;
                    parentCtrl.refresh();
                }
            }
        }
    })
    /**
     * 获取用户类型树结构方法
     */
    .factory("getUserTree", function($http, $q, i18n){
        let listToTree = require ("./utils/listToTree");
        return function(hasRegion = false){
            let promises = [
                $http.get("/thor/user/departments"),
                $http.get("/thor/user/get_users")
            ]
            if (hasRegion) {
                promises.push( $http.get("/thor/regions/users/common/tree"))
            }
            return $q.all(promises).then((respArr) => {
                let departs = respArr[0].data.result;
                let uDeparts = angular.copy(departs);
                let domains = respArr[1].data.result;
                let rDeparts = null, rDepartsTree = null;
                uDeparts.forEach((item) => item.type = "uaaCommon");
                departs.forEach((item) => item.type = "common");
                let res = {
                    departTree: listToTree(departs),
                    uDepartTree: listToTree(uDeparts),
                    domainTree: domains.map((item) => {
                        item.name = i18n.translateText("域") + "(" + item.name + ")";
                        item.children = item.groups;
                        item.role = 4;
                        item.type = "domain";
                        item.children.forEach((child) => {
                            child.type = "domainGroup";
                            child.id = item.id;
                        });
                        return item;
                    })
                }
                if (hasRegion) {
                    rDeparts = respArr[2].data.result;
                    rDeparts.forEach((item) => item.type = "regionCommon");
                    rDepartsTree = listToTree(uDeparts);
                    res.rDepartsTree = rDepartsTree;
                }
                return res;
            })
        }
    })
