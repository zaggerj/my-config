angular.module("vdi.desktop")
// 个人桌面列表控制器
.controller("vdiDesktopPersonalListController", function($scope, $modal, PersonDesktop, VMCommon, $interval, $filter, $http, $$$os_types, uihelper, i18n, Server, UserRole, TreeInstances, $routeParams){
    "ngInject";
    let hasTerminalpermission = UserRole.currentUserRoles.filter(function(role){ return role == "Terminal" }).length;
    let hasTerminalManagepermission = UserRole.currentUserRoles.filter(function(role){ return role == "Terminal_Manage" }).length;
    let hasClassroompermission = UserRole.currentUserRoles.filter(function(role){ return role == "Classroom" }).length;
    $scope.linkTerminal = hasTerminalpermission && hasTerminalManagepermission && hasClassroompermission ? true : false;
    $scope.inCurrentUserPool = function(pool){
        if($$$storage.getSessionStorage("loginInfo"))
            return JSON.parse($$$storage.getSessionStorage("loginInfo")).pool.indexOf(pool) > -1
    };

    $scope.searchText = $routeParams.name;
    const loopTimer = $interval(function(){
        var filterSearch = $filter("filter")($scope.rows || [], $scope.searchText);
        var filterSearchPage = $filter("paging")(filterSearch, $scope.currentPage, $scope.pagesize);
        $scope.rows && $scope.$root && $scope.$root.$broadcast("instanceIDS", filterSearchPage.map(item => item.id));
    }, 1000);
    $scope.$on("$destroy", function(){
        $interval.cancel(loopTimer);
    });
    $scope.$on("instancesRowsUpdate", function($event, data){
        var _rows = {};
        $scope.rows.forEach(function(item){
            _rows[item.id] = item;
        });
        console.log(["$scope.rows", $scope.rows])
        data.forEach(function(item){
            if(item.task_state){
                item.other_status = "other";
            }else{
                item.other_status = "certain";
            }
            if(item.status == "updating" || item.status == "making"){
                item._ignore = true;
            }else{
                item._ignore = false;
            }
            if(_rows[item.id]){
                for(var k in item){
                    _rows[item.id][k] = item[k];
                }
            }
        });
        // $scope.updateData("", $scope.select, $scope.depart);
    });
    $scope.getObjLength = function(obj){
        try{
            return Object.keys(obj).length;
        }catch(err){
            return 0;
        }
    };
    var _scope = $scope;
    //个人桌面排序
    _scope.sortPersonalName = function(name, bool){
        $scope.rows.sort(function(a, b){
            var _numa, _numb;
            var get_num = function(tar){
                for(var i = tar.length - 1 ; i-- ; i >= 0 ){
                    if(!Number(tar[i])){
                        return Number(tar.substring(i + 1, tar.length));
                    }
                }
            };
            _numa = get_num( a[name] );
            _numb = get_num( b[name] );
            return (_numa - _numb) * (bool ? -1 : 1);
        });
    };

    $scope.depart = {name: i18n.translate("全部"), id: -1, full_path: "root"};
    $scope.refresh = (_s = $scope) => {
        console.log("refresh")
        _s.depart = $$$storage.getSessionStorage("depart") ? JSON.parse($$$storage.getSessionStorage("depart")) : $scope.depart;
        PersonDesktop.query(res => {
            // _s.rows = _s.select==''?res.result:res.result.filter(function(item){ return item.status == _s.select });
            res.result.forEach(function(desk){
                if(desk.user_group == ""){
                    desk.user_group = i18n.translate("管理用户")
                }
                if(desk.task_state){
                    desk.other_status = "other";
                }else{
                    desk.other_status = "certain";
                }
                if(desk.status == "updating" || desk.status == "making"){
                    desk._ignore = true;
                }else{
                    desk._ignore = false;
                }
            })
            _s.allRows = res.result;
            _s.updateData("", _s.select, _s.depart);
            _s.rows.forEach(row => {
                row.icon = uihelper.getOS(row).icon;
                row.label = uihelper.getOS(row).label;
                row.detailData = {};
            });
            _s.sortPersonalName("display_name");
            _s.loading = false;
        });
    };
    $scope.getDetail = function(it){
        $scope.loading_detail = true;
        PersonDesktop.list_detail({id:it.id}, function(res){
            it.detailData = res.result;
        }).$promise.finally(function(){
            $scope.loading_detail = false;
        });
    };
    $scope.expand = function(row){
        $scope.rows.forEach(r => {
            if(row.id === r.id){
                r._expand = !row._expand;
                if(r._expand){
                    $scope.getDetail(row);
                }
            }else{
                r._expand = false;
            }
        })
    };
    $scope.pagesize = Number($$$storage.getSessionStorage("personl_pagesize")) || 100;
    $scope.currentPage = 1;
    $scope.$watch("pagesize", function(newvalue){
        $$$storage.setSessionStorage("personl_pagesize", newvalue);
    });
    $scope.loading = true;
    $scope.rows = [];
    $scope.refresh();
    $scope.openAddDomainDialog = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.is_domain_user && !row.ad_server_name });
        if(rows.length === 0){
            uihelper.i18nAlert("vdiDesktopPersonalDomain_TIP1", "INFOR_TIP")
            return;
        }
        var modal = $modal.open({
            templateUrl:"views/vdi/dialog/desktop/add_server.html",
            controller:"personalAddServerDialog",
            resolve:{param:function(){ return angular.copy(rows); }}
        });
        modal.result.then(function(res){
            $scope.refresh();
        });
    };
    // 个人模板
    // 锐哥说是评审的结果：一共四个条件已保存、未关联个人桌面且关机状态的正常模板
    $scope.canDisk = function (item) {
        return item.status == "shutdown";
    }
    $scope.personExitDomain = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.ad_server_name; });
        if(rows.length == 0){
            uihelper.i18nAlert("vdiDesktopPersonalDomain_TIP2", "INFOR_TIP")
        }else{
            uihelper.confirmWithModal(
                '退域', 'DOMAIN_EXIT_TIP'
            ).then(function(){
                Server.domain_set_person({
                    instance_ids:rows.map(function(row){ return row.id }),
                    has_domain:false
                }, function(){
                    _controllerScope.refresh();
                });  
            })
        }
    };
    $scope.updateData = function(text, select, depart){
        $$$storage.setSessionStorage("depart", JSON.stringify(depart));
        $scope.rows = $scope.allRows.filter(function(row){
            row._selected = false;
            if(select){
                if(text && text.trim()){
                    return row.status === select || row.other_status === select;
                }
                return row.status === select || row.other_status === select;
            }
            return true;
        });
        if(depart.type == "common"){
            $scope.rows = $scope.rows.filter(it=>it.user_group.indexOf(depart.dept_name) > -1);
        }else if(depart.type == "domain"){
            $scope.rows = $scope.rows.filter(it=>it.user_group === depart.domain_name);
        }else if(depart.type == "admin"){
            $scope.rows = $scope.rows.filter(it=>it.user === depart.name);
        }else if(depart.type == "adminAll"){
            $scope.rows = $scope.rows.filter(it=>it.user_group == i18n.translate("管理用户"));
        }
    };
    var _controllerScope = $scope;
    /**
    * [selectMode 部门域选择]
    */
    $scope.selectMode = function(){
        $modal.open({
            templateUrl:"views/vdi/dialog/desktop/personal_user_group.html",
            size: "sm-md",
            controller:function($scope, $modalInstance){
                "ngInject";
                function formatData(d, name){
                    iteration(d, name);
                    return d;
                }
                function iteration(data, childName){
                    for(var i = 0 ; i < data.length ; i++){
                        data[i]["type"] = "common";
                        data[i]["name"] = data[i]["dept_name"];
                        $scope.expandnodes.push(data[i]);
                        if(data[i][childName] && data[i][childName].length){
                            var len = iteration(data[i][childName], childName);
                            if(len === 0){
                                data[i] = undefined;
                            }
                        }
                        if(data[i][childName] && data[i][childName].length === 0){
                            data[i] = undefined;
                        }
                    }
                    for(i = 0 ; i < data.length ; i++){
                        if(data[i] === undefined){
                            data.splice(i, 1);
                        }
                    }
                    return data.length;
                }
                function getAdminNum(rows){
                    return rows.reduce(function(count, item){
                        return count + item.desktop_num;
                    }, 0);
                }
                $scope.loading = true;
                TreeInstances.query(function(res){
                    $scope.loading = false;
                    res.result.forEach(function(item){
                        if(item.dept_name){
                            item.name = item.dept_name;
                        }else if(item.domain_name){
                            item.name = item.domain_name;
                        }else{}
                    });
                    $scope.expandnodes = [];
                    var adminData = res.result.filter(function(item){ return item.type == "admin" });
                    var admins = [{
                        name: i18n.translate("管理用户"), type: "adminAll", children: adminData, desktop_num: getAdminNum(adminData)}];
                    var domains = res.result.filter(function(item){ return item.type == "domain" });
                    var commons = res.result.filter(function(item){ return item.type == "common" });
                    commons = formatData(commons, "children", $scope.expandnodes);
                    var all = [{id: -1, name:i18n.translate("全部"), children: admins.concat(commons).concat(domains)}];
                    $scope.treedata = all;
                    $scope.expandnodes = $scope.expandnodes.concat(admins).concat(adminData).concat(domains).concat(all);
                    $scope.selected = $scope.expandnodes.filter(function(item){ return item.name == _controllerScope.depart.name; })[0];
                    $scope.selected._selected = true;
                    $scope.showSelected = function(node, selected){
                        node._selected = selected;
                        $scope.selected = node;
                    }
                })
                $scope.ok = function(){
                    _controllerScope.depart = $scope.selected && $scope.selected._selected ? $scope.selected : {name: i18n.translate("全部"), id: -1, full_path: "root"};
                    _controllerScope.updateData(_controllerScope.searchText, _controllerScope.select, _controllerScope.depart)
                    $modalInstance.close();
                },
                $scope.close = function(){
                    $modalInstance.close();
                }
            }
        })
    }
    /**
    * [selectMode 部门域选择]_____end
    */

    $scope.checkCanPause = function (item, status) {
        let temp = (item && [item] || $scope.rows.filter(function (row) { return row._selected }));
        return temp.some(function (row) {
            return row.gpu == 3 || row.gpu == 4 ||
                (status == 1 ? row.status != 'running' : row.status != 'paused' )
                || row.task_state;
        });
    }

    $scope.start = item => {
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && (row.status == "shutdown" || row.status == "suspended") && !row.task_state; });
        if(rows.length == 0){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP1", "INFOR_TIP")
        }else{
            VMCommon.start({instance_ids: rows.map(row => row.instance_id)}, () => $scope.refresh());
        }
    };

    $scope.forceShutdown = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && (row.status == "running" || row.status == "suspended") && !row.task_state; });
        if(rows.length == 0){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP2", "INFOR_TIP")
        }else{
            uihelper.confirmWithModal(
                '桌面强制关机',
                '确定强制关闭桌面吗'
            ).then(function(){
                // $modalInstance.close();
                VMCommon.shutdowns({instance_ids: rows.map(row => {
                    row._selected = false;
                    return row.instance_id;
                })}, () => { _controllerScope.refresh() });
            })
        }
    };
    $scope.natureShutdown = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && (row.status == "running" || row.status == "suspended") && !row.task_state; })
        if(rows.length == 0){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP3", "INFOR_TIP")
        }else{
            uihelper.confirmWithModal(
                '桌面自然关机',
                '确定自然关闭桌面吗'
            ).then(function(){
                rows.map(function(row){
                    row._selected = false;
                });
                VMCommon.shutdowns({is_soft:"true", instance_ids: rows.map(function(row){ return row.instance_id; })}, function(){
                    _controllerScope.refresh();
                });
            })
        }
    };
    $scope.restart = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && (row.status == "running" || row.status == "suspended") && !row.task_state; })
        if(rows.length == 0){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP4", "INFOR_TIP")
        }else{
            uihelper.confirmWithModal(
                '桌面重启',
                '确定重启桌面吗'
            ).then(function(){
                rows.map(function(row){
                    row._selected = false;
                });
                VMCommon.reboots({is_soft:"true", instance_ids: rows.map(function(row){ return row.instance_id; })}, function(){
                    _controllerScope.refresh();
                });
            })
        }
    };
    $scope.pause = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.status == "running" && !row.task_state; })
        if(rows.length == 0 ){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP5", "INFOR_TIP")
        }else{
            uihelper.confirmWithModal(
                '桌面暂停',
                '确定暂停桌面吗'
            ).then(function(){
                rows.map(function(row){
                    row._selected = false;
                });
                VMCommon.pause({instance_ids: rows.map(function(row){ return row.instance_id; })}, function(){
                    _controllerScope.refresh();
                });
            })
        }
    }
    $scope.resume = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.status == "paused" && !row.task_state; })
        if(rows.length == 0 ){
            uihelper.i18nAlert("vdiDesktopPersonalList_TIP6", "vdiDesktopPersonalList_TIP6")
        }else{
            uihelper.confirmWithModal(
                '桌面恢复',
                '确定恢复桌面吗'
            ).then(function(){
                rows.map(function(row){
                    row._selected = false;
                });
                VMCommon.resume({instance_ids: rows.map(function(row){ return row.instance_id; })}, function(){
                    _controllerScope.refresh();
                }); 
            })
        }
    };
    $scope.hasPausedStatus = function(){
        var flag = false;
        var _selected = $scope.rows.filter(function(row){ return row._selected });
        var _hasPaused = _selected.filter(function(row){ return row.status == "paused" });
        if(_hasPaused.length == _selected.length){
            flag = true;
        }
        return flag;
    }
    $scope.delete = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.status !== "paused" });
        var is_running = rows.some(function(row){ return row.status == "running" && !row.task_state });
        $modal.open({
            templateUrl: "views/vdi/dialog/desktop/personal_delete.html",
            controller : function($scope, $modalInstance){
                "ngInject";
                let models = $scope.m = {
                    loading: false,
                    is_run: is_running,
                    moveToRecycle: true,
                    delete_disk: false,
                    has_data_disk: rows.some(function(d){ return d.local_gb }),
                    isAllConnected: rows.every(d => d.client_ip)
                };
                $scope.ok = function(){
                    let promise;
                    let instance_ids = rows.map(function(row){ return row.instance_id; });
                    models.loading = true;
                    if(models.moveToRecycle) {
                        promise = $http.post("/api/instances/recycle/add/", {
                            instance_ids
                        });
                    } else {
                        promise = PersonDesktop.delete({
                            instance_ids,
                            force_delete_data: models.delete_disk
                        }).$promise;
                    }
                    promise.then(() => {
                        if(models.isAllConnected) {
                            uihelper.alertCodeError(14024);
                        }
                        _controllerScope.refresh();
                    }).finally(() => {
                        models.loading = false;
                    });
                    // 删除桌面可能非常耗时
                    $modalInstance.close();
                },
                $scope.cancel = function(){
                    $modalInstance.close();
                }
            },
            size : "sm"
        });
    };
    $scope.select_network = function(item){
        
    }
    $scope.canMoveTo = function(){
        var rows = $scope.rows.filter(function(row){ return row._selected });
        if(rows.length === 1 && rows[0].status === "shutdown"){
            return true;
        } else {
            return false;
        }
    }
    $scope.moveto = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected });
        var can_migrate_rows = rows.filter(function(item){ return item.virtual_type === "kvm" && item.status == "shutdown" && !item.task_state });
        if(!can_migrate_rows.length){
            uihelper.i18nAlert("DESKTOP_MOVE_TIP1", "INFOR_TIP")
        }else{
            var can_migrate_host = [];
            $scope.moveto_loading = true;
            PersonDesktop.check_can_migrate_host_vpc({instance_ids:can_migrate_rows.map(function(item){ return item.id })}, function(res){
                for(var i in res.result){ can_migrate_host.push({id:i, value:res.result[i]}) }
                can_migrate_host = can_migrate_host.filter(function(item){ return item.value });
                $scope.moveto_loading = false;
                if(!can_migrate_host.length){
                    uihelper.i18nAlert("DESKTOP_MOVE_TIP1", "INFOR_TIP")
                    return;
                }
                $modal.open({
                    template:
                        `<section id='widget-grid'>
                            <div class='modal-content'>
                                <div class='modal-header'>
                                    <button type='button' class='close' data-ng-click='close()'><span aria-hidden='true'>×</span><span class='sr-only'>Close</span></button>
                                    <h4 class='modal-title' id='mySmallModalLabel' localize='桌面迁移'>桌面迁移</h4>
                                </div>
                                <div class='modal-body'>
                                    <form class='form-horizontal' novalidate name='movetoForm'>
                                        <div class='form-group'>
                                            <label class='control-label col-xs-4' localize='选择目标主机'>选择目标主机</label>
                                            <div class='col-xs-4'>
                                                <select class='form-control' ng-model='host' ng-options='host for host in hosts' required>
                                                    <option value="" localize="--请选择--"> --请选择-- </option>
                                                </select>
                                            </div>
                                            <img style="position: relative;top: 3px" ng-if="hosts_loading" width="24" height="24" src="img/HLloading.gif">
                                        </div>
                                        <footer class='text-right'><img src='img/loadingtext.gif' ng-if='loading' height='24' width='24' alt=''>
                                        <button class='btn btn-default' ng-if='!loading' data-ng-click='ok()' localize='确定' ng-disabled='movetoForm.$invalid'>确定</button>
                                        <button ng-if='!loading' class='btn btn-default' data-ng-click='close()' style='margin-left:5px;' localize='取消'>取消</button></footer>
                                    </form>
                                </div>
                            </div>
                        </section>`,
                    controller : function($scope, $modalInstance){
                        "ngInject";
                        $scope.hosts = [];
                        $scope.hosts_loading = true;
                        PersonDesktop.moveHostList_vpc({instance_ids:rows.map(function(item){ return item.id })}, function(res){
                            $scope.hosts = res.result;
                            $scope.host = $scope.hosts[0];
                            $scope.hosts_loading = false;
                        });
                        $scope.ok = function(){
                            var _this = this;
                            $scope.loading = true;
                            PersonDesktop.moveTo_vpc({instance_ids:rows.map(function(item){ return item.id }), host:_this.host}, function(){
                                $modalInstance.close();
                            }).$promise.finally(function(){
                                $scope.loading = false;
                                _controllerScope.refresh();
                            });
                        },
                        $scope.close = function(){
                            $modalInstance.close();
                        }
                    },
                    size : "md"
                });
            }, function(){ $scope.moveto_loading = false;})
        }
    };
    $scope.migration = function(item){
        var rows = item ? [item] : $scope.rows.filter(function(row){ return row._selected && row.status === "running" && !row.task_state });
        if(!rows.length){
            uihelper.i18nAlert("DESKTOP_MOVE_TIP2", "INFOR_TIP")
            return;
        }
        $modal.open({
            template:
                `<section id='widget-grid'>
                    <div class='modal-content'>
                        <div class='modal-header'>
                            <button type='button' class='close' data-ng-click='close()'><span aria-hidden='true'>×</span><span class='sr-only'>Close</span></button>
                            <h4 class='modal-title' id='mySmallModalLabel' localize='动态迁移'></h4>
                        </div>
                        <div class='modal-body'>
                            <form class='form-horizontal' novalidate name='movetoForm'>
                                <div class='form-group'>
                                    <label class='control-label col-xs-4' localize='选择目标主机'>选择目标主机</label>
                                        <div class='col-xs-4'>
                                            <select class='form-control' ng-model='host' ng-options='host for host in hosts' required>
                                                <option value="" localize="--请选择--">请选择</option>
                                            </select>
                                        </div>
                                        <img style="position: relative;top: 3px" ng-if="hosts_loading" width="24" height="24" src="img/HLloading.gif">
                                        <a style="position: relative;top: 5px;" ng-if="!hosts_loading && !hosts.length" class="mypopover" htmlpopover='{{migrationTip}}'><i class="fa fa-question-circle"></i></a>
                                    </div>
                                    <footer class='text-right'>
                                        <img src='img/loadingtext.gif' ng-if='loading' height='24' width='24' alt=''>
                                        <button class='btn btn-default' ng-if='!loading' data-ng-click='ok()' localize='确定' ng-disabled='movetoForm.$invalid'>确定</button>
                                        <button ng-if='!loading' class='btn btn-default' data-ng-click='close()' style='margin-left:5px;' localize='取消'>取消</button>
                                    </footer>
                                </form>
                            </div>
                        </div>
                    </section>`,
            controller : function($scope, $modalInstance){
                "ngInject";
                $scope.hosts = [];
                $scope.hosts_loading = true;
                $scope.migrationTip = i18n.translate("migrationTip");
                VMCommon.get_live_move_hosts({instance_ids:rows.map(function(item){ return item.id })}, function(res){
                    $scope.hosts = res.result;
                    $scope.host = $scope.hosts[0];
                    $scope.hosts_loading = false;
                });
                $scope.ok = function(){
                    var _this = this;
                    $scope.loading = true;
                    VMCommon.live_move({
                        instance_ids:rows.map(function(item){ return item.id }),
                        host:_this.host
                    }, function(){
                        $modalInstance.close();
                    }).$promise.finally(function(){
                        $scope.loading = false;
                    });
                },
                $scope.close = function(){
                    $modalInstance.close();
                }
            },
            size : "md"
        });
    };
    $scope.view = function(item){
        window.open("desktopScreenshot.html#" + item.id, "person_desktop_" + item.id);
    };
    $scope.viewStorage = function(item){
        $modal.open({
            templateUrl:"views/vdi/dialog/desktop/view_storage.html",
            controller:["$scope", "$modalInstance", function($scope, $modalInstance){
                PersonDesktop.list_detail({id:item.id}, function(res){
                    $scope.data = res.result;
                    $scope.data.hostname = item.hostname;
                });
                $scope.close = function(){
                    $modalInstance.close();
                }
            }]
        });
    };
    var is_update = false;
    // 获取个人桌面
    PersonDesktop.update_tpl_tip(function(res){
        var resp = res.result;
        if(resp.storage_type === "local" && resp.ha_mode === "active_passive" && resp.ha_triggered){
            is_update = true;
            _controllerScope.isLimitDownload = true;
        }
    });
    //新增个人桌面添加同新增模板一致限制条件
    $scope.addPersonalDesk = function(){
        if(is_update){
            uihelper.i18nAlert("HA_MODE_REMOTE_ADD_DESKTOP", "INFOR_TIP")
            return false;
        }
        $modal.open({
            templateUrl:"views/vdi/dialog/desktop/personal_new.html",
            controller:"newPersonDialog",
            size:"md",
            scope:_controllerScope
        });
    }
    //另存为模板也限制
    $scope.saveAsTpl = function(){
        if(is_update){
            uihelper.i18nAlert("HA_MODE_REMOTE_SAVE_AS_TPL", "INFOR_TIP")
            return false;
        }
        $modal.open({
            templateUrl:"views/vdi/dialog/desktop/personal_save_template.html",
            controller:"SaveAsTplCtrl",
            scope: _controllerScope,
            size:"md"
        });
    }
    // 磁盘管理-新增
    $scope.createDisk = function (item) {
        if(!item) { return; }
        $modal.open({
            templateUrl: "views/vdi/dialog/template/template_teach_disk_create.html",
            size: "md",
            controller: function ($scope, $http, $modalInstance) {
                let models = $scope.m = {
                    size: "",
                    isPersonalTpl: true,
                    isPersonalDesk: true
                }
                $scope.ok = function () {
                    $http.post(`/api/instances/${item.instance_extra_id}/disks/`, {
                        size: models.size
                    }).then(function (res){
                        res = res.data;
                        if(res.code == 0) {
                            // ignore
                        }
                    })
                    $modalInstance.close();
                }
                $scope.close = function () {
                    $modalInstance.close();
                }
            }
        }).result.then($scope.refresh);
    }
    // 磁盘管理-扩容
    $scope.diskExpand = function (item) {
        if(!item) { return; }
        $modal.open({
            templateUrl: "views/vdi/dialog/template/template_teach_disk_expand.html",
            size: "md",
            controller: function ($scope, $modalInstance, $http) {
                let models = $scope.m = {
                    disks: [],
                    disk: null,
                    boot_index: 0,
                    size: "",
                    diskLoading: false,
                    min: 5,
                    isPersonalTpl: true,
                    isPersonalDesk: true
                }
                $scope.$watch("m.disk", function (v) {
                    if(v){
                        if(v.boot_index == 0) {
                            models.min = (v.volume_size > 10 ? v.volume_size : 10) + 1;
                        } else {
                            models.min = (v.volume_size > 5 ? v.volume_size : 5) + 1;
                        }
                        models.size = "";
                    }
                })
                function getDisks() {
                    models.diskLoading = true;
                    $http.get(`/api/instances/${item.instance_extra_id}/disks/`)
                                .then(function (res) {
                                    res = res.data;
                                    if(res.code == 0) {
                                        models.disks = res.disks;
                                        models.disk = res.disks[0];
                                    }
                                })
                                .finally(function () {
                                    models.diskLoading = false;
                                })
                }
                getDisks();
                $scope.ok = function () {
                    $http.put(`/api/instances/${item.instance_extra_id}/disks/${models.disk.boot_index}/`, {
                        boot_index: models.disk.boot_index,
                        size: models.size
                    })
                    $modalInstance.close();
                }
                $scope.close = function () {
                    $modalInstance.close();
                }
            }
        }).result.then($scope.refresh);
    }
    // 磁盘管理-挂载
    $scope.diskLoad = function (item) {
        if(!item) { return; }
        $modal.open({
            templateUrl: "views/vdi/dialog/desktop/personal_disk_load.html",
            size: "md",
            controller: function ($scope, $modalInstance, $http) {
                let models = $scope.m = {
                    diskLoading: false,
                    user: item.user,
                    disks: [],
                    disk: null
                }
                function getDisks() {
                    models.diskLoading = true;
                    $http.get(`/thor/list_passive_volume`,
                        {
                            params: {
                                instance_id: item.id,
                                user_id: item.user_id
                            }
                        })
                        .then(function (res) {
                            res = res.data;
                            if(res.code == 0) {
                                models.disks = res.result;
                                models.disk = models.disks[0];
                            }
                        })
                        .finally(function () {
                            models.diskLoading = false;
                        })
                }
                getDisks();
                $scope.ok = function () {
                    $http.post(`/api/instances/${item.instance_extra_id}/disks/`, {
                        volume_id: models.disk.volume_id,
                        size: models.disk.size
                    })
                    $modalInstance.close();
                }
                $scope.close = function () {
                    $modalInstance.close();
                }
            }
        }).result.then($scope.refresh);
    }

    $scope.manageDissociateDisk = function(){
        uihelper.openModal({
            templateUrl: "views/vdi/dialog/desktop/dissociate_disk.html",
            controller: "dissociateDiskCtrl"
        });
    };
})
.controller("newPersonDialog", function($scope, $modalInstance, Host, Network, HardwareTemplate, PersonDesktop, i18n, $$$MSG, ResourcePool, $filter, $modal, VMCommon, $location, uihelper, $http, networkUtils){
    "ngInject";
    let allReses = [];
    $scope.desktopNum = 1;
    $scope.max_instance = 0;
    $scope.host_loading = true;
    $scope.regXP = /WindowsXP|WindowsXP_64/i;
    $scope.reg = /(windows\s*7|8|10)/i;
    $scope.regWin = /Windows/i;
    // 第一步
    $scope.step1 = {};
    $scope.step1.resourceType = "kvm";
    $scope.IPmodes1 = [{name: i18n.translate("不分配"), value: 0}];
    $scope.IPmodes2 = [{name: i18n.translate("系统分配"), value: 1}, {name: i18n.translate("固定IP"), value: 2}];
    $scope.get_subnet = function(network){
        if(network.subnets.length){
            Network.query_sub({
                id:network.id
            }, function(res){
                $scope.subnetworks = res.result.map(function(n){
                    n._desc = n.start_ip ? (n.name + " (" + n.start_ip + " - " + n.end_ip + ") ") :  n.name;
                    return n;
                });
                $scope.step1.subnetwork = $scope.subnetworks[0];
                $scope.clearBindIp();
            });
        }else{
            $scope.subnetworks = [];
            $scope.step1.subnetwork = null;
            $scope.clearBindIp();
        }
    };
    Network.query(function(data){
        // $scope.networks = data.networks.filter(function(n){ return n.subnets.length > 0});
        $scope.networks = data.networks;
        if($scope.networks.length){
            $scope.step1.network = $scope.networks[0];
            $scope.get_subnet($scope.step1.network);
        }
    });
    ResourcePool.query(function(res){
        allReses = res.result;
        $scope.resources = allReses.filter(function(item){ return item.hosts.length > 0 && item.type == $scope.step1.resourceType });
        $scope.step3.resource = $scope.resources[0];
        $scope.get_personal_template();
    });
    $scope.onResouceTypeChange = function(){
        $scope.resources = allReses.filter(function(item){ return item.hosts.length > 0 && item.type == $scope.step1.resourceType });
        $scope.step3.resource = $scope.resources[0];
        $scope.get_personal_template();
    };
    $scope.get_personal_template = function(){
        $scope.templates = [];
        $scope.templateNum = undefined;
        $scope.step1.image = undefined;
        $scope.loading_template = true;
        VMCommon.list_template({type:2, product_type__in: ["vdi","voi"], virtual_type:$scope.step1.resourceType }, function(data){
            $scope.loading_template = false;
            $scope.winTable = data.win_images
                .filter(function(item){ return item.status === "alive" })

            $scope.linTable = data.linux_images
                .filter(function(item){ return item.status === "alive" })
            $scope.otherTable = data.other_images
                .filter(function(item){ return item.status === "alive" })
            $scope.templates = $scope.winTable.concat($scope.linTable).concat($scope.otherTable);
            for(let t of $scope.templates) {
                t.os_text = uihelper.getOS(t).label;
            }
            $scope.templateNum = $scope.templates.length;
            $scope.step1.image = $scope.templates[0];
        });
    };
    $scope.clearBindIp = function(){
        if($scope.step1.subnetwork){
            $scope.IPmodes = $scope.IPmodes2;
        }else{
            $scope.IPmodes = $scope.IPmodes1;
        }
        $scope.step1.IPmode = $scope.IPmodes[0];
        $scope.step1.ip = null;
    };
    $scope.gotoTemPerson = function(){
        $modalInstance.close();
        $location.url("/template/personal")
    }
    // 第二步
    $scope.step2 = {};
    $scope.step2.loading_server = true;
    PersonDesktop.share_servers(function(res){
        $scope.step2.loading_server = false;
        var servers = [];
        res.servers.forEach(function(server){
            server.nets.forEach(function(net){
                servers.push({id: server.id, net: {ip_address: net.ip_address, network_id: net.network_id, subnet_id: net.subnet_id}})
            })
        });
        $scope.share_servers = servers;
        $scope.step2.share_server = "";
    })
    $scope.updateHardware = function(){
        var is_win7UP = $scope.reg.test($scope.step1.image.os_type);
        var is_winXP = $scope.regXP.test($scope.step1.image.os_type);
        var is_win = $scope.regWin.test($scope.step1.image.os_type);
        $scope.step2.usb_version = "2.0";
        if(is_win7UP){
            $scope.step2.usb_redir = true;
            $scope.step2.usb_version = "3.0";
        }else if(is_winXP){
            $scope.step2.usb_redir = true;
        }else{
            // $scope.step2.usb_redir = false;
        }
        $scope.step2.usb3_disabled = !is_win7UP ? true : false;
        $scope.step2.isWin = is_win;
        $scope.step2.show_desk_info = false ;
    }
    // 第三步
    $scope.step3 = {};
    $scope.step3.desktopNum2 = 0;
    $scope.get_host = function(){
        if($scope.resources.length) {
            var uuid = $scope.step3.resource.uuid;
            var netid = $scope.step1.network.id;
            var is_gpu = $scope.step2.has_gpu;
            $scope.host_loadding = true;
            $scope.step3.is_all = undefined;
            $scope.hosts = undefined;
            if($scope.step1.resourceType == "hyper-v"){
                Host.query_gpu_agent({
                    id: uuid,
                    network_id: netid,
                    enable_gpu: is_gpu
                }, function(data){
                    $scope.host_loadding = false;
                    $scope.hosts = data.hosts_list.map(function(item){
                        if(item.disabled_tips !== ""){
                            item.disabled_desc = i18n.translate(item.disabled_tips);
                        }
                        return item;
                    });
                });
            }else{
                Host.query_agent({
                    id: uuid,
                    network_id: netid,
                    enable_gpu: $scope.step2.gpu_auto_assignment,
                    check_service: true
                }, function(res){
                    $scope.host_loadding = false;
                    $scope.hosts = res.hosts_list.filter(function(h){ return h.status === "active" });
                });
            }
        }
    };
    $scope.onResourceChange =  function () {
        $scope.get_host();
    }
    var host_storages = {};
    $scope.openMoreDialog = function(){
        var _hostids;
        if($scope.step3.hostType == "0"){
            _hostids = $scope.hosts.filter(function(h){ return h._selected }).map(function(h){ return h.storage_uuid });
        }else{
            _hostids = $scope.hosts.filter(function(h){ return h.instance_num }).map(function(h){ return h.storage_uuid });
        }
        var moreDialog = $modal.open({
            templateUrl:"views/vdi/dialog/desktop/host_config.html",
            controller:"hostConfigDialog",
            resolve:{
                param: function(){
                    return {
                        "phostids":angular.copy(_hostids),
                        "pstore":host_storages
                    }
                }
            }
        });
        moreDialog.result.then(function(){
        });
    };

    $scope.selectAllHost = function(bool){
        var _hosts = $scope.hosts.filter(function(h){
            if($scope.step1.resourceType == "hyper-v"){
                return h.disabled_tips == "";
            }else{
                return true;
            }
        });
        _hosts.map(function(item){
            item._selected = bool;
            return item;
        });
        var num = $filter("selectedFilter")(_hosts, "max_instance");
        $scope.step3.desktopNum = $scope.step2.has_gpu == "through" ? num : 0;
    };
    $scope.selectOneHost = function(){
        var _hosts = $scope.hosts.filter(function(h){
            if($scope.step1.resourceType == "hyper-v"){
                return h.disabled_tips == "";
            }else{
                return true;
            }
        });
        $scope.step3.is_all = _hosts.every(function(item){
            return item._selected === true;
        });
        var num = $filter("selectedFilter")(_hosts, "max_instance");
        $scope.step3.desktopNum = $scope.step2.has_gpu == "through" ? num : 0;
    };
    $scope.getDesktopNumber2 = function(){
        var _lis = angular.copy($scope.hosts.filter(function(item){ return item.instance_num > 0 }));
        if(_lis.length > 0){
            $scope.step3.desktopNum2 = _lis.reduce(function(a, b){
                a.instance_num += b.instance_num;
                return a;
            }).instance_num;
        }else{
            $scope.step3.desktopNum2 = 0;
        }
    };

    $scope.step4 = {};
    $scope.step4.select_users = [];
    $scope.$on("selectStepChange", function(e, arg){
        if(arg.index == 0){
            arg.stepScope.$$nextSibling.error = false;
        }
    })
    $scope.$on("WizardStep_0", function(e, step, scope){
        setTimeout(function(){
            $("[rel=popover-hover]").popover({
                trigger : "hover"
            });
        })
        scope.error = step.is_dirty;
        function toStrLong(ip){
            var ips;
            ips = ip.split(".").map(function(item, idx){
                var _prefix = "";
                for(var i = 0;i < 8 - Number(item).toString(2).length;i++){
                    _prefix += "0";
                }
                return _prefix + Number(item).toString(2);
            });
            return ips.join("");
        }
        function check_net(){
            // 返回值为true时，invalid
            if($scope.step1.subnetwork && $scope.step1.subnetwork.netmask && $scope.step1.subnetwork.enable_dhcp && $scope.step1.ip){
                var _startIP = toStrLong($scope.step1.subnetwork.start_ip);
                var _endIP = toStrLong($scope.step1.subnetwork.end_ip);
                var _bindStartIP = toStrLong($scope.step1.ip);
                return (_bindStartIP < _startIP || _bindStartIP > _endIP);
            }
            return false;
        }

        if(check_net()){
            $.bigBox({
                title	:i18n.translate("INFOR_TIP"),
                content	:$$$MSG.get(12061),
                timeout	:5000
            });
        }
        var sameDesktopName = $scope.rows.filter(function(item){ return item.display_name == $scope.step1.desktopName }).length;
        
        var is_valid = scope.bodyForm1.$valid && !check_net();
        if(!$scope.step1.image) {
            $scope.step1.image = false;
        }
        step.done = is_valid  && !sameDesktopName && $scope.step1.image;
        if(sameDesktopName){
            uihelper.i18nAlert("SAME_PERSONAL_NAME", "INFOR_TIP")
        }
        let isChooseWin = !!(/win/i).exec($scope.step1.image.os_type.toLowerCase());
        let gstatus = $scope.step1.image.guesttool_status;
        window.vdiEnvironment == "development" && console.log("isChooseWin:", isChooseWin, "gstatus:", gstatus);
        if (step.done && isChooseWin && gstatus != "normal") {
            uihelper.i18nAlert("CHOOSE_NEW_GUESTTOOL_TPL_TIP");
        }
        step.done = isChooseWin ? (step.done && gstatus == "normal") : step.done;
        if(step.done && !sameDesktopName){
            HardwareTemplate.filter({
                "system_gb": $scope.step1.image.system_alloc_disk,
                "local_gb": $scope.step1.image.data_alloc_disk,
                "local_gb1": $scope.step1.image.data_alloc_disk_2
            }, function(data){
                $scope.hardwareList = data.result.map(function(data){
                    data.showName = (data.gpu_flag && data.gpu_flag == "defined" && `${data.gpu_name.split(" ")[0]} ${data.gpu_details}` || `${data.gpu_name}` || "");
                    data.memory_mb = data.memory_mb / 1024;
                    return data;
                });
                $scope.step2.hardware = $scope.hardwareList[0];
                $scope.step2.hardware && $scope.updateHardware();
            });
        }
    });
    $scope.$on("WizardStep_1", function(e, step, scope){
        scope.error = step.is_dirty;
        var is_valid = scope.bodyForm2.$valid;
        if(is_valid){
            $scope.step3.desktopNum = undefined;
            $scope.step3.desktopNum2 = 0;
            $scope.get_host();
        }
        step.done = is_valid;
    });
    $scope.$on("WizardStep_2", function(e, step, scope){
        scope.error = step.is_dirty;
        // number类型的input ，max属性是变量，不生效，手动判断
        if($scope.step3.hostType == 0){
            step.done = scope.bodyForm3.$valid && $scope.step3.desktopNum <= $filter("selectedFilter")($scope.hosts, "max_instance");
        }
        if($scope.step3.hostType == 1){
            step.done = scope.bodyForm3.$valid && Boolean($scope.step3.desktopNum2);
        }
    });
    $scope.$on("WizardStep_3", function(e, step, scope){
        scope.error = step.is_dirty;
        if (!$scope.step4.select_users.length) {
            uihelper.i18nAlert("请选择绑定帐号。");
        }
        step.done = $scope.step4.select_users.length ? true : false;
    });
    $scope.$on("WizardDone", function(e, steps, scopes){
        var postData = {};
        var regWin10 = /Windows10/i;
        postData.display_name = $scope.step1.desktopName;
        postData.network_id = $scope.step1.network.id;
        postData.resource_pool	  = $scope.step3.resource.uuid;

        if($scope.step1.subnetwork){
            postData.subnet_id = $scope.step1.subnetwork.id;
        } else {
            postData.subnet_id = "";
        }
        postData.ip_choose = Number($scope.step1.IPmode.value) ? true : false;
        if(postData.ip_choose && Number($scope.step1.IPmode.value) === 2){
            postData.start_ip = $scope.step1.ip;
        }
        postData.image_id     = $scope.step1.image.id;
        postData.rollback      = Number($scope.step2.rollback);
        postData.data_rollback = $scope.step2.hardware.local_gb > 1 || $scope.step2.hardware.local_gb1 > 1 ? Number($scope.step2.data_rollback) : undefined;
        if(postData.rollback === 2){
            postData.rollback_weekday = $scope.step2.rollback_weekday;
        }
        if(postData.rollback === 3){
            postData.rollback_monthday = $scope.step2.rollback_monthday;
        }
        if(postData.data_rollback === 2){
            postData.data_rollback_weekday = $scope.step2.data_rollback_weekday;
        }
        if(postData.data_rollback === 3){
            postData.data_rollback_monthday = $scope.step2.data_rollback_monthday;
        }
        postData.instance_type_id = $scope.step2.hardware.id;
        postData.usb_version = $scope.step1.resourceType == "kvm" ? $scope.step2.usb_version : null;
        postData.usb_redir = postData.usb_version ? true : false;
        /* if($scope.step1.resource.type === "hyper-v")
            postData.enable_gpu       = $scope.step2.has_gpu; */
        if($scope.step1.resourceType === "kvm"){
            postData.gpu_auto_assignment = $scope.step2.gpu_auto_assignment;
            if(regWin10.test($scope.step1.image.os_type)){
                postData.firmware_type = "uefi";
            }
        }
        if($scope.step3.hostType == 0){
            postData.servers = $scope.hosts.filter(function(item){ return item._selected }).map(function(item){
                return {"uuid": item.id}
            });
            postData.count = $scope.step3.desktopNum;
        }
        if($scope.step3.hostType == 1){
            postData.servers = $scope.hosts.filter(function(item){ return item.instance_num > 0 }).map(function(item){
                return { "uuid":item.id, "vm_count":item.instance_num }
            });
            postData.count = $scope.step3.desktopNum2;
        }
        postData.servers_storage = Object.keys(host_storages).map(function(key){
            var host = host_storages[key];
            return {
                uuid:host.id,
                image_storage_capacity: host.image_storage_capacity,
                image_storage_performance: host.image_storage_performance,
                storage_capacity: host.storage_capacity,
                storage_performance: host.storage_performance
            }
        });
        postData.user_id = $scope.step4.select_users.map(function(item){ return item.id ? item.id : item.user_id });
        postData.rule_id = $scope.step4.rule;

        postData.enable_share = $scope.step2.share_server ? true : false;
        if(postData.enable_share) {
            postData.share_server_ip = $scope.step2.share_server.net.ip_address;
            postData.share_server_id = $scope.step2.share_server.id;
        }
        postData.expand_enabled = $scope.step2.expand_enabled;
        postData.screen_watermark_enabled = $scope.step2.show_desk_info;
        $scope.submitting = true;
        PersonDesktop.save(postData, function(res){
            $modalInstance.close();
            console.log(["新增", res])
            console.log(["新增参数", postData])
            $scope.refresh();
        }).$promise.finally(function(){
            $scope.submitting = false;
        });
    });
    $scope.close = function(){
        $modalInstance.close();
    };
})
.controller("alterPersonalDialog", function($scope, $modalInstance, Network, User, Admin, PersonDesktop, Domain, $q, i18n, $http, $modal){
    "inject";
    let outScope = $scope;
    let models = $scope.m = {
        gpu: "",
        gpus: [],
        allGpus: [],
        card: "1"
    }
    function getAllGpus (flag, name, details) {
        $http.get("/thor/flavors/gpus").then(function (res) {
            res = res.data;
            if(res.code == 0) {
                let gpus = res.gpus;
                angular.forEach(gpus, function(gpu) {
                    let details = gpu.details && ` / ${gpu.details}` || "";
                    let name = gpu.flag == "undefined" && `${gpu.name}` || `${gpu.name.split(" ")[0]}`;
                    gpu.showName = name + details;
                })
                models.allGpus = res.gpus;
                if(!flag) {
                    models.card = "1";
                } else if (flag == "defined") {
                    models.card = "3";
                } else if (flag == "undefined") {
                    models.card = "2";
                }
                $scope.onCardChange();
                models.gpu = models.gpus.filter(function (g) { return g.flag == flag && g.name == name && g.details == details })[0]
            }
        })
    }
    $scope.onCardChange = function (){
        if(models.card == "2") {
            models.gpus = models.allGpus.filter(function (g) { return g.flag == "undefined" } );
        } else if (models.card == "3") {
            models.gpus = models.allGpus.filter(function (g) { return g.flag == "defined" } );
        }else {
            models.gpus = [];
        }
        models.gpu = models.gpus[0];
    }
    $scope.IPs = [];
    $scope.IPmodes1 = [{name: i18n.translate("不分配"), value: 0}];
    $scope.IPmodes2 = [{name: i18n.translate("系统分配"), value: 1}, {name: i18n.translate("固定IP"), value: 2}];
    $scope.datas = angular.copy($scope.currentItem);
    $scope.datas.show_desk_info = $scope.datas.screen_watermark_enabled;
    console.log(["$scope.datas", $scope.datas])
    let flavor = $scope.datas.flavor;
    getAllGpus(flavor.gpu_flag, flavor.gpu_name, flavor.gpu_details);
    if($scope.datas.ips){
        $scope.IPmodes = $scope.IPmodes2;
        $scope.datas.IPmode = $scope.IPmodes[1];
    }else{
        $scope.IPmodes = $scope.IPmodes1;
        $scope.datas.IPmode = $scope.IPmodes[0];
    }
    $scope.datas.usb_version = $scope.datas.usb_redir ? $scope.datas.usb_version : "";
    $scope.datas.memory_mb = $scope.datas.memory_mb / 1024;
    $scope.btndisks = [];
    PersonDesktop.list_detail({id:$scope.datas.id}, function(res){
        $scope.detailData = res.result;
        ["data_rollback_weekday", "data_rollback_monthday", "rollback_weekday", "rollback_monthday"].forEach(key => {
            $scope.detailData[key] = $scope.detailData[key] || 1;
        });
        $scope.get_net(true);
        $scope.loading_server = true;
        PersonDesktop.share_servers(function(res){
            $scope.loading_server = false;
            var servers = [];
            res.servers.forEach(function(server){
                server.nets.forEach(function(net){
                    servers.push({id: server.id, net: {ip_address: net.ip_address, network_id: net.network_id, subnet_id: net.subnet_id}})
                })
            });
            $scope.share_servers = servers;
            if($scope.detailData.share_server_ip){
                $scope.detailData.share_server = $scope.share_servers.filter(function(item){ return item.net.ip_address == $scope.detailData.share_server_ip })[0]
                if(!$scope.detailData.share_server){
                    var _server = {net:{ip_address:$scope.detailData.share_server_ip, unconnect:true}}
                    $scope.share_servers.push(_server);
                    $scope.detailData.share_server = _server;
                }
            }else{
                $scope.detailData.share_server = "";
            }
        })
    });

    $scope.get_net = function(flag){
        $scope.loading = true;
        Network.query(function(res){
            // 过滤无子网网络
            $scope.loading = false;
            // $scope.networks = res.networks.filter(function(net){ return net.subnets.length > 0});
            $scope.networks = res.networks;
            if($scope.detailData.network) {
                $scope.datas._network = $scope.networks.filter(function(item){ return item.id === $scope.detailData.network.id })[0];
                $scope.get_sub_net($scope.datas._network, flag);
            }
        });
    };

    $scope.get_sub_net = function(network, flag){
        if(network.subnets.length){
            $scope.loading = true;
            Network.query_sub({id:network.id}, function(res){
                $scope.loading = false;
                $scope.subnetworks = res.result;
                if(flag){
                    $scope.datas._subnetwork = $scope.subnetworks.filter(function(item){ return item.id === $scope.detailData.subnet_id })[0]
                }else{
                    $scope.datas._subnetwork = $scope.subnetworks[0];
                }
                $scope.clearBindIp();
            });
        }else{
            $scope.subnetworks = [];
            $scope.datas._subnetwork = null;
            $scope.clearBindIp();
        }

    };
    var first = true;
    $scope.clearBindIp = function(){
        if(first){
            first = false;
        }else{
            if($scope.datas._subnetwork){
                $scope.IPmodes = $scope.IPmodes2;
            }else{
                $scope.IPmodes = $scope.IPmodes1;
            }
            $scope.datas.IPmode = $scope.IPmodes[0];
            $scope.datas.ips = null;
        }
    };
    $scope.get_disks = function(){
        $scope.loading_disk = true;
        PersonDesktop.list_passive_disk({
            user_id:$scope.datas._user.id,
            instance_id:$scope.datas.instance_id
        }, function(res){
            $scope.loading_disk = false;
            $scope.disks = res.result;
        });
    };
    $scope.$watch("datas._user", function(newval){
        if(newval){
            $scope.get_disks();
        }
    });
    $scope.expandedNodes = [];
    function formatData(d, name){
        iteration(d, name);
        return d;
    }
    function iteration(data, childName, list){
        for(var i = 0 ; i < data.length ; i++){
            $scope.expandedNodes.push(data[i]);
            if(data[i][childName] && data[i][childName].length){
                var len = iteration(data[i][childName], childName);
                if(len === 0){
                    data[i] = undefined;
                }
            }
            if(!data[i]) { continue; }
            if(data[i].users && data[i].users.length > 0){
                data[i].users.map(user => {
                    user.name = user.name || user.user_name;
                    user._is_last = true;
                    return user;
                });
                data[i][childName] = data[i].users;
            }
            if(data[i][childName] && data[i][childName].length === 0){
                data[i] = undefined;
            }
        }
        while(data.length > 0) {
            // 如果有数组元素为空，每次删除一个
            var oldlen = data.length;
            for(i = 0 ; i < oldlen ; i++){
                if(data[i] === undefined){
                    data.splice(i, 1);
                    break;
                }
            }
            if(oldlen === data.length) {
                break;
            }
        }

        return data.length;
    }
    function removeNoChildrenDeparts(data) {
        data = data.filter(noUserFilter);
        data.forEach(walk);
        return data;
        function walk(node) {
            if(!node.dept_id) { return; }
            // 用户上级是没有 children 的
            if(node.children) {
                node.children = node.children.filter(noUserFilter);
                node.children.forEach(walk);
            }
        }
        function noUserFilter(node) {
            if(node.dept_id && !node.children && node.users.length === 0) {
                return false;
            }
            return true;
        }
    }
    $scope.$on("selectCommonUser", function(e, user){
        $scope.datas._is_open = false;
        $scope.datas._user = user;
    })
    $q.all([Admin.query().$promise, User.query_tree().$promise, Domain.list().$promise]).then(function(arr){
        $scope.admin_users = arr[0].users.filter(function (a) { return !a.is_uaa });
        $scope.admin_users_uaa = arr[0].users.filter(function (a) { return a.is_uaa });
        $scope.common_users = arr[1].result;
        let uaa_commons = arr[1].uaa_result;
        $scope.common_users = formatData(removeNoChildrenDeparts($scope.common_users), "children");
        $scope.common_users_uaa = formatData(removeNoChildrenDeparts(uaa_commons), "children");
        $scope.domain_users = arr[2].result;
        var commonUser = [];
        $scope.expandedNodes.forEach(function(node){
            node.children.forEach(function(user){
                if(user.user_id && !user.dept_id){
                    user.id = user.user_id;
                    commonUser.push(user);
                }
            })
        })
        var dus = $scope.domain_users.reduce(function(arr, b){
            b.groups.forEach(function(g){
                [].push.apply(arr, g.users);
            });
            return arr;
        }, []);
        var all_users = $scope.admin_users
            .concat($scope.admin_users_uaa)
            .concat(commonUser)
            .concat(dus)
        $scope.datas._user = all_users.filter(function(user){ return user.id == $scope.datas.user_id })[0];
    })
    $scope.name = function(net){
        var is_dhcp = net.enable_dhcp;
        if(is_dhcp){
            return net.name + " ( " + net.start_ip + " - " + net.end_ip + " ) ";
        }else{
            return net.name;
        }
    };
    $scope.user_name = function(user){
        return user.name + " ( " + user.real_name + " ) ";
    };
    $scope.onChangeUser = function () {
        $modal.open({
            size: "md",
            templateUrl: "views/vdi/dialog/desktop/user-select-modal.html",
            controller: function ($scope, $modalInstance) {
                let models = $scope.m = {
                    selectUser: null
                }
                $scope.ok = function () {
                    models.selectUser.name = models.selectUser.username;
                    outScope.datas._user = models.selectUser;
                    $modalInstance.close();
                }
                $scope.close = function () {
                    $modalInstance.close();
                }
            }
        }).result.finally(function () {
            // ignore
        });
    }
    $scope.ok = function(){
        $scope.loading = true;
        var volumes = $scope.disks.filter(function(d){ return d._selected });
        var _local_gb = $scope.btndisks.length ? $scope.btndisks[0].local_gb : undefined
        var is_data_disk = Boolean(_local_gb || $scope.datas.local_gb);
        var postData = {
            id:$scope.datas.id,
            display_name:$scope.datas.display_name,
            user_id:$scope.datas._user.id,
            vcpu:$scope.datas.vcpu,
            memory_mb:$scope.datas.memory_mb * 1024,
            network_id:$scope.datas._network.id,
            subnet_id:$scope.datas._subnetwork ? $scope.datas._subnetwork.id : "",
            local_gb:_local_gb,
            ip:$scope.datas.ips ? $scope.datas.ips : undefined,
            gpu_auto_assignment: $scope.datas.enable_gpu,
            vm_hostname:$scope.datas.vm_hostname,
            rollback:$scope.detailData.rollback,
            rollback_weekday:$scope.detailData.rollback == 2 ? $scope.detailData.rollback_weekday : undefined,
            rollback_monthday:$scope.detailData.rollback == 3 ? $scope.detailData.rollback_monthday : undefined,
            attach_volumes:volumes,
            usb_redir:$scope.datas.usb_version ? true : false,
            usb_version: $scope.datas.usb_redir ? $scope.datas.usb_version : undefined,
            data_rollback:is_data_disk ? $scope.detailData.data_rollback : undefined,
            enable_share: $scope.detailData.share_server ? true : false,
            share_server_ip: $scope.detailData.share_server && $scope.detailData.share_server.net.ip_address || undefined,
            share_server_id: $scope.detailData.share_server && $scope.detailData.share_server.id || undefined,
            expand_enabled: $scope.datas.expand_enabled,
            screen_watermark_enabled: $scope.datas.show_desk_info
        };
        if(postData.data_rollback == 2){
            postData.data_rollback_weekday = $scope.detailData.data_rollback_weekday;
        }
        if(postData.data_rollback == 3){
            postData.data_rollback_monthday = $scope.detailData.data_rollback_monthday;
        }
        if(models.card == "1") {
            postData.gpu_details = "";
            postData.gpu_flag = "";
            postData.gpu_name = "";
        } else if (models.card == "2"){
            postData.gpu_details = "";
            postData.gpu_flag = "undefined";
            postData.gpu_name = models.gpu.name;
        } else if (models.card == "3") {
            postData.gpu_details = models.gpu.details;
            postData.gpu_flag = "defined";
            postData.gpu_name = models.gpu.name;
        }
        PersonDesktop.update(postData, function(res){
            console.log(["修改参数", postData, "修改返回", res])
            $modalInstance.close();
            $scope.refresh();
        }).$promise.finally(function(){
            $scope.loading = false;
           
        });
    };
    $scope.close = function(){
        $modalInstance.close();
    };
})
.controller("snapshotPersonalDialog", function($scope, $modalInstance, VMCommon, i18n){
    "ngInject";
    $scope.rows = [];
    function get_list(){
        $scope.loading = true;
        VMCommon.list_snapshot({ instance_id: $scope.currentItem.instance_id }, function(res){
            $scope.rows = res.snapshots.map(function(item, index){
                item.snapshot_name = item.name;
                item.display_description = item.desc;
                item.editable = false;
                return item;
            }).sort(function(a, b){
                return (new Date(b.create_at)).getTime() - (new Date(a.create_at)).getTime() > 0 ? 1 : -1;
            });
        }).$promise.finally(function(){
            $scope.loading = false;
        });
    }
    get_list();
    $scope.close = function(){
        $modalInstance.close();
    };
    $scope.hasSaveButton = function(){
        return $scope.rows.filter(function(item){ return item.editable }).length
    };
    $scope.hasSubmit = function(){
        return $scope.rows.filter(function(item){ return item._submitting }).length
    };
    $scope.save = function(cur){
        cur._submitting = true;
        VMCommon.take_snapshot({
            method:"save",
            name:cur.snapshot_name,
            instance_id:$scope.currentItem.instance_id,
            desc:cur.display_description
        }).$promise.then(function(){
            $modalInstance.close();
            get_list();
        })
        .finally(function(){
            cur._submitting = false;
        });
    }

    $scope.addNew = function(){
        var manuals = $scope.rows.filter(function(item){ return item.created_by == "manual" }).length;
        if(manuals == 2){
            $.bigBox({
                title : i18n.translate("INFOR_TIP"),
                content : i18n.translate("只能创建两个手动快照"),
                icon : "fa fa-warning shake animated",
                timeout : 6000
            });
        }else{
            $scope.rows.unshift({"editable":true});
        }
    };
    $scope.delete = function(cur){
        cur._submitting = true;
        if(cur.editable){
            var idx = $scope.rows.indexOf(cur);
            $scope.rows.splice(idx, 1);
        }else{
            VMCommon.delete_snapshot({
                snapshot_name:cur.snapshot_name,
                snapshot_volumes:cur.snapshot_volumes,
                instance_id:$scope.currentItem.instance_id
            }, function(res){
                var idx = $scope.rows.indexOf(cur);
                $scope.rows.splice(idx, 1);
            }).$promise.finally(function(){
                cur._submitting = false;
            });
        }
    };
    $scope.restore = function(cur){
        cur._submitting = true;
        VMCommon.restore_snapshot({
            method:"restore",
            snapshot_volumes:cur.snapshot_volumes,
            snapshot_name:cur.snapshot_name,
            instance_id:$scope.currentItem.instance_id
        }, function() {
            $modalInstance.close();
            get_list();
        }).$promise.finally(function(){
            cur._submitting = false;
            get_list();
        });
    }
})
.controller("personalAddServerDialog", function($scope, Server, $modalInstance, param){
    "ngInject";
    Server.query(function(res){
        $scope.servers = res.servers;
        $scope.server = $scope.servers[0];
    });
    $scope.post = function(){
        var _this = this;
        $scope.submiting = true;
        Server.domain_set_person({
            instance_ids:param.map(function(p){ return p.id }),
            has_domain:true,
            ad_server_id:_this.server.id,
            recreate_sid:_this.is_sid
        }, function(res){
            $modalInstance.close();
        }).$promise.finally(function(){
            $scope.submiting = false;
        });
    };
    $scope.close = function(){
        $modalInstance.dismiss();
    };
})
.controller("SaveAsTplCtrl", SaveAsTplCtrl)
.controller("SaveAsTplCtrl1", SaveAsTplCtrl1)
.controller("SaveAsTplCtrl2", SaveAsTplCtrl2)
.controller("dissociateDiskCtrl", dissociateDiskCtrl)
function NewTemplateCtrl($scope, $modalInstance){
    let models = $scope.p = {
        stepIndex: 1,
        loading: false
    };
    $scope.setModal = function(key, value){
        if(models.hasOwnProperty(key)) {
            models[key] = value;
        }
    };
    let stepData = [];
    $scope.getStepData = function(step){
        return stepData[step - 1] || {};
    };
    $scope.setStepData = function(step, data){
        stepData[step - 1] = data;
    };
    const callOnce = require("once");
    $scope.closeModal = callOnce(() => $modalInstance.close());
    $scope.isValid = function(){
        return this.form.$valid;
    };
    $scope.onPrev = function(){
        let myStep = this.getCurrentStep();
        $scope.setStepData(myStep, this.m);
        $scope.setModal("stepIndex", myStep - 1);
    };
    $scope.onNext = function(){
        let myStep = this.getCurrentStep();
        $scope.setStepData(myStep, this.m);
        $scope.setModal("stepIndex", myStep + 1);
    };
}
function SaveAsTplCtrl ($scope, $modalInstance, productType) {
    let tpl = $scope.currentItem = angular.copy($scope.currentItem);
    $scope.originData = tpl;
    $scope.productType = productType;
    NewTemplateCtrl ($scope, $modalInstance);
}
/**
 * 另存为模板-1基本信息
 * 名称/描述/模板类型/可用范围/教室范围
 * @param {*} $scope
 * @param {*} $modalInstance
 */
function SaveAsTplCtrl1 ($scope, $http) {
    let item = $scope.originData;
    let models = $scope.m = {
        name: "",
        description: "",
        type: 2,
        class_refers: item.class_refers || [],
        schoolrooms: [],
        scopeType: "all"
    }
    Object.assign(models, $scope.getStepData(1));
    $scope.getCurrentStep = () => 1;
    function getClasses () {
        $http.get("/thor/pools", {
            params: {
                managed:false
            }
        }).then(function (res) {
            res = res.data;
            if(res.code == 0) {
                let classes = res.pools_;
                if(item.class_refers && item.class_refers.length) {
                    angular.forEach(models.schoolrooms, function (pool) {
                        let curId = pool.id;
                        if(item.class_refers.indexOf(curId) > -1) {
                            pool._selected = true;
                        }
                    })
                }
                models.schoolrooms = classes;
                models.scopeType = item.class_refers && item.class_refers.length ? "select" : "all";
            }
        })
    }
    getClasses();
    $scope.$watch("m.type", function (val) {
        if(val == 1) {
            $scope.isValid = function(){
                let valid = this.form.$valid;
                if(models.scopeType !== "all") {
                    valid = valid && models.schoolrooms.some(room => room._selected);
                }
                return valid;
            };
        } else if (val == 5) {
            models.scopeType = "all";
        } else {
            $scope.isValid = function(){
                return this.form.$valid;
            };
        }
    })
}
/**
 * 另存为模板-2模板配置
 * 计算节点/网络/子网/IP地址
 * @param {*} $scope
 * @param {*} $modalInstance
 */
function SaveAsTplCtrl2 ($scope, $http, currentUser, uihelper) {
    let item = $scope.originData;
    let models = $scope.m = {
        bindIP: "",
        bindType: "auto",
        hosts: [],
        host: null,
        networks: [],
        network: null,
        is_copy: true,
        saveLoading: false,
        netLoading: false,
        network_loading: false,
        host_loading: false
    }
    Object.assign(models, $scope.getStepData(2));
    let data1 = $scope.getStepData(1);
    $scope.getCurrentStep = () => 2;
    // 获取计算节点
    function getHosts(type, rbd_enabled) {
        models.host_loading = true;
        models.netLoading = true;
        $http.get("/thor/hosts_with_virtual_type", {
            params: {
                virtual_type: type,
                rbd_enabled: rbd_enabled
            }
        }).then(function (res) {
            res = res.data;
            models.host_loading = false;
            models.hosts = res.result;
            models.host = models.hosts[0];
            getNetwork(models.host);
        }, function () {});
    }
    // 获取网络
    function  getNetwork (host) {
        if (host) {
            $http.get("/thor/list_network_with_host", {
                params: { host: host.host_uuid }
            }).then(function (res) {
                res = res.data;
                let networks = res.result;
                networks = networks.filter(function (net) { return !net.external });
                models.networks = networks;
                models.network = models.networks[0];
                getSubnets(models.network);
            }, function () { });
        }
    }
    // 获取子网
    function getSubnets (net) {
        if (net.subnets.length) {
            models.network_loading = true;
            $http.get(`/thor/network/${ net.id }/subnets`)
            .then(function (res) {
                res = res.data;
                models.subnets = res.result;
                models.subnet = models.subnets[0];
                switchIps(models.subnet);
                models.network_loading = false;
            }).finally(() => models.netLoading = false)
        } else {
            models.subnets = [];
            models.subnet = null;
            switchIps(models.subnet);
            models.netLoading = false;
        }
    }
    function switchIps(subnet) {
        if (subnet) {
            models.bindType = "auto";
        } else {
            models.bindIP = "";
            models.bindType = "none";
        }
    }
    function switchSubnet (val) {
        getSubnets(val);
    }
    $scope.switchIps = switchIps;
    $scope.switchSubnet = switchSubnet;
    getHosts(item.virtual_type, item.rbd_enabled);
    // *getTwoTypes
    const {type, product_type} = uihelper.getTwoTypes(data1.type);
    window.vdiEnvironment == "development" && console.log(type, product_type);
    $scope.ok = function () {
        var bindIP = models.bindIP;
        var _ip = models.bindType === 'static' ? bindIP : undefined;
        let opt = {
            data: {
                owner: currentUser.id,
                name: data1.name,
                description: data1.description,
                image_id: item.image_id,
                class_refers: data1.scopeType == "all" ? [] : data1.schoolrooms.filter(function(cla) {return cla._selected }).map(function(cla) { return cla.id }),
                network: models.network.id,
                subnet: models.subnet ? models.subnet.id : '',
                band_ip: _ip,
                band_type: models.bindType,
                host_uuid: models.host.host_uuid,
                instance_id: item.instance_id,
                os: item.os_type,
                virtual_type: item.virtual_type,
                type,
                product_type,
            }
        };
        models.saveLoading = true;
        // 胡海：clone接口 换 新建接口
        $http.post(`/api/images`, opt).then(function (res) {
            $scope.closeModal();
            models.saveLoading = false;
        }, function () {
            models.saveLoading = false;
        });
    }
}


/**
 * 游离数据盘管理功能
 */
function dissociateDiskCtrl($scope, $http, uihelper, $modalInstance){
    "ngInject";
    let models = $scope.m = {
        disks: [],
        checkAll: false,
        loading: false
    };
    $scope.$watch("m.checkedAll", function(val){
        models.disks.forEach(d => {
            d._selected = val;
        });
    });
    const refresh = function(){
        models.loading = true;
        $http.get("/thor/passive_volumes").then((resp) => {
            models.disks = resp.data.result;
        }).finally(() => {
            models.loading = false;
        });
    };
    refresh();

    $scope.cancel = function(){
        $modalInstance.dismiss();
    };

    $scope.hasSelected = function(){
        return models.disks.filter(x => x._selected).length > 0;
    };

    $scope.remove = function(){
        uihelper.confirmWithModal("删除游离盘", "remove-dissociate-disk-tips", null, true).then(() => {
            let disks = models.disks.filter(x => x._selected).map(x => x.volume_id);
            return $http.delete("/thor/passive_volumes", {data: {volume_ids: disks}});
        }).then(refresh);
    };
}