module.exports = function listToTree (source, opt = {}) { // 平行结构转树结构
    let {idProp = "id", parentProp = "parent", childProp = "children", rootId = null, disabled} = opt;
    const cloneData = source;
    let tree = cloneData.filter(item =>{ // 找根节点1：通过指定rootId找到根节点
        return item[idProp] == rootId;
    })
    if (!tree.length) { // 找根节点2：没有parent_id的节点为根节点,他的id作为rootId
        tree = cloneData.filter(item =>{
            if (!item[parentProp]) {
                rootId = item.id;
                return true;
            }
        })
    }
    if (!tree.length) {
        tree = cloneData.filter(item =>{
            if (item.name == "default" || item.name == "VOI-default" || item.name == "IDV-default") {
                rootId = item.id;
                return true;
            }
        });
        console.error("该数据找不到根节点，取default作为根节点!", rootId);
    }
    if (!tree.length) console.error("该数据找不到根节点!", rootId);
    tree[0][childProp] =  cloneData.filter(p=>{
        let branchArr = cloneData.filter(child => p[idProp] == child[parentProp]);
        if (branchArr.length > 0 ) {
            p[childProp] = branchArr;
            if (disabled) p.disabled = true; // 有子元素的就不能被移动至，故禁用掉
        } else {
            p[childProp] = [];
        }
        return p[parentProp] == rootId
    })
    return tree;
}