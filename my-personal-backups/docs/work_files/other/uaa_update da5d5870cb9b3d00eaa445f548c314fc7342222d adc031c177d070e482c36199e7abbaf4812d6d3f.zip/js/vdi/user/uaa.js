require('./uaa.css');

const ipReg = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
let { debounce } = require('lodash');
angular.module("vdi.user")
.controller("vdiUserUAAManageController", function($scope, $http, uihelper, $rootScope, $modal){
    let _scope = $scope;
    let models = $scope.m = {
        loading: false,
        searchText: "",
        is_uaa: false,
        config: {
            host: null,
            port: null
        }
    };
    $scope.paginationType = 1;
    $scope.currentPage = 1;
    $scope.pagesize = Number($$$storage.getSessionStorage('uua_pagesize')) || 30;
    $scope.$watch("pagesize", function (newvalue) {
        $scope.pagesize = newvalue || 30;
        $$$storage.setSessionStorage('uua_pagesize', newvalue ? newvalue : 30)
    });
    $scope.pageChange = function(){
        refresh();
    };
    $scope.rows = [];
    const getConfig = function () {
        $http.get("/thor/uaa/open").then(function (res) {
            let config = res.data;
            models.is_uaa = config.is_open_uaa;
        })
    }
    getConfig();
    // 为了防止 事件绑定多次引起了多次调用接口的问题
    var destroyInsert = $rootScope.$on("refresh-list-uaa", function () {
        getConfig();
        refresh();
    })
    $scope.$on("$destroy", function() {
        destroyInsert();
    })
    const refresh = function(){
        $scope.rows = [];
        models.loading = true;
        let params = {
            keyword: models.searchText,
            page_size: $scope.pagesize || 30,
            page_num: $scope.currentPage || 1
        };
        $http.get("/thor/uaa/manager", {params}).then(resp => {
            let rows = resp.data.result;
            rows.forEach((item) => {
                item.deptLabel = (item.u_department || "-") +
                ("/" + (item.major || "-")) +
                ("/" + (item.grade || "-")) +
                ("/" + (item.u_class || "-"));
            })
            $scope.rows = rows;
            $scope.totalCount = resp.data.total_num;
            models.config.host = resp.data.uaa_host;
            models.config.port = resp.data.uaa_port;
        }).finally(function(){
            models.loading = false;
        });
    };
    let last;
    $scope.doFilter = function(e){
        last = e.timeStamp;
        setTimeout(function () {
            if(last - e.timeStamp == 0){
                refresh();
            }
        }, 500)
    };
    $scope.importAccount = function(){
        uihelper.openModal({
            templateUrl: "views/vdi/dialog/user/uaa_import_account.html",
            controller: "ImportAccountCtrl"
        }).result.then(refresh);
    };
    $scope.sync = function(){
        /* $http.get("/thor/uaa/update").then(function (res) {
            let resp = res.data;
            if(resp.code == 0) {
                let total = resp.total_users;
                let del = resp.delete_user;
                let success = total - del;
                uihelper.i18nAlert(["STATISTICS_NUM", total, success, del]);
                refresh();
            }
        }); */
        $modal.open({
            size: "sm",
            footer: false,
            template: `
                <div class="modal-header">
                        <button type="button" class="close" data-ng-click="cancel()" ng-disabled="loading">
                            <span aria-hidden="true">×</span><span class="sr-only">Close</span>
                        </button>
                        <h4 class="modal-title" localize="一键同步"></h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal">
                            <p style="margin-bottom:20px;word-break: break-all;white-space:pre-wrap;" localize="一键同步确认"></p>
                            <footer class="text-right">
                                <img ng-if="loading" src="img/loadingtext.gif" width="24px" height="24px">
                                <button ng-disabled="loading" class="btn btn-default" data-ng-click="ok()" data-localize="确定">
                                </button>
                                <button ng-disabled="loading" class="btn btn-default" data-ng-click="cancel()" style="margin-left:5px;" data-localize="取消">
                                </button>
                            </footer>
                        </form>
                    </div>
            `,
            controller: function ($scope, $modalInstance) {
                $scope.loading = false;
                $scope.ok = function () {
                    $scope.loading = true;
                    $http.get("/thor/uaa/update").then(function (res) {
                        let resp = res.data;
                        if(resp.code == 0) {
                            let total = resp.total_users;
                            let del = resp.delete_user;
                            let success = total - del;
                            $modalInstance.close();
                            uihelper.i18nAlert(["STATISTICS_NUM", total, success, del]);
                            refresh();
                        }
                    }).finally(() => $scope.loading = false);
                }
                $scope.cancel = function () {
                    $modalInstance.close();
                }
            }
        }).result.finally(refresh);
    };
    $scope.config = function(){
        let data = $scope.rows.filter(function (r) { return r._selected });
        uihelper.openModal({
            templateUrl: "views/vdi/dialog/user/uaa_account_setting.html",
            controller: "AccountSettingCtrl",
            scope: _scope,
            resolve: {
                params: function () {
                    return data;
                }
            }
        }).result.then(refresh);
    };
    /**
     * 一键导入
     */
    $scope.importAll = function () {
        $modal.open({
            size: "sm",
            footer: false,
            template: `
                <div class="modal-header">
                        <button type="button" class="close" data-ng-click="cancel()" ng-disabled="loading">
                            <span aria-hidden="true">×</span><span class="sr-only">Close</span>
                        </button>
                        <h4 class="modal-title" localize="一键导入"></h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal">
                            <p style="margin-bottom:20px;word-break: break-all;white-space:pre-wrap;" localize="一键导入确认"></p>
                            <footer class="text-right">
                                <img ng-if="loading" src="img/loadingtext.gif" width="24px" height="24px">
                                <button ng-disabled="loading" class="btn btn-default" data-ng-click="ok()" data-localize="确定">
                                </button>
                                <button ng-disabled="loading" class="btn btn-default" data-ng-click="cancel()" style="margin-left:5px;" data-localize="取消">
                                </button>
                            </footer>
                        </form>
                    </div>
            `,
            controller: function ($scope, $modalInstance) {
                $scope.loading = false;
                $scope.ok = function () {
                    $scope.loading = true;
                    $http.get("/thor/uaa/save").then(() => {
                        $modalInstance.close();
                    }).finally(() => $scope.loading = false);
                }
                $scope.cancel = function () {
                    $modalInstance.close();
                }
            }
        }).result.finally(refresh);
        /* uihelper.confirmWithModal("一键导入", "一键导入确认").then(() => {
            $http.get("/thor/uaa/save")
        }); */
    };
    $scope.remove = function(){
        uihelper.confirmWithModal("提示", "uaa-remove-tips").then(() => {
            let ids = this.rows.filter(x => x._selected).map(x => x.id);
            $http.delete("/thor/uaa/manager", {params: {ids}}).finally(refresh);
        });
    };
    $scope.hasConfigHostAndPort = function () {
        return models.config.host && models.config.port;
    }
    $scope.modifyAddress = function () {
        let config = models.config;
        uihelper.openModal({
            templateUrl: "views/vdi/dialog/user/uaa_modify_address.html",
            controller: function ($scope, $modalInstance, uihelper) {
                "ngInject";
                let models = $scope.m = {
                    ipReg: ipReg,
                    host: config.host,
                    port: config.port * 1,
                    loading: false,
                    new_host: false
                }
                $scope.isValid = function () {
                    return !((models.host == config.host) && (models.port == config.port));
                }
                $scope.ok = function () {
                    models.loading = true;
                    $http.post("/thor/uaa/address", {
                        "uaa_ip":  models.host,
                        "uaa_port": models.port,
                        "new_host": models.new_host
                    }).then(function (resp) {
                        if(resp.data.code == 0) {
                            $modalInstance.close();
                        }
                    }).finally(function () { models.loading = false; })
                }
                $scope.cancel = function () {
                    $modalInstance.dismiss();
                }
            }
        }).result.then(refresh);
    }
    $scope.releaseAddress = function () {
        let config = models.config;
        uihelper.openModal({
            templateUrl: "views/vdi/dialog/user/uaa_release_address.html",
            controller: function ($scope, $modalInstance) {
                "ngInject";
                let models = $scope.m = {
                    ipReg: ipReg,
                    host: config.host,
                    port: config.port * 1,
                    loading: false
                }
                $scope.isValid = function () {
                    return (models.host == config.host) && (models.port == config.port);
                }
                $scope.ok = function () {
                    models.loading = true;
                    $http.delete("/thor/uaa/address").then(function (resp) {
                        if(resp.data.code == 0) {
                            $modalInstance.close();
                        }
                    }).finally(function () { models.loading = false; })
                }
                $scope.cancel = function () {
                    $modalInstance.dismiss();
                }
            }
        }).result.then(refresh);
    }
    refresh();
})
// 导入帐号 界面需要需求继续确定
/*
.controller("ImportAccountCtrl", function($scope, $http, $modalInstance, networkUtils, uihelper){
*/
.controller("ImportAccountCtrl", function($scope, $http, $modalInstance, networkUtils, uihelper, $filter){
    let models = $scope.m = {
        step: 1,
        host: "", // 172.16.241.111
        port: 5767, // 5767
        departs: [],
        loading: false,
        type: 1, // 按帐号导入1 按院系导入2
        searchText: "",
        searching: false,
        checking: false,
        ipReg: ipReg,
        packMap: {}
    };
    function createObj () {
        return {
            data: [],
            checkAll: false,
            page: 1,
            pageSize: 30
        }
    }
    models.pack = createObj();
    models.origin = createObj();
    $scope.rows = [];  // 占位用的
    $scope.sortOrigin = function (name, asc) {
        models["origin"].data.sort(function (a, b) {
            if (!getPageItems("origin").map((item) => item.id).includes(a.id) ||
             !getPageItems("origin").map((item) => item.id).includes(b.id)) {
                return 0;
            }
            return (a[name] > b[name] ? 1 : -1) * (asc ? 1 : -1);
        });
    };
    $scope.sortPack = function (name, asc) {
        models["pack"].data.sort(function (a, b) {
            if (!getPageItems("pack").map((item) => item.id).includes(a.id) ||
             !getPageItems("pack").map((item) => item.id).includes(b.id)) {
                return 0;
            }
            return (a[name] > b[name] ? 1 : -1) * (asc ? 1 : -1);
        });
    }
    $scope.onPageChange = function (key) {
        models[key].checkAll = false;
        models[key].data.forEach(item => {
            item.checked = false;
        });
    };
    const getPageItems = $scope.getPageItems = function (key) {
        return $filter("paging")(models[key].data, models[key].page, models[key].pageSize) || [];
    };
    $scope.onAllSel = function (key) {
        uihelper.downCheck(getPageItems(key), models[key].checkAll);
    }
    $scope.onOneSel = function (key) {
        uihelper.upCheck(getPageItems(key), (flag) => {
            models[key].checkAll = flag;
        });
    }
    const checkIsConfig = function () {
        models.checking = true;
        $http.get("/thor/uaa/flag").then((res) => {
            let respBool = Boolean(res.data.result);
            models.step = respBool ? 2 : 1;
            if (models.step == 2) {
                getData();
            }
        }).finally(() => models.checking = false);
    }
    checkIsConfig();
    function getData () {
        getDepart();
        getSearch();
    }
    const checkAddress = function(){
        models.loading = true;
        return $http.post("/thor/uaa/address", {
            "uaa_ip": models.host,
            "uaa_port": models.port
        }).finally(function () { models.loading = false; });
    };
    const getDepart = function () {
        return $http.get("/thor/uaa/department").then(function (res) {
            let departs = res.data.result;
            models.departs = departs.map(function (de) { return {name: de, checked: false} });
        }).finally(function () { models.loading = false; });
    }
    const getSearch = function () {
        let searchText = models.searchText.trim();
        models.searching = true;
        models["origin"].checkAll = false;
        models["origin"].data = [];

        return $http.post("/thor/uaa/manager", {
            "keyword": [searchText],
            "is_create": 0
        }).then((res) => {
            let users = res.data.result || [];
            users.forEach(item => {
                item.deptLabel = (item.department || "-") +
                ("/" + (item.major || "-")) +
                ("/" + (item.grade || "-")) +
                ("/" + (item.class || "-"));
            });
            models["origin"].data = users;
            refreshMap();
        }).finally(() => models.searching = false);
    }
    const refreshMap = function () {
        let map = {};
        models.pack.data.forEach((u) => {
            map[u.id] = u;
            u.checked = false;
            u.disabled = false;
        })
        models.origin.data.forEach((u) => {
            u.checked = false;
            u.disabled = !!map[u.id];
        })
    }
    // 步骤一表单验证
    $scope.isStep1Valid = function(){
        let { host, port } = models;
        return networkUtils.isServerAddress(host) && port > 1 && port <= 65535;
    };
    $scope.isValid = function(){
        if (models.type == 2) {
            return models.departs.filter(x => x.checked).length > 0;
        } else {
            return models.pack.data.length;
        }
    };
    $scope.checkLen = function (key) {
        return getPageItems(key).filter((d) => d.checked && !d.disabled).length;
    }
    $scope.add = function () {
        let temp = [];
        angular.copy(models.origin.data.filter((a) => a.checked && !a.disabled), temp);
        models.pack.data.push(...temp);
        refreshMap();
        models.pack.checkAll = false;
        models.origin.checkAll = false;
    }
    $scope.remove = function () {
        let temp = [];
        angular.copy(models.pack.data.filter((a) => a.checked && !a.disabled), temp);
        models.pack.data = models.pack.data.filter((a) => temp.map((t) => t.id).indexOf(a.id) <= -1 );
        refreshMap();
        models.pack.checkAll = false;
        models.origin.checkAll = false;
    }
    $scope.next = function(){
        checkAddress().then(function () {
            models.step = 2;
            getData();
        });
    };
    $scope.onSearch = debounce(getSearch, 500);
    $scope.ok = function(){
        let keyword = [];
        models.loading = true;
        if (models.type == 2) {
            keyword = models.departs.filter(function (d) { return d.checked }).map(function (de) { return de.name });
            $http.post("/thor/uaa/manager", {
                "keyword": keyword,
                "is_create":1
            }).then(function (res) {
                if(res.data.result) 
                    $modalInstance.close();
            }).finally(function () { models.loading = false; });
        }
        if (models.type == 1) {
            models.pack.data.forEach(function (a) {
                delete a.checked;
                delete a.disabled;
            })
            $http.post("/thor/uaa/save", {
                data: models.pack.data
            }).then(function (res) {
                if(res.data.result) 
                    $modalInstance.close();
            }).finally(function () { models.loading = false; });
        }
    };
    $scope.cancel = function(){
        $modalInstance.dismiss();
    };
})
// 帐号设置 1.添加角色 2.添加部门
.controller("AccountSettingCtrl", function($scope, $http, $modalInstance, networkUtils, Depart, params){
    // 帐号类型，管理帐号，普通帐号
    let models = $scope.m = {
        type: 0, // 帐号类型 0，管理帐号，2，普通帐号
        ids: [],
        data: params,
        loading: false,
        roles:  [],
        pools: []
    };
    // 管理帐号
    let modelsAdmin = $scope.a = {
        classes: [],
        manage_all_classes: true,
        permission: null
    };
    // 普通帐号
    let modelsCommon = $scope.c = {
        department: null
    }
    const getRoles = function () {
        return $http.get("/thor/user/permissions").then(function (res) {
            models.roles = res.data.result;
            console.log('models.roles:', models.roles);
        })
    }
    const getPools = function () {
        return $http.get("/thor/pools?simple=true&managed=false&product_type=all").then(function (res) {
            models.pools = res.data.pools_;
            console.log('models.pools:', models.pools);
        })
    }
    var nodes = [], tree = []; // 父子（树）关系的数据
    /* getRoles();
    getPools(); */
    const queryDepart = function(){
        return Depart.query(function(res){
            $scope.treedata_loading = false;
            nodes = res.result;
            let rootId = nodes.filter((n) => !n.parent)[0].id;
            $scope.treedata = tree = nodes.length ? transformTreeData(nodes, "id", "parent", "children", rootId) : [];
            $scope.treedata[0].children && 
                $scope.treedata[0].children.sort(
                    function(a, b){ return a.name > b.name ? -1 : 1 }
                );
            setTimeout(function () {
                $scope.expandnodes = nodes;
            }, 1000);
            $scope.expandnodes = nodes;
            var selected = {};
            if($scope.selected){
                var _selected = nodes.filter(function(item){ return item.id == $scope.selected.id })[0];
                selected = _selected ? _selected : tree[0];
            }else{
                selected = tree[0];
            }
            $scope.selected = selected;
            if($scope.selected){
                $scope.selected._selected = true;
                modelsCommon.department = $scope.selected.id;
            }
        }, function(){
            $scope.treedata_loading = false;
        });
    }
    models.loading = true;
    Promise.all([
        getRoles(),
        getPools(),
        queryDepart()
    ]).then(function () {
        models.loading = false;
    })
    const transformTreeData = (source, id, parentId, children, rootId) => {
        let tree = source.filter(item =>{
            return item[id] === rootId;
        })
        tree[0][children] =  source.filter(father=>{
            let branchArr = source.filter(child => father[id] == child[parentId]);
            branchArr.length > 0 ? father[children] = branchArr : ''
            return father[parentId] == rootId;
        })
        return tree;
    }
    // 初始化树状图
    const initTree = function (scope, flag){
        scope.opts = {};
        scope.treedata = tree;
        scope.expandnodes = nodes;
        scope.selected = scope.treedata[0] ? scope.treedata[0] : null;
        if(scope.selected){
            scope.selected._selected = true;
        }
        scope.showSelected = function(node, selected){
            node._selected = selected;
            scope.selected = node;
            if(scope.selected._selected && flag){
                modelsCommon.department = scope.selected.id;
            }
            if (!selected) {
                scope.selected = null;
                modelsCommon.department = null;
            }
        }
    }
    initTree($scope, true);
    $scope.islastGroup = function(){
        return $scope.selected && !nodes.filter(function(item){
            return item.id !== $scope.selected.id;
        }).filter(function(item){
            return (item.full_path + '/').indexOf($scope.selected.full_path + '/') > -1;
        }).length
    }
    $scope.treedata_loading = true;
    // queryDepart();
    $scope.$watch("m.type", function (val) {
        if(val == 2) {
            $scope.expandnodes = nodes;
        }
    })
    $scope.isValid = function () {
        if(models.type == 0) {
            let classes = models.pools.filter(function (item) {
                if (item._selected) return item
            }).map(function (item) {
                return item.id
            })
            if(!modelsAdmin.manage_all_classes && !classes.length) {
                return false;
            }
        } else {
            if(!modelsCommon.department) {
                return false;
            }
        }
        return true;
    }
    $scope.ok = function(){
        models.loading = true;
        if(models.type == 0) {
            let classes = models.pools.filter(function (item) {
                if (item._selected) return item
            }).map(function (item) {
                return item.id
            });
            return $http.put("/thor/uaa/manager", {
                "classes": classes || [],
                "id": params.map((item) => item.id),
                "manage_all_classes": modelsAdmin.manage_all_classes,
                "permission": modelsAdmin.permission.id
            }).then(function (res) { 
                if (res.data.result)
                    $modalInstance.close(); 
            }).finally(function () { models.loading = false; })
        } else {
            return $http.put("/thor/uaa/common", {
                "id": params.map((item) => item.id),
                "department": modelsCommon.department
            }).then(function (res) { 
                if (res.data.result)
                    $modalInstance.close(); 
            }).finally(function () { models.loading = false; })
        }
    };
    $scope.cancel = function(){
        $modalInstance.dismiss();
    };
});
