angular.module("vdi.desktop", []);
angular.module("idv.desktop", []);
angular.module("voi.desktop", []).run(function (injectRoute, productType, productType2) {
    "ngInject";
    //因为融合版需要的页面，都把控制器写到了 html 中，所以这里不需要再用 controller指定，否则容易出现 列表请求同时时间出现2条的问题
    injectRoute("/desktop/scene", {
        vdi: {
            resolve: {
                moduleLoaded: () => import("../vdi/desktop/scene")
            },
            templateUrl: "views/vdi/desktop/scene.html"
            //controller: "vdiDesktopSceneListController"
        },
        voi: {
            resolve: {
                moduleLoaded: () => import("../voi/desktop/controller.scene")
            },
            moduleName: "voi.desktop",
            templateUrl: "views/voi/desktop/scene.html"
            //controller: "voiDesktopSceneListController"
        },
        vdoi: {
            resolve: {
                moduleLoaded: () => {
                    let promiseArr = [import("../vdi/desktop/scene"), import("../voi/desktop/controller.scene")];
                    return Promise.all(promiseArr)
                }
            },
            moduleName: ["vdi.desktop", "voi.desktop"],
            templateUrl: "views/voi/desktop/scene-tab.html"
        },
        idv: {
            resolve: {
                moduleLoaded: () => import("../idv/desktop/controller.scene")
            },
            moduleName: "idv.desktop",
            templateUrl: "views/idv/desktop/scene.html"
        },
        "vdi+idv": {
            resolve: {
                moduleLoaded: () => {
                    let promiseArr = [import("../vdi/desktop/scene"), import("../idv/desktop/controller.scene")];
                    return Promise.all(promiseArr)
                }
            },
            moduleName: ["vdi.desktop", "idv.desktop"],
            templateUrl: "views/voi/desktop/scene-tab.html"
        },
        "voi+idv": {
            resolve: {
                moduleLoaded: () => {
                    let promiseArr = [import("../voi/desktop/controller.scene"), import("../idv/desktop/controller.scene")];
                    return Promise.all(promiseArr)
                }
            },
            moduleName: ["voi.desktop", "idv.desktop"],
            templateUrl: "views/voi/desktop/scene-tab.html"
        },
        "vdoi+idv": {
            resolve: {
                moduleLoaded: () => {
                    let promiseArr = [import("../vdi/desktop/scene"), import("../voi/desktop/controller.scene"), import("../idv/desktop/controller.scene")];
                    return Promise.all(promiseArr)
                }
            },
            moduleName: ["vdi.desktop", "voi.desktop", "idv.desktop"],
            templateUrl: "views/voi/desktop/scene-tab.html"
        }
    }[productType2]);

    if (productType === 'vdoi') {
        injectRoute("/desktop/roam", {
            vdoi: {
                resolve: {
                    moduleLoaded: () => Promise.all([import("../voi/desktop/controller.personal"), import("../voi/desktop/controller.roam")])
                },
                moduleName: ["voi.desktop"],
                templateUrl: "views/voi/desktop/roam.html"
            }
        }[productType]);
    }

    injectRoute("/desktop/personal", {
        vdi: {
            resolve: {
                moduleLoaded: () => Promise.all([import("../vdi/desktop/scene"), import("../vdi/desktop/personal")])
            },
            templateUrl: "views/vdi/desktop/personal.html",
            //controller: "vdiDesktopPersonalListController"
        },
        voi: {
            resolve: {
                moduleLoaded: () => import("../voi/desktop/controller.personal")
            },
            moduleName: "voi.desktop",
            templateUrl: "views/voi/desktop/personal.html",
            //controller: "voiDesktopPersonalListController"
        },
        vdoi: {
            resolve: {
                moduleLoaded: () => Promise.all([
                    import("../vdi/desktop/scene"), import("../vdi/desktop/personal"),
                    import("../voi/desktop/controller.personal")
                ])
            },
            moduleName: ["vdi.desktop", "voi.desktop"],
            templateUrl: "views/voi/desktop/personal-tab.html"
        }
    }[productType]);

    injectRoute("/desktop/pool", {
        resolve: {
            moduleLoaded: () => import("../vdi/desktop/personal-desktop-pool")
        },
        templateUrl: "views/vdi/desktop/pool.html",
        //controller: "vdiDesktopPoolController"
    });
    // 新增- *教学桌面池 路由
    injectRoute("/desktop/tpool", {
        resolve: {
            moduleLoaded: () => import("../vdi/desktop/teach-pool")
        },
        templateUrl: "views/vdi/desktop/teach-pool.html"
    });
    // id 用于切换路由 name 用来显示面包屑 fname用来显示跳转时 用来的筛选参数
    injectRoute("/desktop/voiteach/:id", {
        resolve: {
            moduleLoaded: () =>  Promise.all([import("../voi/desktop/controller.personal"), import("../voi/desktop/controller.scene")])
        },
        moduleName: ["voi.desktop"],
        breadcrumbs: ["桌面", "教学桌面", ":name"],
        templateUrl: "views/voi/desktop/teach-list.html",
        //controller: "voiDesktopTeachListController"
    });
    injectRoute("/desktop/idvteach/:id", {
        resolve: {
            moduleLoaded: () =>  Promise.all([import("../idv/desktop/controller.scene")])
        },
        moduleName: ["idv.desktop"],
        breadcrumbs: ["桌面", "教学桌面", ":name"],
        templateUrl: "views/idv/desktop/teach-list.html",
        //controller: "voiDesktopTeachListController"
    });
    injectRoute("/desktop/teach/:id", {
        resolve: {
            moduleLoaded: () => import("../vdi/desktop/teach")
        },
        breadcrumbs: ["桌面", "教学桌面", ":name"],
        templateUrl: "views/vdi/desktop/teach.html",
        //controller: "vdiDesktopTeachListController"
    });
    injectRoute("/desktop/poolList/:id", {
        resolve: {
            moduleLoaded: () => import("../vdi/desktop/personal-desktop-pool")
        },
        breadcrumbs: ["桌面", "个人桌面池", ":name"],
        templateUrl: "views/vdi/desktop/poolList.html",
        //controller: "vdiDesktopPoolListController"
    });
    // 新增- *教学桌面池(子) - 桌面列表 路由
    injectRoute("/desktop/tpooldesks/:id", {
        resolve: {
            moduleLoaded: () => import("../vdi/desktop/teach-pool")
        },
        breadcrumbs: ["桌面", "教学桌面池", ":name"],
        templateUrl: "views/vdi/desktop/teach-desks.html"
    });
});
require("../vdi/desktop/api");
require("../vdi/desktop/common");
require("../voi/desktop/controller.tab.scene");
require("../voi/desktop/controller.tab.personal");

require('../vdi/desktop/personal.css');