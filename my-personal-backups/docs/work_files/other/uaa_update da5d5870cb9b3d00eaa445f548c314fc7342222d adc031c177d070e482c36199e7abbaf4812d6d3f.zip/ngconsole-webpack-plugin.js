/** @typedef { import("@types/webpack").Compiler } Compiler */
const fs = require("fs");
const path = require("path");
const mkdirp = require("mkdirp");
const Mock = require("mockjs");
const cp = require("child_process");
const http = require("http");
const https = require("https");
const urllib = require("url");
const { createProxyMiddleware } = require("http-proxy-middleware");
const ProxyAgent = require("proxy-agent");

const isProduction = process.env.NODE_ENV === "production";
const ngconsoleResourceRoot = path.resolve(process.env.NGCONSOLE_RESOURCES || "../ngconsole_resources");


class NgconsoleWebpackPlugin {
    constructor(){
        NgconsoleWebpackPlugin.checkBranches();
    }
    /**
     *
     * @param {Compiler} compiler
     */
    apply(compiler){
        if(isProduction) {
            this.applyProduction(compiler);
        } else {
            this.applyDevelopment(compiler);
        }
    }
    /**
     *
     * @param {Compiler} compiler
     */
    applyDevelopment(compiler){
        // watch ngconsole_resources ?
    }
    /**
     *
     * @param {Compiler} compiler
     */
    applyProduction(compiler){
        let vendor = NgconsoleWebpackPlugin.getGitBranch(".").split("-").pop();
        vendor = vendor.replace(/\([^)]+\)/, "");
        if(["dev", "idv", "vpc"].includes(vendor)) {
            vendor = "os-easy";
        }
        compiler.plugin("done", function(){
            // 打包时输出 ngconsole_resources 资源
            let buildResourceProc = cp.fork("../ngconsole_resources/build.js");
            buildResourceProc.send([__dirname, vendor]);
            // 库包
            NgconsoleWebpackPlugin.buildVendorBundle();
        });
    }
    static getGitBranch(gitRoot) {
        var headfile = path.resolve(gitRoot, ".git/HEAD");
        let text = fs.readFileSync(headfile, "utf-8");
        let branch = text.trim().replace("ref: refs/heads/", "");
        // 检测游离 HEAD
        if(/^[0-9a-f]{40}$/.test(branch) && path.resolve(gitRoot) === __dirname) {
            if(!process.env.NGCONSOLE_BRANCH) {
                console.log("仓库处于游离 HEAD 状态，要继续运行请指定环境变量 NGCONSOLE_BRANCH")
                return process.exit();
            }
            branch = process.env.NGCONSOLE_BRANCH;
        }
        return branch;
    }
    static checkBranches(){
        var ngconsoleBranch = this.getGitBranch(".");
        var ngconsoleResourceBranch = this.getGitBranch("../ngconsole_resources");
        // (5.1.4-vpc) $ git checkout -b 5.2.0-vpc-OEM-xx
        let parts = (ngconsoleBranch.indexOf("5.2.0-vpc") === 0
            ? ngconsoleBranch.replace("5.2.0-vpc", "5.1.4-vpc")
            : ngconsoleBranch).split("-");
        let version = parts[1] === "vpc" ? parts.slice(0, 2).join("-") : parts[0];
        if(!(version === ngconsoleResourceBranch || ngconsoleBranch === ngconsoleResourceBranch)) {
            var error = [
                "当前 ngconsole 分支 ", ngconsoleBranch,
                " 与 ngconsole_resources 分支 ", ngconsoleResourceBranch,
                " 不匹配！"
            ].join("");
            console.error(error);
            console.error(error);
            console.error(error);
            process.exit();
        }
    }
    static bindDevServerBefore(app){
        let branch = this.getGitBranch(".");
        let vendor;
        if(branch.indexOf("-OEM-") != -1){
            vendor = branch.split("-").pop();
        } else {
            vendor = null;
        }
        // 重定向资源文件到 ngconsole_resources
        app.get(/^\/resources\//, function(req, resp){
            let filename = path.basename(req.path);
            let language = path.basename(path.dirname(req.path));
            let files = [];
            if(vendor) {
                let vendorRoot = path.resolve(ngconsoleResourceRoot, "resources/pkg", vendor);
                files.push(
                    vendorRoot + path.sep + language + path.sep + filename,
                    vendorRoot + path.sep + filename
                );
            } else {
                let vendorRoot = ngconsoleResourceRoot;
                files.push(vendorRoot + path.sep + language + path.sep + filename);
                if(language !== "zh-cn") {
                    files.push(vendorRoot + path.sep + "zh-cn" + path.sep + filename);
                }
            }
            let finalFile;
            for(let file of files) {
                if(fs.existsSync(file)) {
                    resp.setHeader("Use-File", file);
                    finalFile = file;
                    break;
                }
            }
            if(!finalFile) {
                return resp.status(404).end();
            }
            if(filename === "code.json" || filename === "lang.json") {
                let parentFile = path.resolve(ngconsoleResourceRoot, language, filename);
                let parentJSON = JSON.parse(fs.readFileSync(parentFile, "utf-8"));
                if(language !== "zh-cn") {
                    let parentCnFile = path.resolve(ngconsoleResourceRoot, "zh-cn", filename);
                    let parentCnJSON = JSON.parse(fs.readFileSync(parentCnFile, "utf-8"));
                    parentJSON = Object.assign(parentCnJSON, parentJSON);
                }
                let data = JSON.parse(fs.readFileSync(finalFile, "utf-8"));
                data = Object.assign(parentJSON, data);
                resp.set("content-type", "application/json");
                resp.end(JSON.stringify(magicReplace(data), null, 2));
            } else {
                resp.sendFile(finalFile);
            }
        });
        // 开发时动态修改 js/env.js，并注入合适的代码
        app.get("/js/env.js", function(req, resp){
            var code = fs.readFileSync("js/env.js", "utf-8");
            code += "\nwindow.vdiEnvironment = 'development';\n";
            resp.setHeader("Content-Type", "application/javascript");
            resp.end(code.replace("/built/", "/devbuild/"));
        });
        // 开发时 built 重定向到 webpack 的结果
        app.get(/^\/built\//, function(req, resp){
            resp.redirect(req.url.replace("/built/", "/devbuild/"));
        });
        app.get("/personal_login/", function(req, resp){
            var file = path.join(__dirname, req.url, "index.html");
            var code = fs.readFileSync(file, "utf-8");
            resp.status(200).set("Content-Type", "text/html");
            resp.end(code.replace("</head>", "<script>window.vdiEnvironment = \"development\";</script></head>"));
        });
        app.get("/ssh_terminal/", function(req, resp){
            var file = path.join(__dirname, req.url, "index.html");
            var code = fs.readFileSync(file, "utf-8");
            resp.status(200).set("Content-Type", "text/html");
            resp.end(code.replace("</head>", "<script>window.vdiEnvironment = \"development\";</script></head>"));
        });
        app.get("/js/all.bundle.js", function(req, resp){
            resp.set("Content-Type", "application/javascript");
            NgconsoleWebpackPlugin.buildVendorBundle(true).pipe(resp);
        });
    }
    static bindDevServerAfter(app){
        app.use(proxyMiddleware({vdiProxy: process.env.vdiProxy}));
    }
    static buildVendorBundle(stream){
        let vendorFiles = process.env.NODE_ENV === "production" ? [
            "js/libs/jquery-2.1.1.min.js",
            "js/libs/jquery-ui-1.10.3.min.js",
            "js/bootstrap/bootstrap.min.js",
            "js/notification/SmartNotification.min.js",
            "js/libs/angular/angular.min.js",
            "js/libs/angular/angular-resource.min.js",
            "js/libs/angular/angular-route.min.js",
            "js/libs/angular/angular-animate.min.js",
            "js/plugin/angular-tree-control/angular-tree-control.js",
            "js/libs/angular/ui-bootstrap-custom-tpls-0.11.0.js"
        ] : [
            "js/libs/jquery-2.1.1.min.js",
            "js/libs/jquery-ui-1.10.3.min.js",
            "js/bootstrap/bootstrap.js",
            "js/notification/SmartNotification.min.js",
            "js/libs/angular/angular.js",
            "js/libs/angular/angular-resource.min.js",
            "js/libs/angular/angular-route.js",
            "js/libs/angular/angular-animate.min.js",
            "js/plugin/angular-tree-control/angular-tree-control.js",
            "js/libs/angular/ui-bootstrap-custom-tpls-0.11.0.js"
        ];
        let outputStream;
        if(stream) {
            outputStream = require("through2")();
        } else {
            let targetFile = "js/all.bundle.js";
            outputStream = fs.createWriteStream(targetFile);
        }
        vendorFiles.forEach(function(file){
            outputStream.write(fs.readFileSync(file));
        });
        outputStream.end();
        return outputStream;
    }
}

module.exports = NgconsoleWebpackPlugin;

/**
 * 如果 json 指定了 `$replace`, 则进行魔法替换，魔法替换的规则：
 * 如果指定```
  {
    "$replace": {
      "a": "b"
    }
  }``` 则对于 json 每一个属性名包含 `"a"` 的条目，将其属性值里面的 `"a"` 替换为 `"b"`
  如果对于某些特定的 json 条目，并不希望被替换，则可以指定 `$replaceExcludes`
 * @param {Object} json 
 */
function magicReplace(json) {
    let $replace = json["$replace"] || {};
    let $replaceKeys = Object.keys($replace);
    let $replaceExcludeKeys = json["$replaceExcludeKeys"] || [];
    delete json["$replace"];
    delete json["$replaceExcludeKeys"];
    Object.keys(json).forEach(function(key){
        if($replaceExcludeKeys.indexOf(key) > -1) { return; }
        $replaceKeys.forEach(function($key){
            json[key] = replaceAll(json[key], $key, $replace[$key]);
        });
    });
    return json;
}

/**    
 *     
 * @param {string} str 
 * @param {string} sub1 
 * @param {string} repl 
 */    
function replaceAll(str, sub1, repl) {
    let i = 0;
    while((i = str.indexOf(sub1, i)) !== -1) {
        str = str.replace(sub1, repl);
        i += repl.length;
    }
    return str;
}

const proxyCache = {};
function proxyMiddleware(options){
    let useProxy = true;
    accessable("http://172.16.203.254/users/sign_in", "http://172.16.203.12/zentao/my/").then(function(){
        useProxy = false;
    }, function(){});
    return function(req, resp, next){
        let proxyHost = req.get("X-Mock-Proxy");
        if(!proxyHost) {
            return next();
        }
        let proxyUri = useProxy ? options.vdiProxy : false;
        let proxyMiddleware = proxyCache[proxyHost];
        if(!proxyMiddleware) {
            proxyMiddleware = proxyCache[proxyHost] = createProxyMiddleware("/", {
                target: `https://${proxyHost}`,
                secure: false,
                changeOrigin: true,
                logLevel: "debug",
                agent: proxyUri ? new ProxyAgent(proxyUri) : undefined
                , onProxyRes: function onProxyRes (proxyRes, req, res) {
                    let original_cookie = proxyRes.headers['set-cookie'];
                    if (!original_cookie) return;
                    let modified_cookie = original_cookie.map(str => {
                        return str.replace(/(;\s*)?SameSite=None/, '')
                                  .replace(/(;\s*)?secure/, '');
                    });
                    if (modified_cookie.every((str, i) => str === original_cookie[i])) return;
                    console.log(original_cookie);
                    console.log(modified_cookie);
                    proxyRes.headers['set-cookie'] = modified_cookie;
                }
            });
        }
        proxyMiddleware(req, resp, next);
    }
}

function accessable(...urls) {
    return Promise.race(urls.map(url => {
        let httplib = url.indexOf("https://") === 0 ? https : http;
        return new Promise(function(resolve, reject) {
            let obj = urllib.parse(url);
            httplib.request({
                method: "GET",
                path: obj.path,
                host: obj.host,
                timeout: 3000
            }, function(){
                resolve();
            }).on("error", reject).end();
        });
    }));
}
