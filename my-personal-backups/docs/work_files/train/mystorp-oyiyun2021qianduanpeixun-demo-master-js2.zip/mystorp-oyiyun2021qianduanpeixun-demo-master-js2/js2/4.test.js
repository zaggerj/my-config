// TestCase: "2015-04-15" => 3
expect(run("2015-04-15")).to.equal(3);
// TestCase: "2016-04-16" => 6
expect(run("2016-04-16")).to.equal(6);
// TestCase: "2017-04-17" => 1
expect(run("2017-04-17")).to.equal(1);
// TestCase: "2018-04-18" => 3
expect(run("2018-04-18")).to.equal(3);
// TestCase: "2019-04-19" => 5
expect(run("2019-04-19")).to.equal(5);
// TestCase: "2020-04-20" => 1
expect(run("2020-04-20")).to.equal(1);
// TestCase: "2021-04-21" => 3
expect(run("2021-04-21")).to.equal(3);
// TestCase: "2022-04-22" => 5
expect(run("2022-04-22")).to.equal(5);
