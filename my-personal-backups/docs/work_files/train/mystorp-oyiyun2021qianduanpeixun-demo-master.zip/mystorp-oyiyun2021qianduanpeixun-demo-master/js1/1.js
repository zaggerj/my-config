function run(n) {
    let i = 1, arr = [];
    for(; i <= n; i++) { arr.push(i); }
    return arr;
}
