// TestCase: 1
expect(run(1)).to.equal(0);
// TestCase: 2
expect(run(2)).to.equal(0);
// TestCase: 3
expect(run(3)).to.equal(2);
// TestCase: 4
expect(run(4)).to.equal(5);
// TestCase: 500
expect(run(500)).to.equal(21536);