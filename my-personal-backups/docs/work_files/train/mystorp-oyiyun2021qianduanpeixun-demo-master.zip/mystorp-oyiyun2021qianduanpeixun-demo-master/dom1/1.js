function run(){
    return [
        "ul ol li",
        "form input select option textarea",
        "video audio canvas img",
        "table thead tbody tr th td",
        "a i span label strong button small",
        "div p h1 h2 h3 h4 h5 h6 header main footer section article"
    ].join(" ").split(" ");
}