# demoPractice

## 技术框架：vue2

## ui框架：自选，iView，ElementUi,等等。

## 说明：

1. 页面图片在page.png，**主要完成红框内的**功能元素，包含：
   - 增加createModal.png，同编辑，两者相同，**但是有区别**。
   - 删除confirmDelete.png
   - 重置密码confirmOK.png**验证"OK"**
   - 列表数据，自行编造一些假数据，比方说：[{account: "xxx", ...}]，列表中每一行中，有checkbox复选框，进行单选，表格的thead中的tr行，中的checkbox是**全选的功能**。
   - 前端模糊搜索，输入关键字，可以筛选列表数据。

2. 视进度，选择性完成的功能，包含：
   - 前端页面分页
   - **红框外的页面组织形式，即两个或者多个页面，是如何进行路由和组织，进行切换的。**